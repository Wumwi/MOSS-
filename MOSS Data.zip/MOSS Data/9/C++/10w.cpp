// Exemplo de implementacao do mergesort
// ----------------------------------
// Pedro Ribeiro (DCC/FCUP) - 17/10/2015
//10 7 1 3 8 6 4 4 6 9 
// ----------------------------------

#include <iostream>
int contador =0;
using namespace std;

// Juntar dois arrays ordenados
// Assumir que os arrays sao v[start..middle] e v[middle+1..end]
int merge(int v[], int start, int middle, int end) {
  int i, p1, p2, aux[end+1], cont=0;

  p1=start;     // "Apontador" do array da metade esquerda
  p2=middle+1;  // "Apontador" do array da metade direita
  i = start;    // "Apontador" do array aux[] a conter juncao
  while (p1<=middle && p2<=end) { 
	  cout<<v[p1]<< " " <<v[p2]<<endl;           // Enquanto de para comparar
    if (v[p1] <= v[p2]) aux[i++] = v[p1++]; // Escolher o menor e adicionar
    else                {aux[i++] = v[p2++]; cont+=(middle+1)-p1;}
  }
  while (p1<=middle) aux[i++] = v[p1++];     // Adicionar o que resta
  while (p2<=end)    aux[i++] = v[p2++];

  for (i=start; i<=end; i++) v[i] = aux[i];  // Copiar array aux[] para v[]
  
  return cont;
}

// Ordenar array v[] com mergesort entre posicoes start e end
int mergesort(int v[], int start, int end) {
  int middle,contador=0;
  if (start<end) {                 // Parar quando tamanho do array < 2
    middle = (start+end)/2;        // Calcular ponto medio
    contador+=mergesort(v, start, middle);   // Ordenar metade esquerda
    contador+=mergesort(v, middle+1, end);   // Ordenar metade direita
    contador+=merge(v, start, middle, end);  // Combinar duas metades ordenadas
  }
  return contador;
}
 
int main() {
  int n;
  
  // Ler N numeros
  cin >> n;
  int v[n];
  for (int i=0; i<n; i++)
    cin >> v[i];

  // Ordenar
  int cont=mergesort(v, 0, n-1);

  // Imprimir
  for (int i=0; i<n; i++) {
    if (i>0) cout << ' ';
    cout << v[i];
  }
  cout << endl;

  cout<<cont<<endl;
  return 0;
}
