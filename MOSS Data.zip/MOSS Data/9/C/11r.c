#include <stdio.h> 

int v[100000];

int main() {

  int n,new,inv=0;
 
  int i,k,j;
  scanf("%d",&n);

  
    for(i=0;i<n;i++){
      scanf("%d",&new);
      v[i]=new;
    }

    for(j=0;j<n;j++){
      for(k=(j+1);k<n;k++){
	if(v[j]>v[k] && j<k){
	  inv++;
	}
      }
    }

    printf("%d\n",inv);
 

  return 0;
}
