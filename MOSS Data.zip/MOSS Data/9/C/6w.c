#include <stdio.h>
#include <stdlib.h>

int inversoes_brute_force(int v[],int n);
int inversoes_merge_rec(int v[], int start, int end);
int inversoes_merge(int v[], int start, int middle, int end);

int main(){

	int n,i;
	scanf("%d", &n);
	int v[n];

	for(i=0; i<n; i++){
		scanf("%d",&v[i]);
	}

	int n_inversoes;
	//n_inversoes=inversoes_brute_force(v,n);
	//printf("BRUTE FORCE:    %d\n", n_inversoes);
	n_inversoes=inversoes_merge_rec(v,0,n-1);
	//printf("MERGE ALTERADO: %d\n", n_inversoes);
	printf("%d\n",n_inversoes);
	return 0;
}

int inversoes_brute_force(int v[],int n){
	int contador=0;
	int i,j;

	for(i=0; i<n;i++){
		for(j=i+1; j<n; j++){
			if(v[i]>v[j])
				contador++;
		}
	}
	return contador;
}

int inversoes_merge_rec(int v[], int start, int end){
	int contador=0;
	int middle = (start+end)/2;
	/*Aqui vem uma condicao de paragem de recursao*/
	if(start==end){
		return 0;
	}
	contador += inversoes_merge_rec(v,start,middle); 
	contador += inversoes_merge_rec(v,middle+1,end); 
	contador += inversoes_merge(v,start,middle,end);

	return contador;
}

int inversoes_merge(int v[], int start, int middle, int end){
	int contador=0;

	int i=start;
	int i_control=0;
	int j=middle+1;
	int j_control=0;
	int k=start;
	int novo_v[end+1];
	while(k<=end){		
		//i chegou ao limite, apenas vemos se valor em i é mais pequeno que em j		
		if(i==middle){				
			if(i_control==1){	//o v[i] ja foi usado por isso copio o v[j] que ainda tem elementos
				novo_v[k]=v[j];
				contador+=j-k;		//CONTAR QUANTAS POSICOES O NUMERO ESTA DESLOCADO DO ARRAY ORDENADO (j-k)
				k++;
				j++;
				continue;
			}					//v[i] nao usado e é mais pequeno que v[j]
			if(v[i]<=v[j]){
				novo_v[k]=v[i];
				k++;
				i_control=1;
				continue;
			}
		}
		//j chegou ao limite, apenas vemos se valor em j é mais pequeno que em i
		if(j==end){
			if(j_control==1){	//v[j] ja foi usado por isso copio o v[i] que ainda tem elementos
				novo_v[k]=v[i];
				k++;
				i++;
				continue;
			}					//v[j] nao usado e é mais pequeno que v[i]
			if(v[j]<v[i]){
				novo_v[k]=v[j];
				contador+=j-k;		//CONTAR QUANTAS POSICOES O NUMERO ESTA DESLOCADO DO ARRAY ORDENADO (j-k)
				k++;
				j_control=1;
				continue;
			}
		}
		//ainda nao atingiram os extremos corre normalmente
		if(v[i]<=v[j]){
			novo_v[k]=v[i];
			i++;
			k++;
		}
		else{
			novo_v[k]=v[j];
			contador+=j-k;			//CONTAR QUANTAS POSICOES O NUMERO ESTA DESLOCADO DO ARRAY ORDENADO (j-k)
			j++;
			k++;
		}
	}
	//Copiar os valores agora ordenados para o vector original
	for(i=start;i<=end;i++){
		v[i]=novo_v[i];
	}
	return contador;
}
