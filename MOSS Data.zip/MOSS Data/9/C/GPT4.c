#include <stdio.h>

typedef struct {
    int left;
    int right;
    int count;
} Node;

Node segTree[4 * 100000];
int arr[100000];

void build(int node, int start, int end) {
    if (start == end) {
        segTree[node] = (Node){start, end, 0};
    } else {
        int mid = (start + end) / 2;
        build(node * 2, start, mid);
        build(node * 2 + 1, mid + 1, end);
        segTree[node] = (Node){start, end, 0};
    }
}

int countInversions(int node, int start, int end) {
    if (start == end) return 0;
    int mid = (start + end) / 2;
    int invCount = countInversions(node * 2, start, mid) +
                   countInversions(node * 2 + 1, mid + 1, end);
    int j = mid + 1;

    for (int i = start; i <= mid; i++) {
        while (j <= end && arr[i] > arr[j]) {
            j++;
        }
        invCount += (j - (mid + 1));
    }
    return invCount;
}

int main() {
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    build(1, 0, n - 1);
    printf("%d\n", countInversions(1, 0, n - 1));
    return 0;
}
