// Exemplo de implementacao do mergesort
// ----------------------------------
// Pedro Ribeiro (DCC/FCUP) - 17/10/2015
// ----------------------------------

#include <stdio.h>

#define MAX 100005

// Juntar dois arrays ordenados
// Assumir que os arrays sao v[start..middle] e v[middle+1..end]
int merge(int v[], int start, int middle, int end) {
  int i = 0, p1, p2, aux[MAX];
  p1=start;     // "Apontador" do array da metade esquerda
  p2=middle+1;  // "Apontador" do array da metade direita
  int inversion =0;
  while (p1<=middle && p2<=end) {            // Enquanto de para comparar
    if (v[p1] <= v[p2]) aux[i++] = v[p1++];  // Escolher o menor e adicionar
    else { aux[i++] = v[p2++]; inversion += middle - p1 +1; }
   
  }
  while (p1<=middle) aux[i++] = v[p1++];     // Adicionar o que resta
  while (p2<=end)   aux[i++] = v[p2++];

  for(i = 0; i < end - start +1; i++){
    v[i+start]=aux[i];
  }
  return inversion;

}

// Ordenar array v[] com mergesort entre posicoes start e end
int mergesort(int v[], int start, int end) {
  int middle;
  int contador=0;
  if (start < end) {                 // Parar quando tamanho do array < 2
    middle = (start+end)/2;        // Calcular ponto medio
    contador = contador + mergesort(v, start, middle);   // Ordenar metade esquerda
    contador = contador + mergesort(v, middle+1, end);   // Ordenar metade direita
    contador = contador + merge(v, start, middle, end);  // Combinar duas metades ordenadas
  }
  return contador;
}
 
int main() {
  int i, n, v[MAX];
  int troca = 0; 

  
  // Ler N numeros
  scanf("%d", &n);
  for (i=0; i<n; i++)
    scanf("%d", &v[i]);

  // Ordenar
  troca = mergesort(v, 0, n-1); //chamada de função


  printf("%d\n", troca);

  return 0;
}
