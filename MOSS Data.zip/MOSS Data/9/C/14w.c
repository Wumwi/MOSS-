#include <stdio.h>
#include <stdlib.h>

long inv;

void merge(int v[], int s, int m, int e){
  int tam=e-s+1;
  int a[tam];
  int j=s,k=m,i=0, p;

  while(j<m &&k<=e){
    if(v[j]<=v[k])
      a[i]=v[j++];
    else {
      inv += m-j;
      a[i]=v[k++];      
    }
    i++;
  }


  while(j<m)
    a[i++]=v[j++];
  while(k<=e)
    a[i++]=v[k++];
  for(p=0;p<tam;p++)
    v[p+s]=a[p];

}
void mergesort(int v[], int start, int end){
  int middle=(start+end)/2;
  if(end>start){
    mergesort(v,start,middle);
    mergesort(v,middle+1,end);
    merge(v,start,middle+1,end);
  }
}
int main(){
  int i,n;
  scanf("%d",&n);
  int v[n];
  for(i=0;i<n;i++)
    scanf("%d",&v[i]);

  inv = 0;
  mergesort(v,0,n-1);
  printf("%ld\n",inv);

  return 0;
}
