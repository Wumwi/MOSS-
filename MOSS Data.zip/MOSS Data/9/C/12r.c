#include <stdio.h> 
#include <stdlib.h> 

int v[100000];

int main()
{
    
 
    int n,i,j;
    
    scanf("%d",&n);   
    /*int v[n]; */ 
    
    
    for(i=0;i<n;i++){
        scanf("%d",&v[i]);
        }
    
    
    int ac=0;
    
    for(i=0;i<n;i++){
		for(j=i+1;j<n;j++){
			if (v[j]<v[i]){
				ac++;
				
				}
			
			}}
    printf("%d\n",ac);
    
    return 0;
}
