#include <stdio.h>
typedef long long int lli;

lli merge (int v[], int s, int m, int e) {
  int tmp[e-s+1], i, j, c;
  lli count = 0;

  for (c = 0, i = s, j = m+1; c <= e-s; c++) {
    if (j > e)
      tmp[c] = v[i++];
    else if (i > m)
      tmp[c] = v[j++];
    else if (v[i] <= v[j])
      tmp[c] = v[i++];
    else {
      tmp[c] = v[j++];
      count += (m-i+1);
    }
  }

  for (c = 0; c <= e-s; c++)
    v[s+c] = tmp[c];

  return count;
}

lli mergesort(int v[], int start, int end) {
  int middle = (start+end)/2;
  lli c = 0;
  if (end-start) {
    c += mergesort(v, start, middle);
    c += mergesort(v, middle+1, end);
    c += merge(v, start, middle, end);
  }
  return c;
}

int main (void) {
  int n, i;
  scanf("%d", &n);
  int a[n];

  for (i = 0; i < n; i++)
    scanf("%d", a+i);

  printf("%lld\n", mergesort(a, 0, n-1));
  return 0;
}
