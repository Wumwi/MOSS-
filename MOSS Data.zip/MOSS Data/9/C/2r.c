#include <stdio.h>


int main()
{
    
    int n=0,i=0,aux=0,j=0,cont=0;
    scanf("%d",&n);
    int v[100000]={0};
    if(n>=1 && n<=100000){
        for(i=0;i<n;i++){
            scanf("%d",&aux);
            v[i]=aux;
        }
    }
    
    for(i=0;i<n;i++){
        for(j=(i+1);j<n;j++){
            if(v[i]>v[j] && i<j){
                //aux=v[i];
                //v[i]=v[j];
                //v[j]=aux;
                cont++;
            }
        }
    }
    
    //for(i=0;i<n;i++)
      //  printf("%d ", v[i]);
    
    printf("%d\n",cont);
    return 0;
};
