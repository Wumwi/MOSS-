#include <stdio.h>

#define MAX 1000000

int BIT[MAX + 1] = {0}; // Binary Indexed Tree

void update(int index, int value) {
    while (index <= MAX) {
        BIT[index] += value;
        index += index & -index;
    }
}

int query(int index) {
    int sum = 0;
    while (index > 0) {
        sum += BIT[index];
        index -= index & -index;
    }
    return sum;
}

int countInversions(int arr[], int n) {
    int invCount = 0;
    for (int i = n - 1; i >= 0; i--) {
        invCount += query(arr[i] - 1);
        update(arr[i], 1);
    }
    return invCount;
}

int main() {
    int n;
    scanf("%d", &n);
    int arr[n];
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    printf("%d\n", countInversions(arr, n));
    return 0;
}
