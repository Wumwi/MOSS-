#include <stdio.h>
#include <stdlib.h>
//int n;
int max(int x, int y){
	if(x>y) return x;
	return y;
}

int inversion(int v[], int start, int middle, int end){
	int counter=0;
	int left=start, right=middle+1;
	//printf("%d / %d - %d / %d +++++ ", left, v[left], right, v[right]);
	int temp[left-right+2];
	int j=0;
	while(left<=middle && right<=end){
		if(v[left]<=v[right]){
			temp[j]=v[left];
			left++;
		}
		else{
			temp[j]=v[right];
			counter+=(right-left);
			right++;
		}
		j++;
	}
	while(left<=middle){
		temp[j++]=v[left++];
	}
	while(right<=end){
		temp[j++]=v[right++];
	}
	for(j=0; j<left-right+2; j++){
		v[start+j]=temp[j];
	}
	//printf("%d !!!! \n", counter);
	return counter;
}

int mergeInversion(int v[], int start, int end){
	if(start==end) return 0;
	/*int i;
	for(i=start; i<=end; i++){
		printf("%d---", v[i]);
	}
	printf("\n");*/
	int middle=(start+end)/2;
	int counter=0;
	counter=mergeInversion(v, start, middle);
	counter=max(mergeInversion(v, middle+1, end), counter);
	counter=max(inversion(v, start, middle, end), counter);
	return counter;
}

int main(int argc, char **argv){
	int n;
	scanf("%d", &n);
	int v[n], i;
	for(i=0; i<n; i++){
		scanf("%d", &v[i]);
	}
/*	for(i=0; i<n; i++){
		printf("%d ", v[i]);
	}
	printf("\n");*/
	printf("%d\n", mergeInversion(v, 0, n-1));
	return 0;
}