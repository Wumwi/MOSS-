#include <stdio.h>

long c_merge(int v[],  int first, int last)
{

  int mid = (first+last)/2;
  int i = first;
  int j = mid+1;
  int f[last-first+1], k=0;
  long inver = 0, d;

  while (i <= mid && j <= last) {
    if (v[i] <= v[j]) {
      f[k++] = v[i++];
    } else {
      f[k++] = v[j++];
      inver += mid - i + 1;   }
  }
  while (i <= mid)
    f[k++] = v[i++];
  while (j <= last)
    f[k++] = v[j++];

  for (d=0 ; d<last-first+1 ; d++)
    v[d+first] = f[d];
  return inver;
}

long int count_inversion(int v[],  int a, int b)
{
  int mid;
  long x, y, z;
  if (a >= b) return 0;
  mid = (a+b)/2;
  x = count_inversion(v, a, mid);
  y = count_inversion(v, mid+1, b);
  z = c_merge(v, a, b);
  return x+y+z;
}

int main (void){

  int v[1000000];
  int i,n; 

  scanf ("%d", &n);
  for (i=0;i<n;i++){ scanf ("%d", &v[i]);}
  
  printf ("%ld\n",  count_inversion (v,0,n-1));

  return 0; }
