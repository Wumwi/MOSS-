#include <stdio.h>
#define MAX 100005

// Juntar dois arrays ordenados
// Assumir que os arrays sao v[start..middle] e v[middle+1..end]
int merge(int v[], int start, int middle, int end) {
  int i, p1, p2, aux[MAX];
  int c = 0;

  p1=start;     // "Apontador" do array da metade esquerda
  p2=middle;  // "Apontador" do array da metade direita
  i = start;    // "Apontador" do array aux[] a conter juncao
  while (p1<=middle-1 && p2<=end) {            // Enquanto de para comparar
    if (v[p1] <= v[p2]) aux[i++] = v[p1++];  // Escolher o menor e adicionar
    else                
      {
	aux[i++] = v[p2++];
	c = c + (middle - i);
      }
  }
  while (p1<=middle) aux[i++] = v[p1++];     // Adicionar o que resta
  while (p2<=end)    aux[i++] = v[p2++];

  for (i=start; i<=end; i++) v[i] = aux[i];  // Copiar array aux[] para v[]
  return c;
}

// Ordenar array v[] com mergesort entre posicoes start e end
int mergesort(int v[], int start, int end) {
  int middle;
  int c = 0;
  if (start<end) {                 // Parar quando tamanho do array < 2
    middle = (start+end)/2;        // Calcular ponto medio
    c += mergesort(v, start, middle);   // Ordenar metade esquerda
    c += mergesort(v, middle+1, end);   // Ordenar metade direita
    c += merge(v, start, middle+1, end);  // Combinar duas metades ordenadas
    return c;  
  }
  return c;
}
 
int main() {
  int i, n;
  
  // Ler N numeros
  scanf("%d", &n);

  int v[n];

  for (i=0; i<n; i++)
    scanf("%d", &v[i]);

 
  int inv = mergesort(v, 0, n-1);
  printf("%d\n",inv);
  
  return 0;
}
