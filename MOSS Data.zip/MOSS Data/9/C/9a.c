#include <stdio.h>

long long int count_inversion_merge(int array[], int inicio, int fim, int split) {
	
	int m_inicio = inicio;
	int m_fim = split + 1;
	int final[fim - inicio + 1], finali = 0;
	long long int inversion = 0, i;

	while (m_inicio <= split && m_fim <= fim) {
		if (array[m_inicio] <= array[m_fim]) {
			final[finali++] = array[m_inicio++];
		} else {
			final[finali++] = array[m_fim++];
			inversion += split - m_inicio + 1;
		}
	}
	while (m_inicio <= split)
		final[finali++] = array[m_inicio++];
	while (m_fim <= fim)
		final[finali++] = array[m_fim++];
	for (i = 0 ; i < fim -inicio + 1 ; i++)
		array[i+inicio] = final[i];
	
	return inversion;
}

long long int count_inversion(int array[], int inicio, int fim) {
	
	int split = (inicio + fim)/2;

	if (inicio >= fim) return 0;

	return count_inversion(array, inicio, split) + count_inversion(array, split+1, fim) + count_inversion_merge(array, inicio, fim, split);
	}

int main() {
	
	int i, x;

	scanf("%d", &x);

	int arr[x];

	for(i = 0; i < x; i++)
		scanf("%d", &arr[i]);

	printf("%lld\n", count_inversion(arr, 0, x-1));
	
	return 0;
}
