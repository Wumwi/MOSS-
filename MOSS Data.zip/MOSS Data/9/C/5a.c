#include <stdio.h>
#include <stdlib.h>
//inversion - mergesort method (O(nlogn))
long partition(int array[], int temp[], int start, int end);
long mergesort(int array[], int temp[], int start, int mid, int end);

int main (){
	int i;
	int arraysize;
	scanf("%d",&arraysize);
	int array[arraysize];
	int temp[arraysize];
	for(i=0; i<arraysize; i++)
		scanf("%d",&array[i]);
	long counterF = partition(array, temp, 0, arraysize-1);
	
	printf("%lu\n",counterF);
	return 0;
}

long partition(int array[], int temp[], int start, int end){
	int mid;
	long counter=0;
	if(start<end){
		mid = (start+end)/2;
		counter += partition(array, temp, start, mid);
		counter += partition(array, temp,  mid+1, end);
		counter += mergesort(array, temp, start, mid, end);
	}
	return counter;
}

long mergesort(int array[], int temp[], int start, int mid, int high){
	int i, m, k, l;
	long counterm=0;
	l = start;
	i = start;
	m = mid+1;
	
	while((l<=mid)&&(m<=high)){
		if(array[l]<=array[m]){
			temp[i] = array[l];
			l++;
		}
		else{
			temp[i] = array[m];
			m++;
			counterm += mid - l + 1;
		}
		i++;
	}
	if(l>mid){
		for(k=m; k<=high; k++){
			temp[i] = array[k];
			i++;
		}
	}
	else{
		for(k=l; k<=mid; k++){
			temp[i] = array[k];
			i++;
		}
	}
	for(k=start; k<=high; k++)
		array[k] = temp[k];
	return counterm;
}