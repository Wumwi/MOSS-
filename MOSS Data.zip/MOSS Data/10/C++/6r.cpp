#include <iostream>
#include <stdlib.h>
#define MAX 1000000

using namespace std;

int compare(const void * a, const void * b) {
	return (*(int*)a - *(int*)b);
}

int main(void) {

	int n, q = 0;
	int numbers[MAX] = { 0 };
	int sums[MAX] = { 0 };
	int current = 1;
	cin >> n;
	for (int i = 0; i != n; i++) cin >> numbers[i];
	sums[0] = numbers[0];
	for (int i = 0; i != n; i++) {
		for (int j = i + 1; j != n; j++) {
			sums[current] = numbers[i] + numbers[j];
			current++;
		}
	}
	qsort(sums, current, sizeof(int), compare);
	cin >> q;
	for (int i = 0; i != q; i++) {
		bool flag = true;
		int sum;
		int j = 0;
		int qnum = 0;
		int dif = 999;
		int current2 = -1;
		int targets[MAX] = { 0 };
		cin >> qnum;
		while (flag) {
			sum = sums[j] - qnum;
			if (abs(sum) <= dif) dif = abs(sum);
			else flag = false;
			j++;
		}
		flag = true;
		j = n;
		while (flag) {
			sum = sums[j] - qnum;
			if (abs(sum) <= dif) dif = abs(sum);
			else flag = false;
			j--;
		}
		j = 0;
		while (j<current) {
			sum = sums[j] - qnum;
			if (abs(sum) == dif) {
				current2++;
				targets[current2] = sums[j];
			}
			j++;
		}
		qsort(targets, current2, sizeof(int), compare);
		for (int prt = 0; prt != current2 + 1; prt++) {
			(current2-prt) == 0 ? cout << targets[prt] : cout << targets[prt] << " ";
		}
		cout << endl;
	}

#ifdef _DEBUG
	system("PAUSE");
#endif

	return 0;
}