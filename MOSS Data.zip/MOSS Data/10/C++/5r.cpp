#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <stdint.h>

std::set<uint32_t> query( uint32_t num, const std::vector<uint32_t> &sums )
{
	uint32_t distance = -1; // biggest unsigned integer possible
	std::set<uint32_t> res;

	for( std::vector<uint32_t>::const_iterator it = sums.begin( ); it != sums.end( ); ++it )
	{
		uint32_t dist = std::labs( *it - num );
		if( dist < distance )
		{
			distance = dist;
			res.clear( );
			res.insert( *it );
		}
		else if( dist == distance )
		{
			res.insert( *it );
		}
		else
		{
			break;
		}
	}

	return res;
}

int main( int argc, char **argv )
{
	size_t count = 0;
	if( !( std::cin >> count ) )
		return -1;

	std::vector<uint32_t> temp;
	temp.reserve( count );
	for( size_t i = 0; i < count; ++i )
	{
		uint32_t num = 0;
		if( !( std::cin >> num ) )
			return -1;

		temp.push_back( num );
	}

	std::vector<uint32_t> nums;
	nums.reserve( count * count );
	for( size_t i = 0; i < count; ++i )
		for( size_t k = 0; k < count; ++k )
			if( i != k )
				nums.push_back( temp[i] + temp[k] );

	std::sort( nums.begin( ), nums.end( ) );

	if( !( std::cin >> count ) )
		return -1;

	std::vector<uint32_t> queries;
	for( size_t i = 0; i < count; ++i )
	{
		uint32_t num = 0;
		if( !( std::cin >> num ) )
			return -1;

		std::set<uint32_t> res = query( num, nums );
		if( res.empty( ) )
			continue;

		for( std::set<uint32_t>::const_iterator it = res.begin( ); it != res.end( ); ++it )
			std::cout << ( it != res.begin( ) ? " " : "" ) << *it;
		std::cout << '\n';
	}

	return 0;
}