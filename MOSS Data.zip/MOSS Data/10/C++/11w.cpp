#include <iostream>
#include <algorithm>
#include <string>


#define MAX_Num 1000
#define MAX_Pares 1000000
#define MAX_Perg 1000
using namespace std;

int v[MAX_Num];
int sum[MAX_Pares];
int p[MAX_Perg];

int pesquisabinaria(int low,int high,int cond){
	while (low<high){
		int middle=low+(high-low)/2;
		if (sum[middle]>=cond) high=middle;
		else low=middle+1;
	}
		if (sum[low]<cond) return -1;
			return low;
}

int main(){
	int n,perguntas,k=0;
	
	cin >> n;

	for (int i=0; i < n; i++)
		cin >> v[i];
	
	cin >> perguntas;
	
	for (int i=0;i<perguntas; i++)
		cin >> p[i];
		
		
	for(int i=0;i<n;i++){
		for (int j=i+1;j<n;j++){
			sum[k]=v[i]+v[j];
			k++;
		}
	}
	sort(sum,sum+k);

	for (int i=0;i<perguntas;i++){
		int x=pesquisabinaria(0,k,p[i]);
		
		if (x==-1) cout << sum[k-1]<<endl;
		else if (x==0) cout<<sum[0]<<endl;
		else if (sum[x]==p[i]) cout << sum[x]<<endl;
		else if (sum[x]-p[i]==p[i]-sum[x-1]) cout<< sum[x-1]<<" "<<sum[x]<<endl;
		else if (sum[x]-p[i]<p[i]-sum[x-1]) cout<< sum[x]<< endl;
		else cout<< sum[x-1]<<endl;
	}
	
	return 0;
}