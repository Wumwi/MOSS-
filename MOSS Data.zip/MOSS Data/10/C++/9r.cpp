#include <stdlib.h>
#include <iostream>
#include <cstdio>
#include <algorithm>


using namespace std;

int v[1000];
int somav[1000];
int soma=0;
int pares[1000];
int k=0;

void resolve(int v[],int n){
    
 
    
    for (int i=0; i<n; i++) {
        for (int j=i; j<n-1; j++) {
            pares[k++]=v[i]+v[j+1];
        }

    }
    for (int i=0; i<k; i++) {
        somav[i]=pares[i];
        }
}

int bsearch(int somav[],int low, int high, int key){
    int middle=0;
    while(low<=high){
        middle=low+(high - low)/2;
        if(key==somav[middle]) return middle;
        else if(key<somav[middle]) high=middle-1;
        else low=middle+1;

    }
    
    return middle;
}


int main(){
    int n,np,x;
    cin >> n;
    
    for (int i=0; i<n ; i++) {
        cin >> v[i];
    }
    cin >> np;
    int vp[np];
    for (int i=0; i<np ; i++) {
        cin >> vp[i];
    }
  
    sort(v, v+n);
    resolve(v,n);
    sort(somav,somav+k);
  
    for (int i=0; i<np; i++) { //ajudado na procura do valor minimo pelo colega Pedro Emanuel.
        x=bsearch(somav,0,k-1,vp[i]);
        if(somav[x]==vp[i])
            cout << somav[x] <<endl;
        else if ((abs(somav[x-1]-vp[i]) < abs(somav[x]-vp[i])) && x-1>=0 && x-1<k)
        {
            x= x-1;
            cout << somav[x]<< endl;
        }
        else if ((abs(somav[x]-vp[i]) > abs(somav[x+1]-vp[i])) && x+1<k && x+1>=0 )
        {
            x= x+1;
            cout << somav[x]<< endl;
        }
        else if((abs(somav[x]-vp[i]) == abs(somav[x-1]-vp[i])) && x-1>=0 && x-1<k && somav[x]!=somav[x-1])
            cout << somav[x-1] << " " << somav[x] <<endl;
        else if((abs(somav[x]-vp[i]) == abs(somav[x+1]-vp[i])) && x+1>=0 && x<k && x+1<k && somav[x]!= somav[x+1]){
            cout << somav[x] << " " << somav[x+1] <<endl;}
     
  
        else cout << somav[x] << endl;
    }

}