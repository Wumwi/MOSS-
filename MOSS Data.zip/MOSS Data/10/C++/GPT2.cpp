#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;

int main() {
    int N;
    cin >> N;

    vector<int> S(N);
    for (int i = 0; i < N; i++) {
        cin >> S[i];
    }

    int P;
    cin >> P;
    vector<int> queries(P);
    for (int i = 0; i < P; i++) {
        cin >> queries[i];
    }

    // Sort the array S
    sort(S.begin(), S.end());

    // For each query, use two pointers to find the closest sum
    for (int query : queries) {
        int left = 0, right = N - 1;
        int closestDistance = INT_MAX;
        vector<int> closestSums;

        while (left < right) {
            int sum = S[left] + S[right];
            int distance = abs(sum - query);

            if (distance < closestDistance) {
                closestDistance = distance;
                closestSums = { sum };
            } else if (distance == closestDistance) {
                closestSums.push_back(sum);
            }

            if (sum < query) {
                left++;
            } else {
                right--;
            }
        }

        // Sort and print results
        sort(closestSums.begin(), closestSums.end());
        for (size_t j = 0; j < closestSums.size(); j++) {
            if (j > 0) cout << " ";
            cout << closestSums[j];
        }
        cout << endl;
    }

    return 0;
}
