#include <bits/stdc++.h>

using namespace std;

typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;



void binary_search(vector<int> v,int low,int high,int key ){
	while(low<high){

		int mid = low +(high-low)/2;

		if(v[mid] > key){
			high=mid;
		}
		else{
			low = mid +1;
		}

	}
	//cout<<"----"<<key<<" "<<v[low]<<" "<<v[low-1]<<"----"<<endl;
	if(abs(v[low]-key) ==abs(v[low-1]-key))
		
		cout<<v[low-1]<<" "<<v[low]<<endl;
	else if(abs(v[low]-key) < abs(v[low-1]-key)) 
		cout<<v[low]<<endl;
	else
		cout<<v[low-1]<<endl;

}

int main(int argc, char const *argv[])
{
	int N;

	cin>>N;
	vector<int> v;

	while(N--){
		int tmp;
		cin>>tmp;
		v.push_back(tmp);
	}

	vector<int> sums;
	sums.push_back(INT_MIN);

	for (int i = 0; i < int(v.size()); i++)
	{
		for (int j = i+1; j < int(v.size()); j++)
		{
			sums.push_back(v[i]+v[j]);
		}
	}

	sums.push_back(INT_MAX);

	sort(sums.begin(), sums.end());
	int q;
	cin>>q;


	for (int i = 0; i < q; ++i)
	{
		int tmp;
		cin>>tmp;
		binary_search(sums,0,int(sums.size()),tmp);
	}






	return 0;
}