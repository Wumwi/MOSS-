#include <bits/stdc++.h>

int valor;

int crescente(const void *pointer1, const void *pointer2) {
  return (*(int *)pointer1 - *(int *)pointer2);
}

int pesquisa(int v[], int key, int size) {
  valor = 0;
  int start = 0, middle, end = size;

  if(key < v[0]) return v[0];
  if(key >= v[end - 1]) return v[end - 1];

  while(start <= end) {
    middle = (start + end) / 2;

    if(key == v[middle]) return v[middle];

    else if(key < v[middle] && key > v[middle - 1]) {
	if(key - v[middle - 1] < v[middle] - key) return v[middle - 1];
	else if(key - v[middle - 1] > v[middle] - key) return v[middle];
	else {
	  valor = v[middle - 1];
	  return v[middle];
	}
    }
    
    else if(key < v[middle]) end = middle - 1;
    else start = middle + 1;
  }

  return -1;
}

int main() {
  int n, size=0;

  scanf("%d", &n);
  
  int num[n];
  for(int i=0; i<n; i++) scanf("%d", &num[i]);

  int somas[n*n];
  for(int i=0; i<n; i++) {
    for(int j=0; j<n && i != j; j++) {
      somas[size++] = num[i] + num[j];
    }
  }
  qsort(somas, size, sizeof(int), crescente);
  
  int npesquisas, key;
  scanf("%d", &npesquisas);
  for(int i=0; i<npesquisas; i++) {
    scanf("%d", &key);
    
    int resultado = pesquisa(somas, key, size);
    
    if(valor !=0) printf("%d %d\n", valor, resultado);
    else printf("%d\n", resultado);
  }
  return 0;
}
