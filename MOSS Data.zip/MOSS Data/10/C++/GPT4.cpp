#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <climits>

using namespace std;

int main() {
    int N;
    cin >> N;

    vector<int> S(N);
    for (int i = 0; i < N; i++) {
        cin >> S[i];
    }

    int P;
    cin >> P;
    vector<int> queries(P);
    for (int i = 0; i < P; i++) {
        cin >> queries[i];
    }

    // Store all possible sums
    vector<int> sums;
    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {
            sums.push_back(S[i] + S[j]);
        }
    }

    // Sort sums for binary search
    sort(sums.begin(), sums.end());

    // For each query, find the closest sum using binary search
    for (int query : queries) {
        auto it = lower_bound(sums.begin(), sums.end(), query);
        vector<int> closestSums;
        int closestDistance = INT_MAX;

        if (it != sums.end()) { // Check the upper bound
            int sum = *it;
            int distance = abs(sum - query);
            if (distance < closestDistance) {
                closestDistance = distance;
                closestSums = { sum };
            } else if (distance == closestDistance) {
                closestSums.push_back(sum);
            }
        }
        
        if (it != sums.begin()) { // Check the lower bound
            int sum = *(--it);
            int distance = abs(sum - query);
            if (distance < closestDistance) {
                closestDistance = distance;
                closestSums = { sum };
            } else if (distance == closestDistance) {
                closestSums.push_back(sum);
            }
        }

        // Print results
        sort(closestSums.begin(), closestSums.end());
        for (size_t j = 0; j < closestSums.size(); j++) {
            if (j > 0) cout << " ";
            cout << closestSums[j];
        }
        cout << endl;
    }

    return 0;
}
