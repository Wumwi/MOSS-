#include <stdio.h>
#include <vector>
#include <algorithm>
#include <stdlib.h>
#include <limits.h>

using namespace std;

int bs(int * b, int * e, int q) {
  int * m;
  int min = *b;
  
  while (b <= e) {
    m = b + (e-b)/2;
    if (abs(*m-q) < abs(min-q))
      min = *m;
    
    if (q == *m) return *m;
    else if (q < *m) e = m-1;
    else b = m+1;
  }
  return min;
}

int bs2(int * b, int * e, int q) {
  int * m;
  while (b <= e) {
    m = b + (e-b)/2;
    if (q == *m) return *m;
    else if (q < *m) e = m-1;
    else b = m+1;
  }
  return -1;
}
       
int main (void) {
  int p, n, q;
  scanf("%d", &n);
  int a[n];
  
  for (int i = 0; i < n; i++)
    scanf("%d", a+i);

  int s[n*n], siz = 0;
  for (int i = 0; i < n; i++)
    for (int j = i+1; j < n; j++)
      s[siz++] = a[i]+a[j];
  sort(s, s + siz);

  scanf("%d", &p);
  
  for (int i = 0; i < p; i++) {
    scanf("%d", &q);
    int r1 = bs(s, s + siz, q);
    int r2;

    if (r1 > q)
      r2 = bs2(s, s + siz, r1 - 2*(r1-q));
    else
      r2 = bs2(s, s + siz, r1 + 2*(q-r1));
    
    if (r2 == -1 || r2 == r1)
      printf("%d\n", r1);
    else
      printf("%d %d\n", min(r1, r2), max(r1,r2));
  }
  return 0;
}
