#include <stdio.h>
#include <algorithm>

using namespace std;

int v[2010], arr[1005];

int bs(int a, int b, int c) {    
  while(a < b) {
    int mid = a + (b - a) / 2;
    if(v[mid] >= c) b = mid;
    else a = mid + 1;
  }

  if(v[a] < c) return -1;
  else return a;
}

int main() {
  int N;

  scanf("%d", &N);
  
  for(int i = 0; i < N; i++) scanf("%d", &arr[i]);

  int cnt = 0;

  for(int i = 0; i < N; i++) {
    for(int j = i + 1; j < N; j++) {
      v[cnt++] = arr[i] + arr[j];
    }
  }

  sort(v, v + cnt);

  int P;

  scanf("%d", &P);

  for(int i = 0; i < P; i++) {
    int Pi;
    
    scanf("%d", &Pi);
        
    int ind = bs(0, cnt - 1, Pi);
    if(ind == -1) printf("%d\n", v[cnt - 1]);
    else if(ind == 0) printf("%d\n", v[0]);
    else {
      int a = abs(v[ind] - Pi);
      int b = abs(v[ind - 1] - Pi);
      
      if(a == b) printf("%d %d\n", v[ind - 1], v[ind]); 
      else printf("%d\n", a < b ? v[ind] : v[ind - 1]);
    }
  }
  
  return 0;
}
