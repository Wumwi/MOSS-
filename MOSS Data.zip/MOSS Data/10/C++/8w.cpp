#include <iostream>
#include <algorithm>
#include <stdlib.h>

using namespace std;

int n, p;
int s[1000], pi[1000];

int procurar_pi(int v[], int high, int key)
{
  int low=0, mid=0;
  while (low <= high)
    {
      mid = low + (high-low)/2;
      if (key == v[mid])
	return mid;
      else if (key < v[mid])
	high = mid-1;
      else
	low = mid+1;
    }
  return mid;
}

void solve()
{
  //calcular o numero de somas possiveis
  int a=0;
  for (int i=n; 0<i; i--)
    {
      a += (i-1);
    }

  int somas[a];
  //calcular tds as somas
  int b=a;
  for (int i=0; i<n; i++)
    {
      for (int j=i; j<n-1; j++)
	{
	  somas[b-1] = s[i] + s[j+1];
	  b--;
	}
    }
  
  //ordenar o vetor somas
  sort (somas, somas + a);

  /*
  //imprimir o vetor somas
  for (int i=0; i<a; i++)
    {
      cout << somas[i] << " ";
    }
  cout << endl;
  */  

  for (int i=0; i<p; i++)
    {
      int v_position =  procurar_pi(somas, a-1, pi[i]);

      //cout << "v_position: " << v_position << " " << endl;
      if (somas[v_position] == pi[i])
	cout << somas[v_position];
      
      else if (abs(somas[v_position-1]-pi[i]) < abs(somas[v_position]-pi[i]) && v_position-1 >=0 && v_position-1<a)
	{
	  v_position= v_position-1;
	  cout << somas[v_position];
	}
      else if (abs(somas[v_position]-pi[i]) > abs(somas[v_position+1]-pi[i]) && v_position+1 >=0 && v_position+1<a)
	{
	  v_position= v_position+1;
	  cout << somas[v_position];
	}
      else if (abs(somas[v_position]-pi[i]) == abs(somas[v_position-1]-pi[i]) && v_position-1>=0 && v_position-1<a && somas[v_position] != somas[v_position-1])
	cout << somas[v_position-1] << " " << somas[v_position];
      else if (abs(somas[v_position]-pi[i]) == abs(somas[v_position+1]-pi[i]) && v_position+1 >=0 && v_position+1<a && somas[v_position] != somas[v_position+1])
	cout << somas[v_position] << " " << somas[v_position+1];
      else
	cout << somas[v_position];
      cout << endl;
    }
  
  //cout << procurar_pi(somas, a-1, pi[1]);
  //cout <<  endl;
    

}

int main ()
{
  cin >> n;
  for (int i=0; i<n; i++)
    cin >> s[i];

  cin >> p;
  for (int i=0; i<p; i++ )
    cin >> pi[i];

  solve();
  return 0;
}
