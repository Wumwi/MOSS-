#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;


void binarySearch(vector<int> v, int low, int high, int perg) {
    int middle;
    while (low < high) {
        middle = low+((high-low)/2);
        if(low == middle) {
            if(abs(v[low] - perg) == abs(v[high] - perg))
                cout << v[low] << ' ' << v[high] << endl;
            else if(abs(v[low] - perg) < abs(v[high] - perg))
                cout << v[low] << endl;
            else
                cout << v[high] << endl;
            return;
        }
        if (v[middle] == perg){
            cout << v[middle] << endl;
            return;
        }
        else
            if(perg < v[middle])
                high = middle;
        else
            low = middle;
    }
    cout << v[low] << endl;
    return;
}

vector<int> sum(int s[], int n) {
    vector<int> sum;
    for (int i=0; i<n ; i++) {
        for (int j=i+1; j<n; j++) {
            sum.push_back(s[i]+s[j]);
        }
    }
    return sum;
}

int main() {
    int n, p;

    cin >> n;
    int s[n];

    for (int i=0; i<n; i++) {
        cin >> s[i];
    }

    cin >> p;
    int perg[p];

    for (int i=0; i<p; i++) {
        cin >> perg[i];
    }

    vector<int> somas(sum(s, n));

    sort(somas.begin(), somas.end());

    for (int i=0; i<p; i++) {
        binarySearch(somas, 0, somas.size(), perg[i]);
    }

    return 0;
}
