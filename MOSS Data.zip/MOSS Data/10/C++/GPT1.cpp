#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
#include <unordered_set>

using namespace std;

int main() {
    int N;
    cin >> N;

    vector<int> S(N);
    for (int i = 0; i < N; i++) {
        cin >> S[i];
    }

    int P;
    cin >> P;
    vector<int> queries(P);
    for (int i = 0; i < P; i++) {
        cin >> queries[i];
    }

    // Store all possible sums
    unordered_set<int> sums;
    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {
            sums.insert(S[i] + S[j]);
        }
    }

    // For each query, find the closest sum
    for (int query : queries) {
        int closestDistance = INT_MAX;
        vector<int> closestSums;

        for (int sum : sums) {
            int distance = abs(sum - query);
            if (distance < closestDistance) {
                closestDistance = distance;
                closestSums = { sum };
            } else if (distance == closestDistance) {
                closestSums.push_back(sum);
            }
        }

        // Sort and print results
        sort(closestSums.begin(), closestSums.end());
        for (size_t j = 0; j < closestSums.size(); j++) {
            if (j > 0) cout << " ";
            cout << closestSums[j];
        }
        cout << endl;
    }

    return 0;
}
