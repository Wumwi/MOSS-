#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

//pesquisa binaria
void binarysearch(int somas[],int low,int high,int key){
  int middle;
  //printf("Pesquisa binária com somas[], %d , %d, %d\n",low,high,key);
  while (low < high){
    middle = low + (high-low)/2;
    //printf("%d = low, %d = high, %d = middle, p[i] = %d\n",low,high,middle,key);
    if(somas[middle] >= key)high = middle;
    else low = middle + 1;
  }
  int dist1 = abs(somas[low - 1] - key);
  int dist2 = abs(somas[low] - key);
  if(somas[low] == key)
    cout  << somas[low]<< endl;
  else if(dist1 == dist2)
    cout << somas[low - 1] << " " << somas[low]<< endl;
  else if(dist1 < dist2)
    cout << somas[low - 1]<< endl;
  else
    cout << somas[low]<< endl;
 
}




int main() {
//declaracoes variaveis
int i=0;
int j=0;

int v[1000000];

int p,n;
cin >> n;

int s[n];
for(i=0;i<n;i++)
	cin >> s[i];


//code
//somas
int c=0;
for(i=0;i<n;i++){
	for(j=i+1;j<n;j++)
	{
		v[c++]=s[i]+s[j];
		
	}
}

//ordenar somas
sort(v,v+c);

int ns = ((n * (n - 1))/2);
//leitura p
cin >> p;

int p1[p];
for(i=0;i<p;i++)
	cin >> p1[i];


for(i=0;i<p;i++){
	if (p1[i] < v[0])
		cout  << v[0]<< endl;
	else if (v[ns - 1] < p1[i])
		cout << v[ns - 1]<< endl;
	else binarysearch(v ,0,ns,p1[i]);

	}

	

  return 0;
}
