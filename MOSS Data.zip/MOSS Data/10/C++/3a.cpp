#include<bits/stdc++.h>
#include<climits>


using namespace std;

int main(){
  
  int n,p;
  vector<int> s,pi,sum;

  cin >> n;
  s.reserve(n);
  for(int i=0; i<n; i++){

    int tmp;
    cin >> tmp;
    s.push_back(tmp);
    
  }
    
  cin >> p;
  pi.reserve(p);
  for(int i=0; i<p; i++){
    int tmp;
    cin >> tmp;
    pi.push_back(tmp);
    
  }
  
  for(int i=0; i<n; i++){
    for(int j=i+1; j<n; j++){
      
      sum.push_back(s[i]+s[j]);
            
    }
  }

  sum.push_back(INT_MIN/2);
  sum.push_back(INT_MAX/2);

  std::sort(sum.begin(), sum.end());
  
  for(int i=0; i<p; i++){
    for(int j=1; j<int (sum.size()); j++){
      
      if(sum[j]>=pi[i]){
	int dist1 = sum[j] - pi[i];
	int dist2 = pi[i] - sum[j-1];	
	
	if(dist1>dist2){
	  cout << sum[j-1] << "\n";
	}else if(dist1<dist2){
	  cout << sum[j] << "\n";
	}else if(dist1==dist2){
	  cout << sum[j-1] << " " << sum[j] << "\n";
	}
	break;
      }
    }
  }
  
  return 0;
}
