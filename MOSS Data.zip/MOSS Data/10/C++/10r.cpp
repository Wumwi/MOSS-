#include <iostream>
#include <algorithm>

using namespace std;

int n,k;
int v[20],pares[20],somas[1000000],p[20000];

int q;

//----------------------------------------------------

int bsearch(int somas[],int low, int high,int key){
  int middle=0;
  while(low <= high)
    middle = low + (high-low)/2;
  if(key == somas[middle])
    return middle;
  else if(key < somas[middle])
    high=middle-1;
  else
    low=middle+1;
  return -1;
  
}

//------------------------------------------------------

int main(){
  int a;
  
  cin >> n;
  for(int i=0;i<n;i++)
    cin >> v[i];
  
  cin >> k;
  for(int j=0;j<k;j++)
    cin >> pares[j];

  for(int x=0;x<n;x++){
    for(int y=0;y<n;y++){
      somas[a]=v[x]+v[y+1];
      a++;
    }
  }

  sort(somas,somas+(a-1));
  
  for(int i=0;i<a-1;i++){
    q=bsearch(somas,0,a-1,pares[i]);
    if(somas[i]==pares[i])
      cout << somas[i] << " ";
    else
      if(abs(somas[i]-q) < abs(somas[i+1] - q) && i+1<a-1)
	cout << somas[i] << " ";
      
  }
  cout << endl;
}
  
