//------------------------
/* INPUT
6
12 3 17 5 34 33
4
1 51 41 21
*/
//--------------------------
#include <iostream>
#include <algorithm>

#define MAX 1000000
using namespace std;

int v[MAX], somasPares[MAX], perg[MAX], k = 0;

void somas(int n) // calculo das somas
{
   
   for(int i = 0; i < n; i++){
   	for(int j = i+1; i < n; j++){
   		somasPares[k] = v[i] + v[j];
   		k++;
	   }
   }
}

struct compareSomas{
	bool operator() (const int i, const int j){
		if(i <= j)	return true;
		else	return false;
	}
};

int binsearch(int low, int high, int key){
	int mid;
	while(low < high){
		mid = low + (high-low) / 2;
		if(somasPares[mid] >= key) 	high = mid;
		else					low=mid+1;
	}
	
	if(key>somasPares[low]) return -1;
	
	return low;
}

int main(){
	int n, p, indiceSoma;
	
	cin >> n;
	
	for(int i=0; i<n; i++)	
		cin >> v[i];
		
	cin >> p;
	
	for(int i=0; i<p; i++)
		cin >> perg[i];
	
	somas(n);
	
	sort(somasPares, somasPares+k, compareSomas());
	
	for(int i=0; i < p; i++){
		indiceSoma = binsearch(0, k, perg[i]);
		
		if (indiceSoma == -1)																cout << somasPares[k-1] << endl;
		else if (indiceSoma == 0)															cout << somasPares[0] << endl;
		else if (somasPares[indiceSoma] == perg[i])											cout << somasPares[indiceSoma] << endl;
		else if (somasPares[indiceSoma] - perg[i] == perg[i] - somasPares[indiceSoma-1]) 	cout << somasPares[indiceSoma-1] << ' ' << somasPares[indiceSoma] << endl;
		else if (somasPares[indiceSoma] - perg[i] < perg[i] - somasPares[indiceSoma-1])  	cout << somasPares[indiceSoma] << endl;
		else 																				cout << somasPares[indiceSoma-1] << endl;
		
	}
		
	return 0;
}
