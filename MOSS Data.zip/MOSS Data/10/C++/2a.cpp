#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <vector>

using namespace std;

int search(int lo, int hi, int key, const vector<int> &v)
{
    while(lo != hi-1) // stop at size 2 gap
    {
		int mid = lo+((hi-lo)/2);
	
		if(v[mid] <= key)
			lo = mid;
		else
			hi = mid;
    }

    return (abs(v[lo]-key) <= abs(v[hi]-key)) ? lo : hi;
}

void answer(int key, const vector<int> &v)
{
    int pos = search(0, v.size()-1, key, v);

    cout << v[pos];
	int dist = abs(v[pos]-key);
	for(int i=pos+1; i<(int)v.size() && v[i]!=v[i-1] && abs(v[i]-key) == dist; ++i)
		cout << " " << v[i];

    cout << endl;
}

int main()
{
    int N, P, num;
    vector<int> nums, sums;

    cin >> N;
    for(int i=0; i<N; ++i)
    {
		cin >> num;
		nums.push_back(num);
    }

    // generate & sort sums
    for(int i=0; i<N; ++i)
	for(int j=i+1; j<N; ++j)
	    sums.push_back(nums[i]+nums[j]);

    sort(sums.begin(), sums.end());
    
    cin >> P;
    for(int i=0; i<P; ++i)
    {
		cin >> num;
		answer(num, sums);
    }
    
    return 0;
}
