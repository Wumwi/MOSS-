#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <climits>

using namespace std;

int main() {
    int N;
    cin >> N;

    vector<int> S(N);
    for (int i = 0; i < N; i++) {
        cin >> S[i];
    }

    int P;
    cin >> P;
    vector<int> queries(P);
    for (int i = 0; i < P; i++) {
        cin >> queries[i];
    }

    // Store sums in a frequency map
    unordered_map<int, int> sumCount;
    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {
            sumCount[S[i] + S[j]]++;
        }
    }

    // Extract unique sums into a vector
    vector<int> uniqueSums;
    for (const auto &entry : sumCount) {
        uniqueSums.push_back(entry.first);
    }

    // Sort the unique sums
    sort(uniqueSums.begin(), uniqueSums.end());

    // For each query, find the closest sum
    for (int query : queries) {
        int closestDistance = INT_MAX;
        vector<int> closestSums;

        for (int sum : uniqueSums) {
            int distance = abs(sum - query);
            if (distance < closestDistance) {
                closestDistance = distance;
                closestSums = { sum };
            } else if (distance == closestDistance) {
                closestSums.push_back(sum);
            }
        }

        // Print results
        for (size_t j = 0; j < closestSums.size(); j++) {
            if (j > 0) cout << " ";
            cout << closestSums[j];
        }
        cout << endl;
    }

    return 0;
}
