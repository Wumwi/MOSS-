#include <stdio.h>

#define MAX 1000001

void merge(int v[], int start, int middle, int end)
{
  int i, p1, p2, aux[MAX];
  
  p1=start;    
  p2=middle+1;
  i = start;    
  while (p1<=middle && p2<=end)
    {           
      if (v[p1] <= v[p2]) aux[i++] = v[p1++];  
      else                aux[i++] = v[p2++];
    }
  while (p1<=middle) aux[i++] = v[p1++];    
  while (p2<=end)    aux[i++] = v[p2++];
  
  for (i=start; i<=end; i++) v[i] = aux[i]; 
}

void mergesort(int v[], int start, int end)
{
  int middle;
  if (start<end)
    {               
      middle = (start+end)/2;       
      mergesort(v, start, middle);  
      mergesort(v, middle+1, end);  
      merge(v, start, middle, end); 
    }
}



int binsearch(int list[], int lo, int hi, int key)
{
    int mid;
    
    mid = (lo + hi) / 2;
    while ((list[mid+1] == list[mid])&&(mid<hi))
      mid++;   

     if (list[mid] <= key && list[mid+1] > key)
    {
      if(mid==0)
	return list[1];
      
      int a = key-list[mid]; //distancia para tras
      int b = list[mid+1] - key; //distancia para frente
      
      if(a>b) 
	return list[mid+1];
      if(b>a)
	return list[mid];

      else
	{
	  printf("%d ", list[mid]);
	  return list[mid+1];
	}
      
   
      
    }
    
    else if (list[mid] > key)
        return binsearch(list, lo, mid - 1, key);
    
    else if (list[mid] < key)
        return binsearch(list, mid + 1, hi, key);
    else
      return -1;
         
}


int main()
{
  
  int n,p,i,j;
  

  //LER O CONJUNTO S
  scanf("%d", &n);
  int ns[n];
  for(i = 0; i < n; i++)
    scanf("%d", &ns[i]);
  
  int x = ((n*n)+n)/2; //QUANTIDADE DE SOMAS
  int somas[x+1];
  int a = 0;
  somas[a] = 0;
  a++;
  
  //LER O CONJUNTO P
  scanf("%d", &p);
  int ps[p];
  for(i = 0; i < p; i++)
    scanf("%d", &ps[i]);


  //CALCULAR SOMAS
  for(i = 0; i < n; i++)
    for( j = i + 1; j < n; j++)
      {
	somas[a] = ns[i]+ns[j];
	a++;
      }
  somas[a] = MAX;
  
  //ORDENAR SOMAS
  mergesort(somas, 0, a-1);

  //IMPRIMIR SOMAS
  /*
  printf("%d\n",a);
  for( i = 0; i <= a; i++)
    printf("%d ",somas[i]);
  printf("\n");
  */

  //PROCESSAR
  for(i = 0; i < p; i++)
    {
      int c = binsearch(somas,0,a,ps[i]);
      printf("%d\n",c);
    }

  
  return 0;
}
