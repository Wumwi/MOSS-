#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int compare(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

int main() {
    int N, P;
    scanf("%d", &N);
    
    int S[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &S[i]);
    }

    // Sort the array S
    qsort(S, N, sizeof(int), compare);
    
    scanf("%d", &P);
    int queries[P];
    for (int i = 0; i < P; i++) {
        scanf("%d", &queries[i]);
    }

    // For each query, use two pointers to find closest sum
    for (int i = 0; i < P; i++) {
        int target = queries[i];
        int left = 0, right = N - 1;
        int closestDistance = INT_MAX;
        int closestSums[N * (N - 1) / 2];
        int closestCount = 0;

        while (left < right) {
            int sum = S[left] + S[right];
            int distance = abs(sum - target);

            if (distance < closestDistance) {
                closestDistance = distance;
                closestCount = 0;
                closestSums[closestCount++] = sum;
            } else if (distance == closestDistance) {
                closestSums[closestCount++] = sum;
            }

            if (sum < target) {
                left++;
            } else {
                right--;
            }
        }

        // Sort closest sums
        qsort(closestSums, closestCount, sizeof(int), compare);

        // Print results
        for (int j = 0; j < closestCount; j++) {
            if (j > 0) printf(" ");
            printf("%d", closestSums[j]);
        }
        printf("\n");
    }

    return 0;
}
