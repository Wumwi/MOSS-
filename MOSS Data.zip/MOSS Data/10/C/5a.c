#include <stdio.h>
#include <stdlib.h>

void bsearch1(int v[], int low, int high, int key);
int compare_int(const void *a, const void *b) {
  int i1 = *((int *)a);
  int i2 = *((int *)b);

  if (i1 < i2) return -1;
  if (i1 > i2) return +1;
  return 0;
}


int main()
{
  int i, n, p, num_casos=0, j, num_vet=0;

  scanf("%d", &n);
  int s[n];

  for(i=0; i<n; i++)
  {
    scanf("%d", &s[i]);
    num_casos=num_casos+i;
  }

  scanf("%d", &p);
  int t[p];

  for(i=0; i<p; i++)
    scanf("%d", &t[i]);
  
  int vetsoma[num_casos];

  for(i=0; i<n; i++)
  {
    for(j=i+1; j<n; j++)
    {
	vetsoma[num_vet]=s[i]+s[j];
	num_vet++;
    }
  }

  
  qsort(vetsoma, num_casos, sizeof(int), compare_int);
  // printf("\n");
  
  for(i=0; i<p; i++)
   {
     if(i!=0)
       printf("\n");
     bsearch1(vetsoma, 0, num_casos-1, t[i]);

    
   }
   //   printf("*****total = %d\n", num_casos);
   printf("\n");
  return 0;
}



void bsearch1(int v[], int low, int high, int key)
{
	int middle;
	int  k=0;
	while(low <= high)
	{
		middle=low + (high-low)/2;
		//	printf("middle= %d, high= %d, low = %d\n", v[middle], v[high], v[low]);
	        
		if(key==v[middle])
		{
		  
		  printf("%d", v[middle]);
		  k=1;
		  break;
		}
		else if(key<v[middle] && middle > 0)
			high=middle-1;
		else
			low=middle+1;

		//printf("middle= %d, high= %d, low = %d\n", middle, v[high], v[low]);
		
	}
	if(k == 0)
	{
		
		if(abs(key - v[low]) == abs(key - v[high]))
			printf("%d %d", v[high], v[low]);
		else if(abs(key - v[low]) < abs(key - v[high]))
			printf("%d", v[low]);
		else
			printf("%d", v[high]);
	}

	 
	
}

