#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

typedef struct {
    int value;
    int distance;
} Pair;

int compare(const void *a, const void *b) {
    Pair *pairA = (Pair *)a;
    Pair *pairB = (Pair *)b;
    if (pairA->distance == pairB->distance) {
        return pairA->value - pairB->value;
    }
    return pairA->distance - pairB->distance;
}

int main() {
    int N, P;
    scanf("%d", &N);
    
    int S[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &S[i]);
    }

    scanf("%d", &P);
    int queries[P];
    for (int i = 0; i < P; i++) {
        scanf("%d", &queries[i]);
    }

    // Store all possible sums
    Pair sums[N * (N - 1) / 2];
    int k = 0;

    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {
            sums[k].value = S[i] + S[j];
            sums[k].distance = 0; // Initialize distance
            k++;
        }
    }

    // For each query, find the closest sum
    for (int i = 0; i < P; i++) {
        int target = queries[i];
        int closestDistance = INT_MAX;
        int closestSums[N * (N - 1) / 2];
        int closestCount = 0;

        for (int j = 0; j < k; j++) {
            sums[j].distance = abs(sums[j].value - target);
            if (sums[j].distance < closestDistance) {
                closestDistance = sums[j].distance;
                closestCount = 0;
                closestSums[closestCount++] = sums[j].value;
            } else if (sums[j].distance == closestDistance) {
                closestSums[closestCount++] = sums[j].value;
            }
        }

        // Sort closest sums
        qsort(closestSums, closestCount, sizeof(int), compare);

        // Print results
        for (int j = 0; j < closestCount; j++) {
            if (j > 0) printf(" ");
            printf("%d", closestSums[j]);
        }
        printf("\n");
    }

    return 0;
}
