#include <stdio.h>
#include <stdlib.h>

int compare (const void *a, const void *b) {
  int i1 = *((int *)a);
  int i2 = *((int *)b);
  if (i1>i2) return 1;
  else return -1;
}

int binproc(int somas[],int low,int high,int key,int melhor){
  if (low>=high){if (abs(key-somas[low])<abs(key-somas[melhor]))return low; else return melhor;}
  int mid=(high+low)/2;
  if (somas[mid]==key) return mid;
  if (melhor==-1) melhor=mid;
  else if (abs(key-somas[mid])<abs(key-somas[melhor]))melhor=mid;
  if (somas[mid]>key) return binproc(somas,low,mid,key,melhor);
  else return binproc(somas,mid+1,high,key,melhor);
 
}

void checkesq(int somas[],int r,int p){
  if (r==0)return;
  else if(somas[r-1]!=somas[r]){
    if (abs(somas[r-1]-p)==abs(somas[r]-p))
      printf("%d ",somas[r-1]);
  }
  else {checkesq(somas,r-1,p);}
}
void checkdir(int somas[],int r,int p,int tam){
  if (r==tam)return;
  if(somas[r+1]!=somas[r]){
    if (abs(somas[r+1]-p)==abs(somas[r]-p))
      printf(" %d",somas[r+1]);
  }
  else {checkdir(somas,r+1,p,tam);}
}
int main(){
  int n,nsomas=0,nperguntas,i,j,k=0;
  scanf("%d",&n);
  int numeros[n];
  for(i=0;i<n;i++){
    scanf("%d",&numeros[i]);
  }
  for(i=1;i<n;i++){
    nsomas+=i;
  }
  int somas[nsomas];
  for(i=0;i<n-1;i++){
    for(j=i+1;j<n;j++){
      somas[k]=numeros[i]+numeros[j];
      k++;
    }
  }
  qsort(somas,nsomas,sizeof(int),compare);
  scanf("%d",&nperguntas);
  int perguntas[nperguntas];
  int respostas[nperguntas];
  for(i=0;i<nperguntas;i++){
    scanf("%d",&perguntas[i]);
    respostas[i]=binproc(somas,0,nsomas-1,perguntas[i],-1);
  }
  for(i=0;i<nperguntas;i++){
    checkesq(somas,respostas[i],perguntas[i]);
    printf("%d",somas[respostas[i]]);
    checkdir(somas,respostas[i],perguntas[i],nsomas-1);
    putchar('\n');
  }
  return 0;
}
