#include<stdio.h>
#include<math.h>
#include<stdlib.h>

void merge (int v[], int start, int middle,int end){
  int aux_size=end-start+1;
  int aux[aux_size];
  int a=start,b=middle+1,i;

  for(i=0;i<aux_size; i++){
    if(a>middle){
      aux[i]=v[b];
      b++;
    }
    else if (b>end){
      aux[i]=v[a];
      a++;
    }
    else if (v[b]>v[a]){
      aux[i]=v[a];
      a++;
    }
    else{
      aux[i]=v[b];
      b++;
    }
  }
  for(i=0, a=start; i<aux_size; i++,a++){
    v[a]=aux[i];
  }
}

void mergesort(int v[], int start, int end, int size){
  int middle = (start+end)/2;
  if(start<end){
    mergesort(v, start, middle,size);
    mergesort(v, middle+1, end,size);
    merge(v, start, middle, end);
  }
}


typedef struct Somas {
 int conta1;
 int conta2;
 int dist_final;
}SOMA;

SOMA resultado (int v[],int p,int size){
	SOMA resultado;
	int i=0,j,conta,dist;
	int proximo;
	//numero inferior mais proximo de p
	for(i=0;i<size;i++){
		if(v[i]<p)
		proximo=i;
		else if (i==0){
			proximo=i;
			resultado.conta1=v[i]+v[i+1];
			resultado.conta2=-1;
			break;
		}
		else
			break;
		//printf("o proximo e %d\n",proximo);
	}
	i=0;
	resultado.dist_final=p+p;
	j=proximo;
	resultado.conta2=-1;
	while(j>i){
		conta=v[j]+v[i];
		if(conta>p){
			dist=conta-p;
			if(dist<resultado.dist_final){
				resultado.dist_final=dist;
				resultado.conta1=conta;
			}
			else if (dist==resultado.dist_final){
				resultado.conta2=conta;
			}
			j--;
		}
		else{
			dist=p-conta;
			if(dist<resultado.dist_final){
				resultado.dist_final=dist;
				resultado.conta1=conta;
			}
			else if (dist==resultado.dist_final){
				resultado.conta2=conta;
			}
			i++;
		}
	}
	return resultado;
}

int main(){
	int n,i;
	scanf("%d",&n);
	int v[n];
	for(i=0;i<n;i++){
		scanf("%d",&v[i]);
	}
	mergesort(v,0,n-1,n);
	//vector já ordenado
	int np;
	scanf("%d",&np);
	int p;
	while(np!=0){
		scanf("%d",&p);
		//função que descobre a melhor soma
		SOMA res;
		res=resultado (v,p,n);
		if(res.conta2!=-1){
			printf("%d %d\n",res.conta1,res.conta2);
		}
		else{
			printf("%d\n",res.conta1);
		}
	}
	return 0;
}
