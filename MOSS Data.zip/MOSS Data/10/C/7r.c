#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main(){
  int n[999], s, p, pi[999],i, max=0,min=1000000,j,k,min2=1000000,max2=0,flag=0;
  scanf("%d", &s);
  for(i=0;i<s;i++){
    scanf("%d", &n[i]);
  }
  scanf("%d", &p);
  if(p>=1||p<=1000){
  for(i=0;i<p;i++){
    scanf("%d", &pi[i]);
  }
  for(k=0;k<p;k++){
    for(i=0;i<s-1;i++){
      for(j=i+1;j<s;j++){
	if(abs(pi[k]-(n[i]+n[j]))==min){
	  min2=min;
	  max2=(n[i]+n[j]);flag=1;}
	if(abs(pi[k]-(n[i]+n[j]))<min){
	  max=(n[i]+n[j]);
	  min=(abs(pi[k]-(n[i]+n[j])));
	}
      }
    }
    if(flag==0)
    printf("%d\n", max);
    else{
      if(max<max2)
      printf("%d %d\n", max, max2);
      else
	printf("%d %d\n", max2, max);}
    min=1000000;max=0;min2=1000000;max2=0;
  }
  }
  return 0;
  }
