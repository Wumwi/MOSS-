#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX_SUMS 500000

typedef struct {
    int sums[MAX_SUMS];
    int count;
} SumSet;

void add_sum(SumSet *set, int sum) {
    for (int i = 0; i < set->count; i++) {
        if (set->sums[i] == sum) return; // Avoid duplicates
    }
    set->sums[set->count++] = sum;
}

int compare(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

int main() {
    int N, P;
    scanf("%d", &N);
    
    int S[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &S[i]);
    }

    scanf("%d", &P);
    int queries[P];
    for (int i = 0; i < P; i++) {
        scanf("%d", &queries[i]);
    }

    SumSet sumSet = { .count = 0 };
    
    // Generate all sums of two different numbers
    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {
            add_sum(&sumSet, S[i] + S[j]);
        }
    }

    // Sort the unique sums
    qsort(sumSet.sums, sumSet.count, sizeof(int), compare);

    // For each query, find the closest sum
    for (int i = 0; i < P; i++) {
        int target = queries[i];
        int closestDistance = INT_MAX;
        int closestSums[MAX_SUMS];
        int closestCount = 0;

        for (int j = 0; j < sumSet.count; j++) {
            int distance = abs(sumSet.sums[j] - target);
            if (distance < closestDistance) {
                closestDistance = distance;
                closestCount = 0;
                closestSums[closestCount++] = sumSet.sums[j];
            } else if (distance == closestDistance) {
                closestSums[closestCount++] = sumSet.sums[j];
            }
        }

        // Print results
        for (int j = 0; j < closestCount; j++) {
            if (j > 0) printf(" ");
            printf("%d", closestSums[j]);
        }
        printf("\n");
    }

    return 0;
}
