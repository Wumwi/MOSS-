#include <stdio.h>
#include <stdlib.h>
#define MAX 1000

int compare_int(const void *a, const void *b) {
  int i1 = *((int *)a);
  int i2 = *((int *)b);
  
  if (i1 < i2) return -1;
  if (i1 > i2) return +1;
  return 0;
}



void binarysearch(int somas[],int low,int high,int key){
  int middle;
  //printf("Pesquisa bin�ria com somas[], %d , %d, %d\n",low,high,key);
  while (low < high){
    middle = low + (high-low)/2;
    //printf("%d = low, %d = high, %d = middle, p[i] = %d\n",low,high,middle,key);
    if(somas[middle] >= key)high = middle;
    else low = middle + 1;
  }
  int dist1 = abs(somas[low - 1] - key);
  int dist2 = abs(somas[low] - key);
  if(somas[low] == key)
    printf("%d\n",somas[low]);
  else if(dist1 == dist2)
    printf("%d %d\n", somas[low - 1],somas[low]);
  else if(dist1 < dist2)
    printf("%d\n", somas[low - 1]);
  else
    printf("%d\n",somas[low]);
  return;
}



int main () {
  int n ,i ,p ,j ;
  scanf("%d", &n);
  int s[n];
  for(i=0; i<n; i++){
    scanf("%d", &s[i]);
  }

  int numero_somas = ((n * (n - 1))/2);
  int somas[numero_somas];
  int posicao = 0;
  for(i=0; i<n; i++){
    for(j=i+1; j<n; j++){
      somas [posicao] = s[i] + s[j];
      posicao++;
    }
  }
  
  qsort(somas,numero_somas,sizeof(int),compare_int);
  scanf("%d", &p);
  int pi[p];
  for(i=0; i<p; i++){
    scanf("%d", &pi[i]);
    if(pi[i] < somas[0])
      printf("%d\n",somas[0]);
    else if(somas[numero_somas - 1] < pi[i])
      printf("%d\n",somas[numero_somas - 1]);
    else
      binarysearch(somas,0,numero_somas,pi[i]);
  }
  return 0;
}



