//Tive a ajuda da Cristiana Morais

#include <stdio.h>
#include <stdlib.h>
 
int compare_int(const void *a, const void *b) {
    int i1 = *((int *)a);
    int i2 = *((int *)b);
   
    if (i1 < i2) return -1;
    if (i1 > i2) return +1;
    return 0;
}
 
 
int bisearch(int low,int high,int p,int pares[]) {
    int middle;
    while (low < high) {
        middle = low + (high - low)/2;
        if (pares[middle] >= p) high = middle;
        else low = middle + 1;
    }
    if (pares[low] < p) return -1;
    return(low);
}
 
int compare(int pares[],int x,int p) {
    if (pares[x] == p)
        return p;
    else if (x==0)
        return pares[0];
    else {
        if (pares[x] - p > p - pares[x-1])
            return pares[x-1];
        else if (pares[x] - p < p - pares[x-1])
            return pares[x];
    }
    return 0;
}
 
int main() {
  
    int N,i,j,k=0,y,p,x,res;
    int Ni;
    
    scanf("%d",&N);
    
    Ni = (N*(N-1))/2;
    
    int v[N],pares[Ni];
    for (i = 0 ; i < N ; i++){
        scanf("%d",&v[i]);
    }
    
    for (i = 0 ; i < N-1 ; i++){
        for (j = i+1 ; j < N ; j++) {
            pares[k] = v[i] + v[j];
            k++;
        }
    }
    
    qsort(pares,Ni,sizeof(int),compare_int);
    
    scanf("%d",&y);
    
    for (i = 0 ; i < y ; i++) {
        scanf("%d",&p);
	
        if (p >= pares[Ni-1]) {
            x = pares[Ni-1];
            printf("%d\n",x);
        }
	
        else if (p <= pares[0]){
            printf("%d\n",pares[0]);
        }
	
        else {
            x = bisearch(0,Ni-1,p,pares);
            if (pares[x] - p == p - pares[x-1] && pares[x-1] != pares[x]){
                printf("%d %d\n",pares[x-1],pares[x]);
            }
	    
            else if (pares[x+1] - p == p - pares[x] && pares[x+1] != pares[x]){
                printf("%d %d\n",pares[x],pares[x+1]);
            }
	    
            else {
                res = compare(pares,x,p);
                printf("%d\n",res);
            }
        }
    }
    
    return 0;
}
