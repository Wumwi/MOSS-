#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {
    int N, P;
    scanf("%d", &N);
    
    int S[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &S[i]);
    }
    
    scanf("%d", &P);
    int queries[P];
    for (int i = 0; i < P; i++) {
        scanf("%d", &queries[i]);
    }

    // Array to store all possible sums
    int sums[N * (N - 1) / 2];
    int k = 0;
    
    // Generate all sums of two different numbers
    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {
            sums[k++] = S[i] + S[j];
        }
    }

    // For each query, find the closest sum
    for (int i = 0; i < P; i++) {
        int target = queries[i];
        int closestDistance = INT_MAX;
        int closestSums[N * (N - 1) / 2];
        int closestCount = 0;

        for (int j = 0; j < k; j++) {
            int distance = abs(sums[j] - target);
            if (distance < closestDistance) {
                closestDistance = distance;
                closestCount = 0;
                closestSums[closestCount++] = sums[j];
            } else if (distance == closestDistance) {
                closestSums[closestCount++] = sums[j];
            }
        }

        // Sort the closest sums
        qsort(closestSums, closestCount, sizeof(int), (int (*)(const void *, const void *)) strcmp);
        
        // Print results
        for (int j = 0; j < closestCount; j++) {
            if (j > 0) printf(" ");
            printf("%d", closestSums[j]);
        }
        printf("\n");
    }

    return 0;
}
