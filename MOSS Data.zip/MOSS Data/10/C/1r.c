#include <stdio.h>
// procura_dif(soma,vpesq,vencontra)
 void procura_dif(int v[],int n, int pesq, int dif){
   int i;
   int valm=pesq-dif;
   int valM=pesq+dif;
   for(i=0;i<n;i++){
     if(v[i]==valm)
       printf("%d ",v[i]);
     else if(v[i]==valM)
       printf("%d ",v[i]);
   } 
 }


int pesbin( int vet[], int low, int high, int key){
  int dif=10000;
  int mdif=1000;
  int meio;
  while(low<=high){
    meio=low+(high-low)/2;
    if(key==vet[meio]){
      return vet[meio];
    }

    else if(key<vet[meio]){
      high=meio-1;
      dif=vet[meio]-key;//
      if(dif<mdif)//
	mdif=dif;//

    }
    else{
      low=meio+1;
      dif=key-vet[meio];//
      if(dif<mdif)//
	mdif=dif;//
    }
  }
  return mdif;
    
  
}

void merge(int v[], int start, int middle, int end){
  int pe, pd, paux, aux[end-start+1];

  pe = start;
  pd = middle+1;
  paux = 0;

  while (pe <= middle && pd<=end) {
    if (v[pe] < v[pd]) {
      aux[paux] = v[pe];
      paux++;
      pe++;
    } 
    else {
      aux[paux] = v[pd];
      paux++;
      pd++;
    }
  }

  // copiar o resto

  while(pe<=middle){
    aux[paux]=v[pe];
    paux++;
    pe++;
  }
  
  while(pd<=end){
    aux[paux]=v[pd];
    paux++;
    pd++;
  }
	  
  // copiar aux para v

  int i;
  for(i=start;i<=end;i++)
    v[i]=aux[i-start];
}
 

void mergesort(int v[], int start, int end){
  int middle=(start+end)/2;
  if (start<end){
    mergesort(v,start,middle);
    mergesort(v,middle+1,end);
    merge(v,start,middle,end);
  }
}



int main(){

  int i,j,n,np;
  scanf("%d",&n);
  int num[n];
  for(i=0;i<n;i++)
    scanf("%d",&num[i]);

  scanf("%d",&np);
  int nump[np];
  for(i=0;i<np;i++)
    scanf("%d",&nump[i]);

  //calcular tamanho vetor
  int valor=0;
  for(i=1;i<n;i++)
    valor+=(n-i);
  //calcular a soma de todos os pares
  int soma[valor];
  int ind=0;
  for(i=0;i<n;i++)
    for(j=i+1;j<n;j++){
      soma[ind]=num[i]+num[j];
      ind++;
    }

  mergesort(soma,0,ind-1);

  for(i=0;i<valor;i++)
    printf("%d ",soma[i]);
  printf("\n");


  int vpesq=0;
  int vencontr=0;
  for(i=0;i<np;i++){
    vpesq=nump[i];
    vencontr=pesbin(soma,0,valor,vpesq);
    if(vpesq==vencontr)
      printf("%d\n",vpesq);
    else {
      procura_dif(soma,valor,vpesq,vencontr);
      printf("\n");
    }
  }

  return 0;
}
