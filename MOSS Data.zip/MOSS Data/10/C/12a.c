#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
int intcmp (const void *aa, const void *bb){
	const int *a = aa, *b = bb;
	return (*a < *b) ? -1 : (*a > *b);
}

void binsearch(long t, long sums[], int search){
	long sol;
	bool exception=false;
	if(t>0){
		
		// then do a binary search with each query in sums[]
		int first = 0, last = t-1;
		int middle = (first+last)/2;
		while(first<=last){
			if(sums[middle]<search){
				sol = first;
				first = middle+1;
			}
			else if(sums[middle]==search){
				sol = middle;
				break;
			}
			else{
				last = middle-1;
				sol = middle;
			}
			middle = (first+last)/2;
		}
		if(abs(search-sums[sol-1]) < abs(search-sums[sol]))
			sol--;
	}
	else
		sol=0;
	if(abs(search-sums[sol+1]) < abs(search-sums[sol]))
		sol++;
	if(sums[sol] != search){ //if there's another number at the same distance from search as sol, write it too
		if((abs(search-sums[sol])==abs(search-sums[sol-1])) && sums[sol]!=sums[sol-1])
			printf("%ld ",sums[sol-1]);
	    else if((abs(search-sums[sol])==abs(search-sums[sol+1])) && sums[sol]!=sums[sol+1])
			exception=true;
	}
	if (exception)
		printf("%ld %ld",sums[sol], sums[sol+1]);
	else
		printf("%ld",sums[sol]);
	printf("\n");
}

int main(){
	int i, k, search;
	long n, m;
	scanf("%ld",&n);
	long array[n];
	for(i=0; i<n; i++)
		scanf("%ld",&array[i]);
	scanf("%ld",&m);
	long queries[m];
	for(i=0; i<m; i++)
		scanf("%ld",&queries[i]);
	
	long t = n*((n-1)/2.0), counter=0;	
	long sums[t];
	for(i=0;i<t;i++)
		sums[i]=0;	
	for(i=0; i<n; i++)
			for(k=i+1; k<n; k++)
				sums[counter++] = array[i] + array[k];
	// now that we have an array with all the possible pair sums, let's sort it
	qsort(sums, t, sizeof(long), intcmp);
		
	for(i=0; i<m; i++){
		search = queries[i];
		binsearch(t, sums, search);
	}
		
	return 0;
}