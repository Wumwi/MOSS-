#include <stdio.h>

#include <stdlib.h>
#include <string.h>
int mycmp(const void *p11, const void *p22){
  const int *a=p11 ,*b=p22;
  if(*a<*b) return -1;
  if(*a>*b) return 1;
  return 0;
}

void geracombos(int nc,int gc[], int ninteiros[],int max){
  int i,k,c=0;
  for(i=0;i<max;i++){
    for(k=i+1;k<max;k++){
      gc[c]=ninteiros[i]+ninteiros[k];
      c++;
    }
  }
}

void binarySearch(int vet[], int chave, int Tam){
     
  int inf = 0;
     int sup = Tam-1;  
     int meio;
     
     while (inf <= sup) {
          meio = (inf + sup)/2;
          if (chave == vet[meio]){
	    printf("%d\n",vet[meio]);
	      return ;}
          else if (chave < vet[meio]){
	    sup = meio-1;}
          else{
	    inf = meio+1;}
     }
     	if(abs(vet[sup]-chave)<abs(vet[inf]-chave)) {printf("%d\n", vet[sup]); return;}
	if(abs(vet[sup]-chave)>abs(vet[inf]-chave)) {printf("%d\n", vet[inf]); return;}
	printf("%d %d\n", vet[sup], vet[inf]);
  }





int main(){
  int i,s,p;
  int nc;
  scanf("%d",&s);
  int ninteiros[s];
  for(i=0;i<s;i++){scanf("%d",&ninteiros[i]);}
  
  scanf("%d",&p);
  int np[p];
  for(i=0;i<p;i++){scanf("%d",&np[i]);}
 
  nc=s*(s-1)/2;
  int gc[nc];
  geracombos(nc,gc,ninteiros,s);
  qsort(gc,nc,sizeof(int),mycmp);
  
  for(i=0;i<p;i++){
    binarySearch(gc,np[i],nc);
  }
  
  return 0;

}
