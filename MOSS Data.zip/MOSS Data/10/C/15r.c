#include <stdio.h>
#include <stdlib.h>


int compare_int(const void *a, const void *b) {

  int i1 = *((int *)a);
  int i2 = *((int *)b);

  if (i1 < i2) return -1;
  if (i1 > i2) return +1;
  return 0;
}

int resposta(int a,int b,int array[]){
	int first=0,last,middle;
	last= b-1;
	middle=((first+last)/2);
		
	while (first < last){

		if (array[middle] == a){
			return a;
			break;
		}
		else if (array[middle] > a)
			last = middle;
		else {
			first = middle + 1;
		}
		middle = ((first + last) / 2);
	}
		
		if(abs(array[first-1]-a)==abs(array[first]-a)) {
			return array[first-1];
			


		}

		else if (abs(array[first] - a)<abs(array[first-1] - a)){
			return array[first];
		}

		else return array[first-1];
	
			
		
		
	
}

int main (){
	int n1,n2,k=0;
	// nº numeros
	scanf("%d", &n1);
	// array com numeros
	int *numeros=malloc(sizeof(int) * n1);
	
	// variaveis temporarias
	int i,j;
	
	// Guardar no array os numeros
	for(i=0;i<n1;i++)
		scanf("%d",&numeros[i]);
	
	// nº perguntas
	scanf("%d" ,&n2);
	
	// array com perguntas
	int *perguntas=malloc(sizeof(int) * n2);
	
	// Guardar no array as perguntas
	for(i=0;i<n2;i++)
		scanf("%d",&perguntas[i]);
	// nº pares	
	int numeropares;
	numeropares=((n1*(n1-1))/2);
	
	// array de tamanho de nº pares
	int *pares=malloc(sizeof(int) * numeropares);
	
	// Guardar Pares no array
	for(i=0;i<n1-1;i++){
		for(j=i+1;j<n1;j++){
			pares[k]=numeros[i]+numeros[j];
			k++;
				
		}
	}

	qsort(pares, numeropares, sizeof(int), compare_int);
	
	for (i = 0; i < numeropares; i++)
		printf("%d\n", pares[i]);

	for(i=0;i<n2;i++)
	printf("%d\n", resposta(perguntas[i],k,pares));
	

return 0;
}