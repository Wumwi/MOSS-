#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int cmp (const void * elem1, const void * elem2) {
    if (*((int*)elem1) > *((int*)elem2) ) return  1;
    if (*((int*)elem1) < *((int*)elem2) ) return -1;
    return 0;
}

int main(int argc, char** argv) {

	int i, x, x2, j, k, count = 0;

	scanf("%d", &x);

	int array[x];

	for(i = 0; i < x; i++)
		scanf("%d", &array[i]);

	scanf("%d", &x2);

	qsort(array, x, sizeof(int), cmp);

	int l = (x*(x-1))/2;

	int sums[l];

	for(i = 0; i < x; i++) {
		for(j = i+1; j < x; j++) {
			sums[count++] = array[i] + array[j];
		}
	}

	for(i = 0; i < x2; i++) {
		int question;

		scanf("%d", &question);

		int dist = INT_MAX;

		int best[count];

		for (j = 0; j < count; j++) {
			if (sums[j] != 0 && abs(sums[j] - question) <= dist) {
				dist = abs(sums[j] - question);
				best[j] = sums[j];
			}
			else best[j] = 0;
		}

		qsort(best, count, sizeof(int), cmp);

		int printed = 0;
		int last = INT_MAX;
		for(k = 0; k < count; k++){
			if(best[k] != 0 && last != best[k] && dist == abs(best[k] - question)) {
				if(printed == 0) { 
					printf("%d", best[k]);
					printed = 1;
				}
				else
					printf(" %d", best[k]);
				last = best[k];
					
			}
		}
		printf("\n");
	}
	return 0;
}