#include <stdio.h>
#include <math.h>

void pergunta();

int main() {
  int n,i,a[1000000],b[1000000],k;

  scanf("%d",&n);
  for(i=0; i<n; i++){
    scanf("%d", &a[i]);
  }
  scanf("%d",&k);
  for(i=0;i<k;i++){
    scanf("%d",&b[k]);
    pergunta(b[k],a,n);
  }
  return 0;
}

void pergunta(int c, int a[], int n){
  int temp=a[0]+a[1], respostas[3], conta=0,e=0,i=0;
  respostas[0]=temp;
 
  for(i=0; i<n-1; i++){
    for(e=i+1; e<n; e++){
      if(fabs(a[i]+a[e]-c)<fabs(temp-c)){
	temp=a[i]+a[e];
	conta=0;
	respostas[0]=temp;
      }
      if(fabs(a[i]+a[e]-c)==fabs(temp-c) && a[i]+a[e]!=temp){
	if(conta==1 && a[i]+a[e]==respostas[1]) break;
	if(conta==1 && a[i]+a[e]==respostas[0]) break;
	conta++;
	if(a[i]+a[e]<temp)
	  respostas[conta]=a[i]+a[e];
	else{
	  respostas[0]=a[i]+a[e];
	  respostas[1]=temp;
	}
      }
    }
  }

  for(i=conta; i>0; i--){
    printf("%d ",respostas[i]);
  }
  printf("%d\n", respostas[0]);
}
  
