#include <stdio.h>
#include <stdlib.h>

#define N 1000
#define S 1000000

int somav[S], k, n, i, j, v[N], p, per;

int pesquisaBin(int somav[], int key, int begin, int fim){
  int mid = 0;

  while(begin < fim){
    mid = begin + (fim - begin)/2; // partese a meio o vetor Somav
    if(key == somav[mid])
      return key;

    else if(key < somav[mid])// lado esquerdo
      fim = mid;

    else//lado direito
      begin = mid + 1;
  }
  mid = begin;

  //printf("%d !\n", mid);
  
  if(mid > 0){
    if(key - somav[mid-1] < somav[mid] - key)
      return somav[mid - 1];
    if(key - somav[mid - 1] == somav[mid] - key){
      printf("%d ", somav[mid - 1]);
      return somav[mid];
    }
    if(key - somav[mid -  1]> somav[mid] - key)
      return somav[mid];
  }
  return somav[0];
}

int compare_int(const void * a, const void * b){
  return ( *(int*)a - *(int*)b );
}


int main() {
  int res;

  scanf("%d", &n);

  for(i=0; i<n; i++)
    scanf("%d", &v[i]);

  scanf("%d", &per);

  k=0;
  for(i=0; i<n; i++){
    for(j=i+1; j<n; j++){
      somav[k]= v[i] + v[j];
      k++;
    }
  }

  qsort(somav, k, sizeof(int), compare_int);

  /*for(i=0; i<k;i++)
    printf("%d ", somav[i]);
    printf("\n");*/
  
  for(i=0; i<per; i++){
    scanf("%d", &p);
    res = pesquisaBin(somav, p, 0, k-1);
    printf("%d\n", res);
  }

  
  return 0;
}
