#include <stdio.h>
#include <stdlib.h>
int main(void){
	int n,aux,p,i,j,min= 1000000,k,dif,soma,d,c=0;
	scanf("%d",&n);
	int s[n];
	for ( i = 0 ; i < n ; i++) {
		scanf("%d",&s[i]);
	}
	for ( i = 0 ; i < n ; i++) {		/* Ordenar */
		for ( j = i+1 ; j < n ; j ++){
			if ( s[i] > s[j] ) {
				aux = s[i];
				s[i] = s[j];
				s[j] = aux;
			}
		}
	}
	scanf("%d",&p);
	int pi[p];						/* Questoes */
	for ( k = 0 ; k < p ; i++) {
		scanf("%d",&pi[k]);
	for ( i = 0 ; i < n ; i++){
		for ( j = i+1; j < n ; j++){
			soma = s[i]+s[j];
			dif = abs( pi[k]-soma);
			if ( dif < min ) {
				min = dif ;
				d = soma;
		}else if ( dif == min ) {
				c = soma ;
			}
		
	}
}	if ( c == 0){
	printf("%d\n",d);
}
	else printf("%d %d\n",d,c);
	min = 1000000 ;
}
			return 0;
		}
	
	
	
