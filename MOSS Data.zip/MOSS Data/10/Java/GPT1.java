import java.util.*;

public class ClosestSums {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int N = scanner.nextInt();
        int[] S = new int[N];
        for (int i = 0; i < N; i++) {
            S[i] = scanner.nextInt();
        }

        int P = scanner.nextInt();
        int[] queries = new int[P];
        for (int i = 0; i < P; i++) {
            queries[i] = scanner.nextInt();
        }

        // Store all possible sums
        Set<Integer> sums = new HashSet<>();
        for (int i = 0; i < N; i++) {
            for (int j = i + 1; j < N; j++) {
                sums.add(S[i] + S[j]);
            }
        }

        // For each query, find the closest sum
        for (int query : queries) {
            int closestDistance = Integer.MAX_VALUE;
            List<Integer> closestSums = new ArrayList<>();

            for (int sum : sums) {
                int distance = Math.abs(sum - query);
                if (distance < closestDistance) {
                    closestDistance = distance;
                    closestSums.clear();
                    closestSums.add(sum);
                } else if (distance == closestDistance) {
                    closestSums.add(sum);
                }
            }

            Collections.sort(closestSums);
            System.out.println(String.join(" ", closestSums.stream().map(String::valueOf).toArray(String[]::new)));
        }

        scanner.close();
    }
}
