import java.io.*;
import java.util.*;

class MyReader {
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    MyReader (InputStream input) {
	reader = new BufferedReader(new InputStreamReader(input));
	tokenizer = new StringTokenizer("");
    }

    static String next() throws IOException {
	while (!tokenizer.hasMoreTokens()) {
	    String line = reader.readLine();
	    tokenizer = new StringTokenizer((line.compareTo("\0")==0)?"":line);
	}
	return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
	return Integer.parseInt(next());
    }

    static double nextDouble() throws IOException {
	return Double.parseDouble(next());
    }
}

public class prat07 {
    
    public static int getMinDist(int pesq, int[] somas) {
	int min = Integer.MAX_VALUE;
	for (int i = 0; i < somas.length; i++) {
	    int d = Math.abs(somas[i] - pesq);
	    if (d < min) min = d;
	}
	return min;
    }

    public static int bsearch (int[] v, int low, int high, int key) {
	while (low <= high) {
	    int middle = low + (high - low) / 2;
	    if (key == v[middle]) return middle;
	    else if (key < v[middle]) high = middle - 1;
	    else low = middle + 1;
	}
	return (-1);
    }
    
    public static int[] removeDuplicates(int[] A) {
	if (A.length < 2)
	    return A;
 
	int j = 0;
	int i = 1;
 
	while (i < A.length) {
	    if (A[i] == A[j]) {
		i++;
	    } else {
		j++;
		A[j] = A[i];
		i++;
	    }
	}
 
	int[] B = Arrays.copyOf(A, j + 1);
 
	return B;
    }

    public static void main (String[] args) {
        try {
	    MyReader reader = new MyReader(System.in);
	    int n = reader.nextInt();
	    int arr[] = new int[n];
	    for (int i = 0; i < n; i++) {
		arr[i] = reader.nextInt();
	    }
	    Arrays.sort(arr);
	    int somas[] = new int[(n * (n-1))];
	    int s = 0;
	    for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
		    if (!(i == j)) {
			somas[s] = arr[i] + arr[j];
			s++;
		    }
		}
	    }
	    Arrays.sort(somas);
	    int somas_ord[] = removeDuplicates(somas);
	    int qs = reader.nextInt();
	    for (int i = 0; i < qs; i++) {
		int pesq = reader.nextInt();
		int dist = getMinDist(pesq, somas_ord);
		int index = bsearch(somas_ord, 0, somas_ord.length, pesq - dist);
		if (index == -1) index = bsearch(somas_ord, 0, somas_ord.length, pesq + dist);
		int itemp = index;
		System.out.print(somas_ord[index]);
		if (itemp + 1 < somas_ord.length) {
		    index = bsearch (somas_ord, itemp + 1, somas_ord.length, pesq - dist);
		    if (index == -1) index = bsearch(somas_ord, itemp + 1, somas_ord.length, pesq + dist);
		    if (index != -1) System.out.print(" " + somas_ord[index]);
		}
		System.out.println();
	    }
	}
	catch (Exception e) {}
    }
}
