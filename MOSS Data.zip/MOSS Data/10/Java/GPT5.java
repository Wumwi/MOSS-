import java.util.*;

public class ClosestSums {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int N = scanner.nextInt();
        int[] S = new int[N];
        for (int i = 0; i < N; i++) {
            S[i] = scanner.nextInt();
        }

        int P = scanner.nextInt();
        int[] queries = new int[P];
        for (int i = 0; i < P; i++) {
            queries[i] = scanner.nextInt();
        }

        // Store sums in a frequency map
        Map<Integer, Integer> sumCount = new HashMap<>();
        for (int i = 0; i < N; i++) {
            for (int j = i + 1; j < N; j++) {
                sumCount.put(S[i] + S[j], sumCount.getOrDefault(S[i] + S[j], 0) + 1);
            }
        }

        // Extract unique sums into a list and sort
        List<Integer> uniqueSums = new ArrayList<>(sumCount.keySet());
        Collections.sort(uniqueSums);

        // For each query, find the closest sum
        for (int query : queries) {
            int closestDistance = Integer.MAX_VALUE;
            List<Integer> closestSums = new ArrayList<>();

            for (int sum : uniqueSums) {
                int distance = Math.abs(sum - query);
                if (distance < closestDistance) {
                    closestDistance = distance;
                    closestSums.clear();
                    closestSums.add(sum);
                } else if (distance == closestDistance) {
                    closestSums.add(sum);
                }
            }

            System.out.println(String.join(" ", closestSums.stream().map(String::valueOf).toArray(String[]::new)));
        }

        scanner.close();
    }
}
