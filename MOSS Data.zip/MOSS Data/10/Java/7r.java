import java.util.*;
public class Somas_Mais_Proximas {
	final static int N_MAX=1000;
	public static void main (String []Args){
		Scanner in  = new Scanner(System.in);
		final int nconj=in.nextInt();
		int[] s=new int[nconj];
		for(int i=0;i<nconj;i++){
			s[i]=in.nextInt();
		}
		int nper=in.nextInt();
		int p[]=new int[nper];
		for(int j=0;j<nper;j++){
			p[j]=in.nextInt();
		}
		int cursor=0;
		int menor[]=new int[N_MAX];
		for(int i=0;i<nper;i++){
			for(int j=0;j<nconj;j++){
				cursor=0;
				for(int k=j+1;k<nconj;k++){
					if(menor[cursor]==0){
						
							menor[cursor]=s[j]+s[k];
					}
					else{
						
						if((Math.abs((s[j]+s[k])-p[i])) < Math.abs(menor[cursor]-p[i])){
							menor[cursor]=s[j]+s[k];
						}
						
						else if((Math.abs((s[j]+s[k])-p[i])) == Math.abs(menor[cursor]-p[i])){
							menor[cursor+1]=s[j]+s[k];
						}
					}
					
				}
			}
			for(int l=0;l<N_MAX;l++){
				if(menor[l]!=0){
					System.out.print(menor[l]+" ");
					menor[l]=0;
				}
			}
			System.out.println();

		}


	}
}
