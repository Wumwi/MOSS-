import java.util.*;

public class MinimalistOpticsPrim {
    static final int MAX_NODES = 100;
    static int[][] cost = new int[MAX_NODES][MAX_NODES];
    static boolean[] selected;

    public static int primMST(int nodes) {
        int total = 0;
        selected[0] = true;

        for (int k = 0; k < nodes - 1; k++) {
            int minCost = Integer.MAX_VALUE, minIndex = -1;
            for (int i = 0; i < nodes; i++) {
                if (selected[i]) {
                    for (int j = 0; j < nodes; j++) {
                        if (!selected[j] && cost[i][j] != 0 && cost[i][j] < minCost) {
                            minCost = cost[i][j];
                            minIndex = j;
                        }
                    }
                }
            }
            if (minIndex != -1) {
                total += minCost;
                selected[minIndex] = true;
            }
        }
        return total;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int nodes = scanner.nextInt();
        int connections = scanner.nextInt();
        int maintenanceCost = scanner.nextInt();
        
        selected = new boolean[nodes];
        for (int i = 0; i < nodes; i++) {
            Arrays.fill(cost[i], 0);
        }

        for (int i = 0; i < connections; i++) {
            int u = scanner.nextInt() - 1;
            int v = scanner.nextInt() - 1;
            int performance = scanner.nextInt();
            cost[u][v] = performance;
            cost[v][u] = performance;
        }

        int grossIncome = primMST(nodes);
        int netIncome = grossIncome - (maintenanceCost * (nodes - 1));

        if (netIncome >= 0) {
            System.out.println("rendimento optimo: " + netIncome);
        } else {
            System.out.println("impossivel");
        }
    }
}
