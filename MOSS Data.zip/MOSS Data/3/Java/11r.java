import java.util.*;

class Node {

	int num;
	int peso;
	LinkedList<Node> ligacoes;
	boolean visitado;

	Node(int n, int p) {
		num = n;
		peso = p;
		ligacoes = new LinkedList<Node>();
		visitado = false;
	}
}

class Grafo {

	LinkedList<Node> arvore;
	LinkedList<Node> arvoreMinima;

	Grafo() {
		arvore = new LinkedList<Node>();
		arvoreMinima = new LinkedList<Node>();
	}

	void colocaGrafo(int n) {
		arvore.add(new Node(n, 0));
	}

	void adicionaLigacao(int o, int d, int valor) {
		for (Node n : arvore)
			if (n.num == o)
				n.ligacoes.add(new Node(d, valor));
	}

	void Prim(int ini) {
		
		LinkedList<Node> fila = new LinkedList<Node>();
		int count = 0;
		for (Node i : arvore)
			if (i.num == 1) {
				i.peso = 0;
				fila.add(i);
				count++;
			}
		while (count > 0) {
			boolean existe = false;
			Node NoMax = new Node(0, -1);
			for (Node l : fila)
				if (l.peso >= NoMax.peso)
					NoMax = l;
			fila.remove(NoMax);
			count--;
			for (Node n : NoMax.ligacoes) {
				for (Node t : arvore) {
					if (t.num == n.num) {
						if (n.peso > t.peso && t.visitado == false) {
							t.peso = n.peso;
							for (Node f : fila)
								if (f.num == t.num)
									existe = true;

							if (existe == false){
								fila.add(t);
								count++;
							}
						}
					}
				}
			}
			for (Node t : arvore)
				if (t.num == NoMax.num)
					t.visitado = true;
			arvoreMinima.add(new Node(NoMax.num, NoMax.peso));
		}
	}
}

public class OticaMinimalista {
	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		int custo = 0;

		int nNos = in.nextInt();
		int nLig = in.nextInt();
		int manutencao = in.nextInt();
		Grafo grafo = new Grafo();

		for (int i = 1; i <= nNos; i++) {
			grafo.colocaGrafo(i);
		}

		for (int i = 0; i < nLig; i++) {
			int n1 = in.nextInt();
			int n2 = in.nextInt();
			int peso = in.nextInt();
			grafo.adicionaLigacao(n1, n2, peso);
			grafo.adicionaLigacao(n2, n1, peso);
		}
		if (nLig < nNos - 1)
			System.out.println("impossivel");

		else {
			grafo.Prim(1);

			if (grafo.arvoreMinima.size() < nNos)
				System.out.println("impossivel");
			else {
				for (Node n : grafo.arvoreMinima)
					custo += n.peso;
				System.out.println("rendimento optimo: "
						+ (custo - ((nNos - 1) * manutencao)));
			}
		}
	}
}