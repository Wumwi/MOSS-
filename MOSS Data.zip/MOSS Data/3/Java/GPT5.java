import java.util.*;

public class MinimalistOpticsDFS {
    static int[][] income;
    static boolean[] visited;
    static int totalGrossIncome = 0;

    public static void dfs(int node, int nodes) {
        visited[node] = true;
        for (int i = 0; i < nodes; i++) {
            if (income[node][i] != 0 && !visited[i]) {
                totalGrossIncome += income[node][i];
                dfs(i, nodes);
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int nodes = scanner.nextInt();
        int connections = scanner.nextInt();
        int maintenanceCost = scanner.nextInt();

        income = new int[nodes][nodes];
        for (int i = 0; i < connections; i++) {
            int u = scanner.nextInt() - 1;
            int v = scanner.nextInt() - 1;
            int performance = scanner.nextInt();
            income[u][v] = performance;
            income[v][u] = performance;
        }

        visited = new boolean[nodes];
        dfs(0, nodes);

        int edgesUsed = 0;
        for (boolean v : visited) {
            if (v) edgesUsed++;
        }

        if (edgesUsed == nodes) {
            int netIncome = totalGrossIncome - (maintenanceCost * (nodes - 1));
            System.out.println("rendimento optimo: " + netIncome);
        } else {
            System.out.println("impossivel");
        }
    }
}
