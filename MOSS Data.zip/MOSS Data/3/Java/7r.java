import java.util.*;
class no {
	int index;
	int custo;
	LinkedList<no> links;
	
	no(int i){
		index = i;
		custo = 0;
		links = new LinkedList<no>();
		
	}
	no(int i, int c){
		index =i;
		custo = c;
		links = new LinkedList<no>();
		
	}
	void addLink( int i, int c){
		links.addLast(new no(i,c));
	}
}
class grafo{
	int nPontos;
	LinkedList<no> inicio;
	LinkedList<no> construcao;
	boolean usados[];
	
	grafo(){
		nPontos =0;
		inicio = new LinkedList<no>();
		construcao = new LinkedList<no>();
		
	}
	void Create(no[] lista, int nos){
		no temp= new no(0);
		usados = new boolean[nos+1];
		for (int i=1; i<=nos; i++){
			usados[i]= false;
		}
		inicio.addFirst(lista[1]);
		usados[1]= true;
		nPontos++;
		construcao.addFirst(new no(1));
		temp = BigPath(inicio);
		while(temp.index!=0){
			//System.out.println("temp: " + temp.index + " " + temp.custo);
			inicio.addLast(lista[temp.index]);
			construcao.addLast(new no(temp.index, temp.custo));
			usados[temp.index]=true;
			nPontos++;
			temp= BigPath(inicio);
		}
	}
	no BigPath(LinkedList<no> inicio ){
		no max= new no(0);
		for(no temp: inicio){
			for(no xx: temp.links){
				if(max.custo<xx.custo && usados[xx.index]==false) max= xx;
			}
		}
		return max;
	}
	void printa(int nos){
		if (nos==nPontos){
			System.out.println("rendimento optimo: " + calculo() );
		}
		else System.out.println("Impossivel");
	}
	int calculo(){
		int cal=0;
		for(no temp: construcao){
			cal = cal+temp.custo;
		}
		return cal;
	}
	/*void printo(){
		for(no xx: inicio){
			System.out.println(xx.index);
		}
		System.out.println(nPontos + " !!");
	}*/
}

public class optica {
	public static void main(String[] agrs){
		int nos, lig, man,var1,var2,var3;
		//no lista[];
		grafo arvFin= new grafo();
		Scanner in = new Scanner(System.in); 
		nos = in.nextInt();
		lig = in.nextInt();
		man = in.nextInt();
		no[] lista = new no[nos+1];
		for(int i =1; i<=nos; i++){
			lista[i]= new no(i);
		}
		for(int i =1; i<=lig; i++){
			var1= in.nextInt();
			var2=in.nextInt();
			var3=in.nextInt();
			lista[var1].addLink(var2, var3-man);
			lista[var2].addLink(var1, var3-man);
		}
		arvFin.Create(lista, nos);
		arvFin.printa(nos);
		//arvFin.printo();
		
	}

}
