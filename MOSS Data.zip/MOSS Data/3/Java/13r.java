import java.util.*;

class Edge{
    public int s;
    public int e;
    public int w;
    Edge(int s, int e, int w){
		this.s=s;
		this.e=e;
		this.w=w;
    }
}

class Sol2{
    Scanner input;
    Sol2(Scanner input){this.input=input;}
    int nrNodes;
    int nrEdges;
    int maiCost;
    int cost = 0;
    int ncons = 0;
    int[] succ;
    int[] rank;
    Edge[] ord;
    ArrayList<ArrayList<Edge>> g  = new ArrayList<ArrayList<Edge>>();
    
    void read(){
		nrNodes = input.nextInt();
		nrEdges = input.nextInt();
		maiCost = input.nextInt();
		succ=new int[nrNodes+1];
		rank=new int[nrNodes+1];
		ord =new Edge[nrEdges];
		for(int i=0; i<nrNodes+1; i++)
		    g.add(new ArrayList<Edge>());
		for(int i=0; i<nrEdges; i++){
		    int s = input.nextInt();
		    int e = input.nextInt();
		    int w = input.nextInt();
		    Edge e1 = new Edge(s,e,w);
		    ord[i]=e1;
		    g.get(s).add(e1);
		}
    }
    
    void solve(){
		if(!isConnected())
		    System.out.println("impossivel");
		else{
		    kruskall();
		    int total = cost-(maiCost*(nrNodes-1));
		    System.out.println("rendimento optimo: " + total);
		}
    }
    
    void kruskall(){
		makeSet();
		orderEdges();
		for(int i=0; i<ord.length; i++){
		    if(findSet(ord[i].s)!=findSet(ord[i].e)){
			union(ord[i].s,ord[i].e);
			cost+=ord[i].w;
			ncons++;
		    }
		}
    }

    void orderEdges(){
		for(int i=1; i<ord.length; i++){
		    Edge aux = ord[i];
		    int j=i-1;
		    while(j>=0 && ord[j].w<=aux.w){
			ord[j+1]=ord[j];
			j=j-1;
		    }
		    ord[j+1]=aux;
		}
    }
    
    void makeSet(){
		for(int i=1; i<g.size(); i++){
		    succ[i]=i;
		    rank[i]=0;
		}
    }
    
    int findSet(int x){
		if(succ[x]!=x)
		    succ[x]=findSet(succ[x]);
		return succ[x];
    }

    void union(int x, int y){
    	link(findSet(x),findSet(y));
    }
    
    void link(int x, int y){
		if(rank[x]>rank[y])
		    succ[y]=x;
		else{
		    succ[x]=y;
		    if(rank[x]==rank[y])
			rank[y]++;
		}
    }
    
    boolean isConnected(){
		LinkedList<Integer> q = new LinkedList<Integer>();
		int[] visi = new int[g.size()];
		q.addLast(1);
		visi[1]=1;
		while(q.size()!=0){
		    int n = q.removeFirst();
		    for(int i=0; i<g.get(n).size(); i++){
			int e = g.get(n).get(i).e;
			if(visi[e]==0)
			    q.addLast(e);
		    }
		    visi[n]=1;
		}
		for(int i=1; i<visi.length; i++)
		    if(visi[i]==0)
			return false;
		return true;
    }

}

class Minimal{
    public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		Sol2 s = new Sol2(input);
	    s.read();
	    s.solve();
    }
}