import java.util.*;

class No{
    boolean visitado = false;
    No pai = null;
    LinkedList<Ligacao> ligacoes = new LinkedList<Ligacao>();
}

class Ligacao{
    No no;
    int rendimento;
    Ligacao(No no, int rendimento){
        this.no = no;
        this.rendimento = rendimento;
    }
}

class OpticaMinimalista{
    static Ligacao getMin(LinkedList<Ligacao> ligacoes){
        int max = Integer.MIN_VALUE;;
        Ligacao res = null;
        for(Ligacao l : ligacoes){
            if(!l.no.visitado && l.rendimento>max){
                max = l.rendimento;
                res = l;
            }
        }
        return res;
    }

    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        int nN = in.nextInt();
        int nL = in.nextInt();
        int cM = in.nextInt();
        
        No[] nos = new No[nN+1];
        for(int i=1; i<=nN; i++){
            nos[i] = new No();
        }
        
        for(int i=0; i<nL; i++){
            No o = nos[in.nextInt()];
            No d = nos[in.nextInt()];
            int r = in.nextInt()-cM;
            o.ligacoes.add(new Ligacao(d, r));
            d.ligacoes.add(new Ligacao(o, r));
        }
        
        LinkedList<Ligacao> ligacoes = new LinkedList<Ligacao>();        
        Ligacao l;
        nos[1].visitado = true;
        ligacoes.addAll(nos[1].ligacoes);
        int rendimento = 0;
        int nvisitados = 1;
        
        while((l=getMin(ligacoes))!=null){
            l.no.visitado = true;
            nvisitados++;
            rendimento += l.rendimento;
            ligacoes.addAll(l.no.ligacoes);
        }
        if(nvisitados<nN)
            System.out.println("impossivel");
        else
            System.out.println("rendimento: "+rendimento);
    }
}
