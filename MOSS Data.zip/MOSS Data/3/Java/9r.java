    import java.util.*;
    class Aluno{
        int id;
        int n;
        int[] rel=new int[n];
        Scanner in;
        Aluno(int i, int nn, String s){
            id=i;
            n=nn;
            in=new Scanner(s);
            int x=0;
            while (in.hasNext()){
                rel[x]=in.nextInt();
                x++;
            }//while
        }//metodo
    }//class
     
    class Sociologia {
        static void remove2(int x,int y, char[][] matriz){
            for(int k=0;k<matriz.length;k++){
                        if(matriz[x][k]=='*'){
                            matriz[x][k]='p';
                    }
            }
            for(int k=0;k<matriz.length;k++){
                        if(matriz[k][y]=='*'){
                            matriz[k][y]='p';
                    }
            }
        }
     
        static void remove(int x,int y, char[][] matriz){
            int conta=0;
            for(int k=0;k<matriz.length;k++){
                        if(matriz[x][k]=='*'){
                            matriz[x][k]='p';
                            conta++;
                            remove2(k,x,matriz);
                    }
            }
            for(int k=0;k<matriz.length;k++){
                        if(matriz[k][y]=='*'){
                            matriz[k][y]='p';
                            remove2(k,x,matriz);
                    }
            }
     
     
        }
        public static void main(String[] args){
            Scanner in = new Scanner(System.in);
            int nmaiorIV=0;
            Scanner inn;
            int ncasos=in.nextInt();
            for (int i=0;i<ncasos;i++){
                int nalunos = in.nextInt();
                if (nalunos>3)
                    nmaiorIV++;
                Aluno[] lista = new Aluno[nalunos];
                inn=new Scanner(in.nextLine());
                char[][] matriz = new char [nalunos][nalunos];
                for (int j=0;j<nalunos;j++){
                    int id = inn.nextInt();
                    int n= inn.nextInt();
                    for(int y=0;y<n;y++){
                        matriz[id][inn.nextInt()]='*';
                    }
     
                    String s = inn.nextLine();
                    lista[j]=new Aluno(id, n, s);
                }//for secundario
                for(int y=0;y<matriz.length;y++){
                    for(int w=0;w<matriz.length;w++){
                        if(matriz[y][w]=='*')
                            remove(y,w,matriz);
                    }
                }
            }//for principal
     
        }//main
    }//class
