
import java.util.*;

class Lig {
    int pri;
    int seg;
    int custo;
    
    Lig (int p, int s, int c) {
        pri=p-1;
        seg=s-1;
        custo=c;
    }
}
@SuppressWarnings("unchecked")
class Grafo {
    ArrayList <Integer> lista [];
    Lig connect [];
    int n_lig;
    int rendimento;
    int nvertices;
    

    
    
    
    Grafo (int n, int e) {
        lista= new ArrayList [n];
        connect = new Lig [e];
        n_lig = 0;
        rendimento=0;
        nvertices=n;
        for (int i=0; i<n; i++) {
            lista[i]=new ArrayList <Integer> ();
        }
    }
    
    public boolean find_set (int a, int b) {
        LinkedList <Integer> aux = new LinkedList <Integer> ();
        aux.add(a);
        int vertices [] = new int [nvertices];
        for (int i=0; i<vertices.length; i++) {
            vertices[i]=1;
        }
        while (!aux.isEmpty()) {
            int v = aux.remove();
            if (v==b) return false;
            else {
                for (int i: lista[v])
                    if (vertices[v]!=0)
                        aux.add(i);
            }
            vertices[v]=0;
        }
        return true;
    }
    
    public boolean kruskal () {
        sort_lig();
        for (int i =0; i<connect.length; i++) {
            if (find_set (connect[i].pri, connect[i].seg)) { //&& find_set (connect[i].seg , connect[i].pri)) {
                lista[connect[i].pri].add (connect[i].seg);
                lista[connect[i].seg].add (connect[i].pri);
                n_lig++;
                rendimento+=connect[i].custo;
            }
        }
        LinkedList <Integer> aux = new LinkedList <Integer> ();
        aux.add(0);
        int vertices [] = new int [nvertices];
        for (int i=0; i<vertices.length; i++) {
            vertices[i]=1;
        }
        while (!aux.isEmpty()) {
            int v = aux.remove();
            if (vertices[v]!=0)
                for (int i: lista[v])
                    aux.add(i);
            vertices[v]=0;
        }
        for (int i=0; i<vertices.length; i++) {
            if (vertices[i]==1)
                return false;
        }
        return true;
    }
    
    public void sort_lig () {
        int ntrocas=1;
        Lig aux;
        while (ntrocas != 0) {
            ntrocas=0;
            for (int i=0; i<connect.length-1; i++) {
                if (connect[i].custo < connect[i+1].custo) {
                    aux = connect[i];
                    connect[i] = connect[i+1];
                    connect[i+1] = aux;
                    ntrocas++;
                } 
            }
        }
    }   
}

public class Optica_minimalista {
    
    public static void main(String[] args) {
        Scanner in = new Scanner (System.in);
        int nverti = in.nextInt();
        int nlig = in.nextInt();
        int custo_lig = in.nextInt();
        Grafo g = new Grafo (nverti,nlig);
        for (int i=0; i<nlig; i++) {
            Lig l = new Lig (in.nextInt(), in.nextInt(), in.nextInt());
            g.connect[i]=l;
        }
        if (g.kruskal()) {
            int rend = g.rendimento - (g.n_lig * custo_lig); 
            System.out.println("Rendimento optico: " + rend);
        }
        else System.out.println("Impossivel");
    }
}
