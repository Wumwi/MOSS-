import java.util.*;

public class MinimalistOpticsKruskalOptimized {
    static class Edge {
        int u, v, cost;

        Edge(int u, int v, int cost) {
            this.u = u;
            this.v = v;
            this.cost = cost;
        }
    }

    static int[] parent, rank;

    static int find(int x) {
        if (parent[x] != x) {
            parent[x] = find(parent[x]);
        }
        return parent[x];
    }

    static void union(int x, int y) {
        int rootX = find(x);
        int rootY = find(y);
        if (rootX != rootY) {
            if (rank[rootX] > rank[rootY]) {
                parent[rootY] = rootX;
            } else if (rank[rootX] < rank[rootY]) {
                parent[rootX] = rootY;
            } else {
                parent[rootY] = rootX;
                rank[rootX]++;
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int nodes = scanner.nextInt();
        int connections = scanner.nextInt();
        int maintenanceCost = scanner.nextInt();

        Edge[] edges = new Edge[connections];
        for (int i = 0; i < connections; i++) {
            edges[i] = new Edge(scanner.nextInt() - 1, scanner.nextInt() - 1, scanner.nextInt());
        }

        parent = new int[nodes];
        rank = new int[nodes];
        for (int i = 0; i < nodes; i++) {
            parent[i] = i;
            rank[i] = 0;
        }

        Arrays.sort(edges, (a, b) -> b.cost - a.cost);

        int totalGrossIncome = 0;
        int edgesUsed = 0;

        for (Edge edge : edges) {
            if (find(edge.u) != find(edge.v)) {
                union(edge.u, edge.v);
                totalGrossIncome += edge.cost;
                edgesUsed++;
            }
        }

        if (edgesUsed == nodes - 1) {
            int netIncome = totalGrossIncome - (maintenanceCost * edgesUsed);
            System.out.println("rendimento optimo: " + netIncome);
        } else {
            System.out.println("impossivel");
        }
    }
}
