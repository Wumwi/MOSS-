import java.util.*;

public class MinimalistOpticsPrimWithPQ {
    static class Edge {
        int v, cost;

        Edge(int v, int cost) {
            this.v = v;
            this.cost = cost;
        }
    }

    static final int MAX_NODES = 100;
    static List<Edge>[] graph = new ArrayList[MAX_NODES];
    static boolean[] selected;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int nodes = scanner.nextInt();
        int connections = scanner.nextInt();
        int maintenanceCost = scanner.nextInt();

        for (int i = 0; i < nodes; i++) {
            graph[i] = new ArrayList<>();
        }

        for (int i = 0; i < connections; i++) {
            int u = scanner.nextInt() - 1;
            int v = scanner.nextInt() - 1;
            int performance = scanner.nextInt();
            graph[u].add(new Edge(v, performance));
            graph[v].add(new Edge(u, performance));
        }

        selected = new boolean[nodes];
        int total = 0, edgesUsed = 0;
        PriorityQueue<Edge> pq = new PriorityQueue<>(Comparator.comparingInt(e -> e.cost));
        selected[0] = true;

        for (Edge edge : graph[0]) {
            pq.offer(edge);
        }

        while (!pq.isEmpty() && edgesUsed < nodes - 1) {
            Edge edge = pq.poll();
            int v = edge.v;
            if (!selected[v]) {
                selected[v] = true;
                total += edge.cost;
                edgesUsed++;
                for (Edge nextEdge : graph[v]) {
                    if (!selected[nextEdge.v]) {
                        pq.offer(nextEdge);
                    }
                }
            }
        }

        if (edgesUsed == nodes - 1) {
            int netIncome = total - (maintenanceCost * edgesUsed);
            System.out.println("rendimento optimo: " + netIncome);
        } else {
            System.out.println("impossivel");
        }
    }
}
