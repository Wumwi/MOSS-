def readln(): return map(int, input().split())

def optica():
    g = {}
    edge = []
    n,nlig,custo = readln()
    for i in range(0,nlig):
        edge.append(readln())
        a,b,dab=edge[i]
        try:
            g[a][b]=dab
        except KeyError:
            g[a]={}
            g[a][b]=dab
        try:
            g[b][a]=dab
        except KeyError:
            g[b]={}
            g[b][a]=dab
    kruskal(g,edge,custo)

def kruskal(g,edge,custo):
    floresta=[]
    for i in g.keys():
        floresta.append([i])
    edge=qsort1(edge)
    optimo=0
    f=len(floresta)
    e=len(edge)
    while(f>=2 and e!=0):
        x=edge.pop()
        e-=1
        if (([x[0]] in floresta) and ([x[1]] in floresta)):
            floresta.remove([x[0]])
            floresta.remove([x[1]])
            floresta.append([x[0]]+[x[1]])
            optimo = optimo + x[2] - custo
            f-=1
        elif ([x[0]] in floresta):
            for i in range(f):
                if x[1] in floresta[i]:
                    floresta[i].append(x[0])
                    floresta.remove([x[0]])
                    optimo= optimo + x[2] - custo
                    f-=1
                    break
        elif ([x[1]] in floresta):
            for i in range(f):
                if x[0] in floresta[i]:
                    floresta[i].append(x[1])
                    floresta.remove([x[1]])
                    optimo= optimo + x[2] - custo
                    f-=1
                    break
        else:
            v0=(-1)
            v1=(-1)
            for i in range(f):
                if x[0] in floresta[i]:
                    v0=i
                if x[1] in floresta[i]:
                    v1=i
                if v0!=(-1) and v1!=(-1):
                    break
            if v0!=v1:
                floresta[v1]=floresta[v1]+floresta[v0]
                floresta.remove(floresta[v0])
                optimo=optimo + x[2] - custo
                f-=1
        
    if f==1:
        print('rendimento optimo: ' + str(optimo))
    else:
        print('impossivel')

def qsort1(lst):
	if len(lst) <= 1:
		return lst
	pivot = lst.pop(0)
	greater_eq = qsort1([i for i in lst if i[2] >= pivot[2]])
	lesser = qsort1([i for i in lst if i[2] < pivot[2]])
	return lesser + [pivot] + greater_eq

optica()
