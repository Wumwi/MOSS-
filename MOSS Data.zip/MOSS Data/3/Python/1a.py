# -*- coding: cp1252 -*-
#OPTICA MINIMALISTA com o kruskal

grafo1={1:{2:6,5:6},4:{8:6},3:{6:3},7:{4:2},2:{5:4,3:3},6:{2:4},5:{6:1},8:{}}

def kruskal(grafo,custo): #grafo pesado; custo de manuten�ao
    a=[]
    conjunto={}
    arestas=[]
    total=0
    for v in grafo:
        conjunto[v]=v
    for u in grafo:
        for v in grafo[u]:
            arestas.append((grafo[u][v],u,v))
    arestas.sort()
    arestas.reverse()
    arvore=0
    for (p,x,y) in arestas:
        if conjunto[x]!=conjunto[y]:
            total=total+p
            conjunto=UNION(conjunto,x,y)
            a.append((x,y))
            arvore=arvore+1
    if arvore!=len(grafo)-1:
        print('impossivel')
        return
    else:
        print('rendimento optimo:',total-custo*arvore)
        return

def UNION(conjunto,x,y):
    r1=conjunto[x]
    r2=conjunto[y]
    for n in grafo:
        if conjunto[n]==r2:
            conjunto[n]=r1
    return conjunto


(vertices,arestas,custo)=map(int,input().split())
grafo={}
lista=[]
for i in range(1,vertices+1):
    grafo[i]={}
for i in range(1,arestas+1):
    (ext1,ext2,rendimento)=map(int,input().split())
    lista.append((ext1,ext2,rendimento))
for (a,b,c) in lista:
    grafo[a][b]=c

kruskal(grafo,custo)
