def dfs(node, graph, visited):
    visited[node] = True
    total_income = 0
    for next_node, performance in graph[node]:
        if not visited[next_node]:
            total_income += performance
            total_income += dfs(next_node, graph, visited)
    return total_income

def dfs_solution(nodes, edges, maintenance_cost):
    graph = [[] for _ in range(nodes)]
    for u, v, performance in edges:
        graph[u].append((v, performance))
        graph[v].append((u, performance))

    visited = [False] * nodes
    total_gross_income = dfs(0, graph, visited)

    if all(visited):
        net_income = total_gross_income - (maintenance_cost * (nodes - 1))
        return net_income
    else:
        return "impossivel"

# Input
nodes, connections, maintenance_cost = map(int, input().split())
edges = [tuple(map(int, input().split())) for _ in range(connections)]
edges = [(u - 1, v - 1, performance) for u, v, performance in edges]  # Zero-indexed

result = dfs_solution(nodes, edges, maintenance_cost)
if result == "impossivel":
    print(result)
else:
    print("rendimento optimo:", result)
