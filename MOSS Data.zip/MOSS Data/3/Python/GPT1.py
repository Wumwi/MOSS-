class UnionFind:
    def __init__(self, size):
        self.parent = list(range(size))
        self.rank = [0] * size

    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x, y):
        rootX = self.find(x)
        rootY = self.find(y)
        if rootX != rootY:
            if self.rank[rootX] > self.rank[rootY]:
                self.parent[rootY] = rootX
            elif self.rank[rootX] < self.rank[rootY]:
                self.parent[rootX] = rootY
            else:
                self.parent[rootY] = rootX
                self.rank[rootX] += 1

def kruskal(nodes, edges, maintenance_cost):
    edges.sort(key=lambda x: -x[2])  # Sort edges by gross income descending
    uf = UnionFind(nodes)
    total_gross_income = 0
    edges_used = 0

    for u, v, performance in edges:
        if uf.find(u) != uf.find(v):
            uf.union(u, v)
            total_gross_income += performance
            edges_used += 1

    if edges_used == nodes - 1:
        net_income = total_gross_income - (maintenance_cost * edges_used)
        return net_income
    else:
        return "impossivel"

# Input
nodes, connections, maintenance_cost = map(int, input().split())
edges = [tuple(map(int, input().split())) for _ in range(connections)]
edges = [(u - 1, v - 1, performance) for u, v, performance in edges]  # Zero-indexed

result = kruskal(nodes, edges, maintenance_cost)
if result == "impossivel":
    print(result)
else:
    print("rendimento optimo:", result)
