def readln(): return map(int, input().split())

def optica():
    g = {}
    edge = []
    n,nlig,custo = readln()
    for i in range(0,nlig):
        edge.append(readln())
        a,b,dab=edge[i]
        try:
            g[a][b]=dab
        except KeyError:
            g[a]={}
            g[a][b]=dab
        try:
            g[b][a]=dab
        except KeyError:
            g[b]={}
            g[b][a]=dab
    kruskal(g,edge,custo,n)

def kruskal(g,edge,custo,n):
    floresta=[]
    pos={}
    tamanho={}
    pai={}
    m=0
    for i in g.keys():
        floresta.append([i])
        pos[i]=m
        tamanho[i]=1
        pai[i]=i
        m+=1
    if m!=n:
        print('impossivel')
        return
    edge=qsort1(edge)
    optimo=0
    f=len(floresta)
    e=len(edge)
    while(f>=2 and e!=0):
        x=edge.pop()
        e-=1
        if pai[x[0]]!=pai[x[1]]:
            if tamanho[pai[x[0]]]>=tamanho[pai[x[1]]]:
                aux=floresta.pop(pos[pai[x[1]]])
                for i in range(pos[pai[x[1]]],f-1):
                    pos[floresta[i][0]]-=1
                floresta[pos[pai[x[0]]]]+=aux
                tamanho[pai[x[0]]]+=tamanho[pai[x[1]]]
                for i in g.keys():
                    if pai[i]==pai[x[1]]:
                        pai[i]=pai[x[0]]
                optimo= optimo + x[2] - custo
                f-=1
            else:
                aux=floresta.pop(pos[pai[x[0]]])
                for i in range(pos[pai[x[0]]],f-1):
                    pos[floresta[i][0]]-=1
                floresta[pos[pai[x[1]]]]+=aux
                tamanho[pai[x[1]]]+=tamanho[pai[x[0]]]
                for i in g.keys():
                    if pai[i]==pai[x[0]]:
                        pai[i]=pai[x[1]]
                optimo= optimo + x[2] - custo
                f-=1
    if f==1:
        print('rendimento optimo: '+ str(optimo))
    else:
        print('impossivel')

def qsort1(lst):
	if len(lst) <= 1:
		return lst
	pivot = lst.pop(0)
	greater_eq = qsort1([i for i in lst if i[2] >= pivot[2]])
	lesser = qsort1([i for i in lst if i[2] < pivot[2]])
	return lesser + [pivot] + greater_eq

optica()
