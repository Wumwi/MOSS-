import heapq

def prim(nodes, edges, maintenance_cost):
    graph = [[] for _ in range(nodes)]
    for u, v, performance in edges:
        graph[u].append((performance, v))
        graph[v].append((performance, u))

    total_gross_income = 0
    edges_used = 0
    selected = [False] * nodes
    min_heap = [(0, 0)]  # (cost, node)

    while min_heap and edges_used < nodes - 1:
        cost, u = heapq.heappop(min_heap)
        if selected[u]:
            continue
        selected[u] = True
        total_gross_income += cost
        edges_used += 1

        for next_cost, v in graph[u]:
            if not selected[v]:
                heapq.heappush(min_heap, (next_cost, v))

    if edges_used == nodes:
        net_income = total_gross_income - (maintenance_cost * (nodes - 1))
        return net_income
    else:
        return "impossivel"

# Input
nodes, connections, maintenance_cost = map(int, input().split())
edges = [tuple(map(int, input().split())) for _ in range(connections)]
edges = [(u - 1, v - 1, performance) for u, v, performance in edges]  # Zero-indexed

result = prim(nodes, edges, maintenance_cost)
if result == "impossivel":
    print(result)
else:
    print("rendimento optimo:", result)
