#    """By Pedro Coelho
#    Basicamente, a lista de adjacencias vai ter o formato [[inic1,dest1,custo1],[inic2],[dest2,custo2],....]
#    Para verificar se todos os nos estao ligados, usei um BFS (testConnections)(esta parte tenho quase a certeza que dava para
#    ser verificada dentro do Kruskal mas ja estava sem paciencias... lol
#    Seguidamente, ordeno a lista de adj pelo maior valor de rendimento bruto de modo a obter o maior lucro possivel (maxRendimento)
#    Finalmente, o getMST vai encontrar a MST e devolver o maior valor de rendimento bruto possivel. (quanto ao find_set
#    e ao union acho que se explicam por eles mesmos mas se precisarem de explicacao avisem.
#    Por ultimo subtraio ao valor de rendimento bruto o custo de manutencao para obter o rendimento liquido.

#    PS - Isto provavelmente nao e la muito eficiente mas acho que da para mostrar adequadamente a ideia por detras do algoritmo de Kruskal
#    """

def optica_minimalista():
    #obter input
    x = input().split()
    nNos = int(x[0])
    nLig = int(x[1])
    cManu = int(x[2])
       
    adj = []
       
    for i in range(nLig):
        x = input().split()
        inic = int(x[0])
        fim = int(x[1])
        rBruto = int(x[2])
        adj.append([inic,fim,rBruto])
       
    #verificar as coneccoes
    testconnections = testConnections(adj)
    if testconnections != nNos:
        print("impossivel")
        return
          
    #ordenar a lista de adj
    adj = maxRendimento(adj)
    #obter a mst e o rendimento bruto max
    mst = getMST(nNos,adj)
       
    #imprimir o valor
    print(("rendimento optimo: %d") % (mst[1]-(cManu*(nNos-1))))

def getMST(n,adj):

    # criar a lista de sets para cada vertice
    setList = []
    for i in range(1,n+1):
        setList.append(set())
        setList[i-1].add(i)
       
    rBruto = 0
       
       
    while len(setList) != 1:   #enquanto nao estiver tudo ligado
          
        for i in adj:
            x= i[0]
            y= i[1]
            if find_set(setList,x) != find_set(setList,y):   #encontrar os sets de cada elemento
                setList = unionSet(setList,x,y)   #se forem diferentes, junta-se os sets
                rBruto+= i[2]   #e junta-se ao rendimento bruto
       
    return setList,rBruto
       
def testConnections(adj):   #bfs para ver se todos os vertices estao ligados
    Queue = [adj[0][0]]
    Visited = [adj[0][0]]
    while Queue != []:
        for i in getAdj(adj,Queue[0]):
            if i not in Visited:
                Queue.append(i)
                Visited.append(i)
            del Queue[0]
    return len(Visited)
       
def getAdj(adj,x):   #encontrar as adjacencias de cada vertice para o BFS
    adjacencias = []
    for i in range(len(adj)):
        if adj[i][0] == x:
            adjacencias.append(adj[i][1])
    return adjacencias
             
          
def find_set(setList,x):   #encontrar o set do vertice x na lista de sets setList
    for i in range(len(setList)):
        if x in setList[i]:
            return i
             
                
def unionSet(setList,x,y):   #juntar o set do x com o y
    doublebreak = False
    for i in range(len(setList)):
        for z in range(len(setList)):
            if x in setList[i] and y in setList[z]:
                #juntar os sets, basicamente usando uma var aux juntar ao set do x o set do y e apagar o do y
                q = setList[i].union(setList[z])
                setList[i] = q
                del(setList[z])
                doublebreak = True   #ta feito o que queriamos, doublebreak para parar os dois ciclos for
                break
        if doublebreak == True: break
    return setList
                
                
       
def maxRendimento(adj):   #ordenar a lista de adj pelo maior lucro
    for i in range(len(adj)):
        for z in range(len(adj)):
            if adj[i][2] > adj[z][2]:
                a = adj[z]
                adj[z] = adj[i]
                adj[i] = a
    return adj





optica_minimalista()
