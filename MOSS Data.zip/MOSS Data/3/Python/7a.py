def read_input(): return map(int, input().split())

def optica_minimalista():
    graph = []
    nrvertex, nredges, cost = read_input()
    for  i in range(nredges):
        start, end, rend = read_input() 
        graph.append((-rend, start, end))  
    output = kruskal(graph)

    if len(output[1]) != nrvertex: return 'impossivel'
    else: return 'rendimento optimo: ' + str(output[0] - (len(output[2]) * cost))

class Disjoint_set:
    def __init__(self, n):
        self.rank = [0] * n
        self.p = [0] * n
        for i in range(n):
            self.rank[i] = 0
            self.p[i] = i
    def union(self, x, y):
        self.link(self.find_set(x), self.find_set(y))
    def find_set(self, x):
        if self.p[x] != x: self.p[x] = self.find_set(self.p[x])
        return self.p[x]
    def link(self, x, y):
        if self.rank[x] > self.rank[y]: self.p[y] = x
        else: 
            self.p[x] = y
            if self.rank[x] == self.rank[y]:
                self.rank[y] += 1
                
def kruskal(graph):
    tree = []
    visited = set()
    count = 0
    D = Disjoint_set(len(graph))
    graph.sort()
    for (w,u,v) in graph:
        visited.add(u)
        if D.find_set(u) != D.find_set(v):
            tree.append((u,v))
            count -= w
            D.union(u,v)    
    return count, visited, tree

print(optica_minimalista())
