def opticamin():
	y = input().split()
	nnos = int(y[0])
	nlig = int(y[1])
	custoM = int(y[2])
	arestas = []
	for i in range(nlig):
		y=input().split()
		e1 = int(y[0])
		e2 = int(y[1])
		rend = int(y[2])
		arestas.append([e1, e2, rend])
	arestas.sort(key=lambda x:x[2], reverse=True)
	rend = kruskal(nnos, arestas)
	if len(rend[1])==1:
		print(("rendimento optimo: %d") % (rend[0]-(custoM*(nnos-1))))
	else:
		print("impossivel")

def kruskal(nos, adj):
	conj=[]
	for i in range(nos):
		conj.append(set())
		conj[i].add(i+1)
	rendB = 0
	for i in adj:
		x=i[0]
		y=i[1]
		if pai(x,conj) != pai(y,conj):
			conj=uniao(conj, x, y)
			rendB = rendB + i[2]
	return rendB,conj
def pai(x, conj):
	for i in range(len(conj)):
		if x in conj[i]:
			return i
def uniao(conj, x, y):
	feito = False
	for i in range(len(conj)):
		for j in range(len(conj)):
			if x in conj[i] and y in conj[j]:
				conj[i]=conj[i].union(conj[j])
				del(conj[j])
				feito = True
				break
		if feito==True: break
	return conj
opticamin()
