def optica_minimalista():
    #obter input
    x = input().split()
    nNos = int(x[0])
    nLig = int(x[1])
    cManu = int(x[2])
       
    adj = []
       
    for i in range(nLig):
        x = input().split()
        inic = int(x[0])
        fim = int(x[1])
        rBruto = int(x[2])
        adj.append([inic,fim,rBruto])
          
    #ordenar a lista de adj
    adj = maxRendimento(adj)
    #obter a mst e o rendimento bruto max
    mst = getMST(nNos,adj)
    
    #imprimir o valor
    if len(mst[0]) == 1:
        print(("rendimento optimo: %d") % (mst[1]-(cManu*(nNos-1))))
    else:
        print("impossivel")
        
def getMST(n,adj):
    # criar um conjunto para cada vertice
    setList = []
    for i in range(1,n+1):
        setList.append(set())
        setList[i-1].add(i)

    #coloca o rendimento bruto a zero
    rBruto = 0      

    #percorre toda a lista de adjacencias
    for i in adj:
        #pega nos dois vertices de cada ligacao
        x= i[0]
        y= i[1]
        #e testa se estao no mesmo set, caso nao estejam:
        if find_set(setList,x) != find_set(setList,y):
            setList = unionSet(setList,x,y)   #une os sets a que cada um pertence
            rBruto += i[2]   #e aumenta-se o rendimento bruto

    return setList,rBruto
          
def find_set(setList,x):   #encontrar o set do vertice x na lista de sets setList
    for i in range(len(setList)):
        if x in setList[i]:
            return i
             
#une o set do elemento x com o set do elemento y
def unionSet(setList,x,y):
    doublebreak = False
    for i in range(len(setList)):
        for z in range(len(setList)):
            if x in setList[i] and y in setList[z]: #junta o set de x com o set de y e apaga o antigo set de y
                setList[i] = setList[i].union(setList[z])
                del(setList[z])
                doublebreak = True   #ta feito o que queriamos, doublebreak para parar os dois ciclos for
                break
        if doublebreak == True: break
    return setList
                
                
#coloca por ordem decrescente de peso todas as arestas
def maxRendimento(adj):
    for i in range(len(adj)):
        for j in range(len(adj)):
            if adj[i][2] > adj[j][2]:
                (adj[i],adj[j]) = (adj[j],adj[i])
    return adj

    optica_minimalista()
