
G = {}

Nnos,nligacoes,C = map(int,input().split())

for i in range(1,Nnos):
	G[i] = []
	
for i in range(nligacoes):
	lst = map(int,input().split())
	u,v,r = lst
	if u not in G: G[u] = []
	if v not in G: G[v] = []
	G[u].append((v,r))
	G[v].append((u,r))
	
def pop(Q):
	bv = -1
	bk = None
	for k in Q:
		if Q[k] > bv:
			bk = k
			bv = Q[k]
	del Q[bk]
	return bk,bv
	
def add(Q,v,r):
	if v not in Q:
		Q[v] = r
	else :
		Q[v] = max(Q[v],r)

def resolve():
	visited = {}
	for i in range(1,Nnos+1):
		visited[i] = False
	Q = {}
	Q[1] = 0
	total = 0
	while Q != {}:
		u,r = pop(Q)
		total += r
		visited[u] = True
		for (v,r) in G[u]:
			if not visited[v]:
				add (Q,v,r-C) #adiciona a pilha caso nao tenha sido visitado
	for v in G:
		if not visited[v]:
			print("impossivel")
			return
	print("rendimento optimo: " + str(total))
	
resolve()
		

