def opticaminimalista():
    while (True):
        try:
            nnos,nlig,cmanu=input().split(' ')
            nnos=int(nnos)
            nlig=int(nlig)
            cmanu=int(cmanu)
            adjacencias=[]
            for i in range(nlig):
                source,end,rend=input().split(' ')
                source=int(source)
                end=int(end)
                rend=int(rend)
                adjacencias.append([source,end,rend])
            adjacencias=reord(adjacencias)
            mst=getMST(nnos,adjacencias)
            if len(mst[0])==1:
                print(("rendimento optimo: %d") % (mst[1]-(cmanu*(nnos-1))))
            else:
                print("impossivel")
        except:
            break

        
def getMST(nnos,adjacencias):
    setlist=[]
    for i in range(1,nnos+1):
        setlist.append(set())
        setlist[i-1].add(i)
    rbruto=0
    for i in adjacencias:
        x=i[0]
        y=i[1]
        if findset(setlist,x)!=findset(setlist,y):
            setlist=unionset(setlist,x,y)
            rbruto=rbruto+i[2]
    return setlist,rbruto

        
def findset(setlist,x):
    for i in range(len(setlist)):
        if (x in setlist[i]):
            return i

def unionset(setlist,x,y):
    dbreak=False
    for i in range(len(setlist)):
        for j in range(len(setlist)):
            if (x in setlist[i] and y in setlist[j]):
                setlist[i]=setlist[i].union(setlist[j])
                del(setlist[j])
                dbreak=True
                break
        if (dbreak==True):
            break
    return setlist

def reord(adj):
    for i in range(len(adj)):
        for j in range(len(adj)):
            if adj[i][2]>adj[j][2]:
                (adj[i],adj[j])=(adj[j],adj[i])
    return adj
