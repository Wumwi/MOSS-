#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define MAX 100
#define INF INT_MAX

int cost[MAX][MAX], nodes, maintenanceCost;

int primMST() {
    int selected[MAX], total = 0, edgesUsed = 0;
    memset(selected, 0, sizeof(selected));
    selected[0] = 1;
    
    for (int k = 0; k < nodes - 1; k++) {
        int min = INF, x = -1, y = -1;
        for (int i = 0; i < nodes; i++) {
            if (selected[i]) {
                for (int j = 0; j < nodes; j++) {
                    if (!selected[j] && cost[i][j]) {
                        if (min > cost[i][j]) {
                            min = cost[i][j];
                            x = i;
                            y = j;
                        }
                    }
                }
            }
        }
        if (x != -1 && y != -1) {
            total += cost[x][y];
            selected[y] = 1;
            edgesUsed++;
        }
    }
    
    return (edgesUsed == nodes - 1) ? total : -1;
}

int main() {
    int connections;
    scanf("%d %d %d", &nodes, &connections, &maintenanceCost);

    for (int i = 0; i < nodes; i++) {
        for (int j = 0; j < nodes; j++) {
            cost[i][j] = INF;
        }
    }

    for (int i = 0; i < connections; i++) {
        int u, v, performance;
        scanf("%d %d %d", &u, &v, &performance);
        cost[u - 1][v - 1] = cost[v - 1][u - 1] = performance;
    }

    int grossIncome = primMST();
    if (grossIncome == -1) {
        printf("impossivel\n");
    } else {
        int netIncome = grossIncome - (maintenanceCost * (nodes - 1));
        printf("rendimento optimo: %d\n", netIncome);
    }

    return 0;
}
