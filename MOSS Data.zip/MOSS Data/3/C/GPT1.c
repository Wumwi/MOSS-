#include <stdio.h>
#include <stdlib.h>

#define MAX 10000

typedef struct {
    int u, v, cost;
} Edge;

Edge edges[MAX];
int parent[MAX];

int find(int i) {
    while (parent[i] != i)
        i = parent[i];
    return i;
}

void union1(int i, int j) {
    int a = find(i);
    int b = find(j);
    parent[a] = b;
}

int cmp(const void *a, const void *b) {
    return ((Edge *)b)->cost - ((Edge *)a)->cost;
}

int main() {
    int nodes, connections, maintenanceCost;
    scanf("%d %d %d", &nodes, &connections, &maintenanceCost);
    
    for (int i = 0; i < connections; i++) {
        scanf("%d %d %d", &edges[i].u, &edges[i].v, &edges[i].cost);
    }

    for (int i = 0; i < nodes; i++) {
        parent[i] = i;
    }

    qsort(edges, connections, sizeof(edges[0]), cmp);

    int totalGrossIncome = 0;
    int edgesUsed = 0;
    
    for (int i = 0; i < connections; i++) {
        int u = edges[i].u - 1;
        int v = edges[i].v - 1;
        int uParent = find(u);
        int vParent = find(v);
        if (uParent != vParent) {
            union1(uParent, vParent);
            totalGrossIncome += edges[i].cost;
            edgesUsed++;
        }
    }

    if (edgesUsed == nodes - 1) {
        int netIncome = totalGrossIncome - (edgesUsed * maintenanceCost);
        printf("rendimento optimo: %d\n", netIncome);
    } else {
        printf("impossivel\n");
    }

    return 0;
}
