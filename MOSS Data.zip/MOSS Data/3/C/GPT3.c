#include <stdio.h>
#include <stdlib.h>

#define MAX 10000

typedef struct {
    int u, v, cost;
} Edge;

Edge edges[MAX];
int parent[MAX], rank[MAX];

int find(int i) {
    if (parent[i] != i)
        parent[i] = find(parent[i]);
    return parent[i];
}

void union1(int x, int y) {
    int rootX = find(x);
    int rootY = find(y);

    if (rank[rootX] > rank[rootY])
        parent[rootY] = rootX;
    else if (rank[rootX] < rank[rootY])
        parent[rootX] = rootY;
    else {
        parent[rootY] = rootX;
        rank[rootX]++;
    }
}

int cmp(const void *a, const void *b) {
    return ((Edge *)b)->cost - ((Edge *)a)->cost;
}

int main() {
    int nodes, connections, maintenanceCost;
    scanf("%d %d %d", &nodes, &connections, &maintenanceCost);
    
    for (int i = 0; i < connections; i++) {
        scanf("%d %d %d", &edges[i].u, &edges[i].v, &edges[i].cost);
    }

    for (int i = 0; i < nodes; i++) {
        parent[i] = i;
        rank[i] = 0;
    }

    qsort(edges, connections, sizeof(Edge), cmp);

    int totalGrossIncome = 0;
    int edgesUsed = 0;
    
    for (int i = 0; i < connections; i++) {
        int u = edges[i].u - 1;
        int v = edges[i].v - 1;
        if (find(u) != find(v)) {
            union1(u, v);
            totalGrossIncome += edges[i].cost;
            edgesUsed++;
        }
    }

    if (edgesUsed == nodes - 1) {
        int netIncome = totalGrossIncome - (edgesUsed * maintenanceCost);
        printf("rendimento optimo: %d\n", netIncome);
    } else {
        printf("impossivel\n");
    }

    return 0;
}
