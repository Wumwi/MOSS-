#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_V 1000005
#define MAX_E 1000005

typedef struct EDGE{
  int a, b, c;
} EDGE;

int compare(const void *x, const void *y){
  return ((*(EDGE*)x).c - (*(EDGE*)y).c);
}

int qttVerts, qttEdges, manCost;
int qttSets, Rend, id;
int p[MAX_V], rank[MAX_V];
EDGE edges[MAX_E];

void init_sets(){
  memset(rank, 0, sizeof(rank));
  int i;
  for(i = 0; i < qttVerts; i ++) p[i] = i;
}
int find_set(int i){ return ((p[i] == i) ? i : (p[i] = find_set(p[i]))); }
int is_same_set(int i, int j){ return (find_set(i) == find_set(j)); }
void union_sets(int i, int j){
  if(!is_same_set(i, j)){
    int x = find_set(i), y = find_set(j);
    if(rank[x] > rank[y]) p[y] = x;
    else{
      p[x] = y;
      if(rank[x] == rank[y]) rank[y] ++;
    }
  }
}


int main(){
  int i;

  scanf("%d %d %d", &qttVerts, &qttEdges, &manCost);
  for(i = 0; i < qttEdges; i ++){
    scanf("%d %d %d", &edges[i].a, &edges[i].b, &edges[i].c);
    edges[i].a --;
    edges[i].b --;
  }

  qsort(edges, qttEdges, sizeof(EDGE), compare);

  qttSets = qttVerts;
  Rend = 0;
  id = qttEdges - 1;
  init_sets();

  while(qttSets > 1 && id >= 0){
    if(!is_same_set(edges[id].a, edges[id].b)){
      union_sets(edges[id].a, edges[id].b);
      Rend += edges[id].c;
      qttSets --;
    }
    id --;
  }

  if(qttSets > 1)
    printf("impossivel\n");
  else
    printf("rendimento optimo: %d\n", Rend - ((qttVerts - 1) * manCost));

  return 0;
}
  
