#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX_NODES 100

int income[MAX_NODES][MAX_NODES], nodes, maintenanceCost, totalGrossIncome;

void dfs(int node, int *visited) {
    visited[node] = 1;
    for (int i = 0; i < nodes; i++) {
        if (income[node][i] && !visited[i]) {
            totalGrossIncome += income[node][i];
            dfs(i, visited);
        }
    }
}

int main() {
    int connections;
    scanf("%d %d %d", &nodes, &connections, &maintenanceCost);

    for (int i = 0; i < nodes; i++) {
        for (int j = 0; j < nodes; j++) {
            income[i][j] = 0;
        }
    }

    for (int i = 0; i < connections; i++) {
        int u, v, performance;
        scanf("%d %d %d", &u, &v, &performance);
        income[u - 1][v - 1] = performance; // Undirected graph
        income[v - 1][u - 1] = performance;
    }

    int visited[MAX_NODES] = {0};
    dfs(0, visited);

    int edgesUsed = 0;
    for (int i = 0; i < nodes; i++) {
        if (visited[i]) edgesUsed++;
    }

    if (edgesUsed == nodes) {
        int netIncome = totalGrossIncome - (maintenanceCost * (nodes - 1));
        printf("rendimento optimo: %d\n", netIncome);
    } else {
        printf("impossivel\n");
    }

    return 0;
}
