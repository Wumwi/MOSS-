#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int u, v, profit;
} Edge;

int parent[1000];
Edge edges[10000];

int find(int x) {
    if (parent[x] == x)
        return x;
    return parent[x] = find(parent[x]);
}

void unionSet(int x, int y) {
    parent[find(x)] = find(y);
}

int cmp(const void *a, const void *b) {
    return ((Edge *)b)->profit - ((Edge *)a)->profit;
}

int main() {
    int n, m, maintenance;
    scanf("%d %d %d", &n, &m, &maintenance);

    for (int i = 0; i < m; i++) {
        scanf("%d %d %d", &edges[i].u, &edges[i].v, &edges[i].profit);
    }

    for (int i = 0; i < n; i++) {
        parent[i] = i;
    }

    qsort(edges, m, sizeof(Edge), cmp);

    int total = 0, connectedEdges = 0;
    for (int i = 0; i < m; i++) {
        if (find(edges[i].u - 1) != find(edges[i].v - 1)) {
            unionSet(edges[i].u - 1, edges[i].v - 1);
            total += edges[i].profit;
            connectedEdges++;
        }
    }

    if (connectedEdges == n - 1) {
        printf("rendimento optimo: %d\n", total - maintenance * connectedEdges);
    } else {
        printf("impossivel\n");
    }

    return 0;
}
