import string
  
pred={}
d={}
visited=[]

def ler():
    lista = []
    a = input()
    a = string.split(a)
    for x in a:
        lista = lista + [int(x)]
    return lista
    
def main():
    P={} #Pesos
    Adj={} #Adjacencias
    global Q
    (lojas,destino)=ler()
    a=ler()
    while (a[0]!=-1):
        P[(a[0],a[1])]=a[2]
        P[(a[1],a[0])]=a[2]
        if( a[0] not in Adj):
            Adj[a[0]]=[a[1]]
        else:
            Adj[a[0]]+=[a[1]]
        if(a[1] not in Adj):
            Adj[a[1]]=[a[0]]
        else:
            Adj[a[1]]+=[a[0]]
        a=ler()
    Q=Adj.keys()
    Dijkstra(Adj,P,destino)
    #print "Pesos",P
    #print "\n"
   #print "Adj",Adj
        

def Dijkstra(G,w,s):
    INITIALIZE_SINGLE_SOURCE(G,s)
    S=[]
    while len(visited)!=len(G):
        u=EXTRACT_MIN(Q)
	#print d
	#print u
        visited.append(u)
	if u==0:
	    return 0
        for v in G[u]:
            RELAX(u,v,w)
    
    for i in visited:
        print(i,)
    
        

def INITIALIZE_SINGLE_SOURCE(G,s):
    for v in G:
        d[v]=1e10000
        pred[v]=[]
    d[s]=0

def EXTRACT_MIN(Q):
    VMenorPeso=1e10000
    minn=1e10000
    for v in Q:
	#print d[v]
        if(d[v]<minn):
            minn=d[v]
            VMenorPeso=v
    if VMenorPeso == 0:
        return 0
    else:
        Q.remove(VMenorPeso)
        return VMenorPeso

def eMin(G):
    x=0
    mini=1e10000
    for v in G:
        if(v not in visited):
            if(d[v]<mini):
                mini=d[v]
                x=v 
    return x

def RELAX(u,v,w):
    if(d[v]>d[u]+w[(v,u)]):
        d[v]=d[u]+w[(v,u)]
        pred[v]=u
main()
