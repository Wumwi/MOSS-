import sys

def floyd_warshall(n, graph):
    dist = [[sys.maxsize] * (n + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        dist[i][i] = 0

    for u in range(1, n + 1):
        for v, d in graph[u]:
            dist[u][v] = min(dist[u][v], d)

    for k in range(1, n + 1):
        for i in range(1, n + 1):
            for j in range(1, n + 1):
                if dist[i][k] < sys.maxsize and dist[k][j] < sys.maxsize:
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j])

    return dist

def main():
    n, dest = map(int, input().split())
    graph = [[] for _ in range(n + 1)]

    while True:
        line = input().strip()
        if line == "-1":
            break
        u, v, d = map(int, line.split())
        graph[u].append((v, d))
        graph[v].append((u, d))  # Undirected graph

    dist = floyd_warshall(n, graph)

    order = sorted((i for i in range(1, n + 1) if i != dest and dist[dest][i] < sys.maxsize),
                   key=lambda x: (dist[dest][x], x))

    print(" ".join(map(str, order)))

if __name__ == "__main__":
    main()
