import sys
def negocio():
    nnos,destino=lerlinha()
    grafo={}
    V=[]
    aresta=lerlinha()
    while aresta[0] != -1:
        grafo=inserir_aresta(grafo,aresta)
        aresta=lerlinha()
    for i in range(1,nnos+1):
        V.append(i)
    sol=dijkstra(grafo,destino,V)
    for i in sol:
        print(i,)
def dijkstra(g,destino,V):
    dist=[]
    fim=[]
    dist.append(sys.maxint)
    for i in V:
        dist.append(sys.maxint)
    dist[destino]=0
    while len(V)!=0:
        t=extract_min(V,dist)
        V.remove(t)
        fim.append(t)
        for y in g[t].keys():
            if y in V:
                dist[y]=min(dist[y],dist[t]+g[t][y])
    return fim
def extract_min(V,dist):
	min=0
	for i in V:
		if dist[i]<dist[min]:
			min=i
	return min
        
def inserir_aresta(grafo,x):
	if x[0] not in grafo:
		grafo[x[0]]={}
	grafo[x[0]][x[1]]=x[2]
	if x[1] not in grafo:
		grafo[x[1]]={}
	grafo[x[1]][x[0]]=x[2]
	return grafo
def lerlinha(): return map(int, input().split())

negocio()
