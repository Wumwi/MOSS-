def readln(): return map(int, input().split())


def negocio():
    n,destino=readln()
    grafo={}
    Q=[]
    aresta=readln()
    while aresta[0]!=-1:
        grafo=insere_aresta(grafo,aresta)
        aresta=readln()
    for i in range(1,n+1):
        Q.append(i)
    dijkstra(grafo,destino,Q)

def dijkstra(g,destino,Q):
    cenas=""
    dist=[]
    res=[]
    dist.append(100000)
    for i in Q:
        dist.append(10000)
    dist[destino]=0
    while len(Q)!=0:
        v=0
        for i in Q:
            if dist[i]<dist[v]:
                v=i
        Q.remove(v)
        for w in g[v].keys():
            if w in Q:
                dist[w]=min(dist[w],dist[v]+g[v][w])
        res.append(v)
    for i in range(len(res)-1):
        cenas = cenas + str(res[i]) + " "
    cenas = cenas + str(res[len(res)-1])
    print(cenas)
       

def insere_aresta(grafo,aresta):
    a,b,dab=aresta
    try:
        grafo[a][b]=dab
    except KeyError:
        grafo[a]={}
        grafo[a][b]=dab
    try:
        grafo[b][a]=dab
    except KeyError:
        grafo[b]={}
        grafo[b][a]=dab
    return grafo       

negocio()
