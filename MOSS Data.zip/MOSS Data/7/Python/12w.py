def negocioelectronico():
    x = input().split()
    nLojas = int(x[0])
    iDestino = int(x[1])

    V = []
    E = {}
   

    #le todas as ligacoes entre as regioes
    x = input().split()
    while x[0] != '-1':
        inic = int(x[0])
        fim = int(x[1])
        dist = int(x[2])
        #Cria uma lista com todos os vertices
        if inic not in V:
            V.append(inic)
        if fim not in V:
            V.append(fim)
        #Cria um dicionario com todas as ligacoes no sentido lato
        E[inic,fim]=dist
        E[fim,inic]=dist
        x = input().split()
    #enviamos todas as ligacoes existentes e respectivos pesos, o ponto a partir do qual pretendemos que seja ligado a todas as regioes e uma lista com os vertices
    print(dijkstra(E,iDestino,V))

#retorna o indice da regiao mais proxima
def Extract_Min(Q,dist):
    minimo = 999999
    for i in Q:
        if dist[i-1] < minimo:
            minimo = dist[i-1]
            ind = i-1
    return ind

#calcula as distancias minimas entre todas as regioes e a regiao de entrega
def dijkstra(G,s,Q):
    dist = []
    parent = []
    for i in range(len(Q)):
        dist.append(999999)
        parent.append(None)
    #As regioes sao identificadas por numeros consecutivos a partir de 1 mas os indices da lista comecam no zero.
    #Por isso temos de reduzir uma unidade. p.e -> Regiao 1 encontra-se no indice 0
    dist[s-1]=0
    S = []
    while Q != []:
        #procura o indice da regiao mais proxima
        ind = Extract_Min(Q,dist)
        #Guarda os vertices conforme encontra-mos os minimos
        S.append(ind+1)
        #remove a entrada da regiao da lista das regioes por visitar
        del(Q[Q.index(ind+1)])
        #No dicionario com todas as ligacoes procura aquelas que ligam a regiao pretendida a todas as outras
        for i in G:
            if i[0] == ind+1:
                if dist[i[1]-1] > dist[ind] + G[i]:
                    dist[i[1]-1] = dist[ind] + G[i]
                    parent[i[1]-1] = ind
    return S