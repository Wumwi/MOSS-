def parent(i):
    return i/2

def left(i):
    return i*2+1

def right(i):
    return i*2+2

class Vertice(object):
    def __init__(self, Parent=None, Visited=None, Length=None, Connected=None):
        self.Parent = Parent
        self.Visited = Visited
        self.Length = Length
        self.Connected = Connected

class minHeap:    
    def __init__(self):
        self.A = []
        self.heapsize = -1
        self.ID_to_index = {}

    def insert(self, ID):
        self.heapsize += 1
        self.ID_to_index[ID] = self.heapsize
        self.A.append([ID, 999999999])
        index = self.ID_to_index[ID]
        self.insertHeapify(index)

    def insertHeapify(self, index):
        if index != 0:
            p = parent(index)
            if self.A[index][1] < self.A[p][1]:
                self._swap(index,p)
                self.insertHeapify(p)
            elif self.A[index][1] == self.A[p][1]:
                if self.A[index][0] < self.A[p][0]:
                    self._swap(index,p)

    def _swap(self, index1, index2):
        ID1 = self.A[index1][0]
        ID2 = self.A[index2][0]
        self.A[index1],self.A[index2] = self.A[index2],self.A[index1]
        self.ID_to_index[ID1],self.ID_to_index[ID2] = self.ID_to_index[ID2],self.ID_to_index[ID1]

    def decreaseKey(self, ID, key):
        index = self.ID_to_index[ID]
        self.A[index][1] = key
        self.insertHeapify(index)

    def extractMin(self):
        if self.heapsize >= 0:            
            min_pair = self.A[0]
            self._swap(0,self.heapsize)
            del self.ID_to_index[min_pair[0]]
            self.A = self.A[0:self.heapsize]
            self.heapsize -= 1
            self.extractHeapify(0)
            return min_pair[0]

    def extractHeapify(self, index):
        l = left(index)
        r = right(index)
        smallest = index
        if l <= self.heapsize:
            if self.A[l][1] < self.A[index][1]:
                smallest = l
            elif self.A[l][1] == self.A[index][1] and self.A[l][0] < self.A[index][0]:
                smallest = l
            else:
                smallest = index
        if r <= self.heapsize:
            if self.A[r][1] < self.A[smallest][1]:
                smallest = r
            elif self.A[r][1] == self.A[smallest][1] and self.A[r][0] < self.A[smallest][0]:
                smallest = r
        if smallest <> index:
            self._swap(index,smallest)
            self.extractHeapify(smallest)
            
    def isEmpty(self):
        if self.heapsize < 0:
            return True
        return False

VERTICES = {}
G = {}
Q = minHeap()

def negocioElectronico():
    linha = map(int, input().split(' '))
    start = linha[1]
    linha = map(int, input().split(' '))
    while linha[0] != -1:
        u = linha[0]
        v = linha[1]
        w = linha[2]
        if u not in G:
            G[u] = {}
            G[u][v] = w
            VERTICES[u] = Vertice(None,False,999999999,False)
            Q.insert(u)
        else:
            G[u][v] = w
        if v not in G:
            G[v] = {}
            G[v][u] = w
            VERTICES[v] = Vertice(None,False,999999999,False)
            Q.insert(v)
        else:
            G[v][u] = w
        linha = map(int, input().split(' '))

    res = Dijkstra(start)
    print(" ".join(['%s'%el for el in res]))

def Dijkstra(start):
    cam = []
    VERTICES[start].Length = 0
    VERTICES[start].Connected = True
    Q.decreaseKey(start,0)
    while not Q.isEmpty():
        u = Q.extractMin()
        if VERTICES[u].Connected:
            cam.append(u)
            VERTICES[u].Visited = True
            for v in G[u]:
                if not VERTICES[v].Visited:
                    VERTICES[v].Connected = True
                    w = G[u][v]
                    Relax(u,v,w)
        else:
            return cam
    return cam
    
def Relax(u,v,w):
    if VERTICES[v].Length > VERTICES[u].Length + w:
        VERTICES[v].Length = VERTICES[u].Length + w
        VERTICES[v].Parent = u
        Q.decreaseKey(v,VERTICES[v].Length)

negocioElectronico()
