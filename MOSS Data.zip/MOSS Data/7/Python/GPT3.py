import heapq
import sys

def prim(n, dest, graph):
    distances = [sys.maxsize] * (n + 1)
    visited = [False] * (n + 1)
    distances[dest] = 0
    pq = [(0, dest)]  # (weight, node)

    while pq:
        current_weight, current_node = heapq.heappop(pq)

        if visited[current_node]:
            continue

        visited[current_node] = True

        for neighbor, weight in graph[current_node]:
            if not visited[neighbor] and weight < distances[neighbor]:
                distances[neighbor] = weight
                heapq.heappush(pq, (weight, neighbor))

    return distances

def main():
    n, dest = map(int, input().split())
    graph = [[] for _ in range(n + 1)]

    while True:
        line = input().strip()
        if line == "-1":
            break
        u, v, d = map(int, line.split())
        graph[u].append((v, d))
        graph[v].append((u, d))  # Undirected graph

    distances = prim(n, dest, graph)

    order = sorted((i for i in range(1, n + 1) if i != dest and distances[i] < sys.maxsize),
                   key=lambda x: (distances[x], x))

    print(" ".join(map(str, order)))

if __name__ == "__main__":
    main()
