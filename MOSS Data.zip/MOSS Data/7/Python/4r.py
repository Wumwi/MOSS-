import sys

def negocio_electronico():
    dic = {}
    v=[]
    x= input().split()
    nlojas = int(x[0])
    prim = int(x[1])

    y = input().split()
    while(y[0]!='-1'):
        if int(y[0]) not in v:
            v+=[int(y[0])]
        if int(y[1]) not in v:
            v+=[int(y[1])]
        dic[int(y[0]),int(y[1])]=int(y[2])
        dic[int(y[1]),int(y[0])]=int(y[2])
        y = input().split()
    print(dic)
    dijkstra(dic,prim,v,v)


def dijkstra(grafo,inicio,v,Q):
    dist=[]
    anterior=[]
    for i in v:
        dist+=[sys.maxint]
        anterior+=[None]
    dist[inicio-1]=0
    while Q!=[]:
        min2=sys.maxint
        u=None
        for i in Q:
            if dist[i-1]<min2:
                min2=dist[i-1]
                u=i-1
            if dist[i-1]==min2:
                if u>i-1:
                    u=i-1
        print(u+1)
        if dist[u]==sys.maxint:
            break
        del(Q[Q.index(u+1)])
        for i in grafo:
            if i[0]==u+1:
                alt = dist[u] + grafo[i]
                if alt<dist[i[1]-1]:
                    dist[i[1]-1]=alt
                    anterior[i[1]-1]=u


negocio_electronico()  
    
