def neg_digital():
    temp=ler_inteiros()
    n_regioes=temp[0]
    regiao_dest=temp[1]
    pesos=[]
    for i in range(n_regioes+1):
        pesos.append([])
        for j in range(n_regioes+1):
            pesos[i].append([])
    rede={}
    temp=ler_inteiros()
    while temp[0]!=-1:
        if rede.has_key(temp[0]):
            rede[temp[0]]=rede[temp[0]].append(temp[1])
        else:
            rede[temp[0]]=[temp[1]]
        pesos[temp[0]][temp[1]]=temp[2]
        temp=ler_inteiros()

    print(Dijkstra(rede,regiao_dest))


def Dijkstra(G,start,end=None):
    D = {}
    P = {}
    Q = priorityDictionary()
    Q[start] = 0
	
    for v in Q:
        D[v] = Q[v]
        if v == end: break
       	
        for w in G[v]:
            vwLength = D[v] + G[v][w]
            if w in D:
                if vwLength < D[w]:
                    raise ValueError
            else:
                if w not in Q or vwLength < Q[w]:
                    Q[w] = vwLength
                    P[w] = v
                    
    return (D,P)

neg_digital()
