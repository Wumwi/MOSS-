import sys

def bellman_ford(n, dest, edges):
    distances = [sys.maxsize] * (n + 1)
    distances[dest] = 0

    for _ in range(n - 1):
        for u, v, w in edges:
            if distances[u] != sys.maxsize and distances[u] + w < distances[v]:
                distances[v] = distances[u] + w

    return distances

def main():
    n, dest = map(int, input().split())
    edges = []

    while True:
        line = input().strip()
        if line == "-1":
            break
        u, v, d = map(int, line.split())
        edges.append((u, v, d))
        edges.append((v, u, d))  # Undirected graph

    distances = bellman_ford(n, dest, edges)

    order = sorted((i for i in range(1, n + 1) if i != dest and distances[i] < sys.maxsize),
                   key=lambda x: (distances[x], x))

    print(" ".join(map(str, order)))

if __name__ == "__main__":
    main()
