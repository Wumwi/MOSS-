grafo = {}
peso = {}

def negocioelectronico():
    global grafo
    # Nuno Peralta
    lojas,dest = input().split(' ')
    lojas = int(lojas)
    check = input().split(' ')
    while check[0] != '-1':
        if not grafo.has_key(check[0]):
            grafo[check[0]] = []
        if not grafo.has_key(check[1]):
            grafo[check[1]] = []
        grafo[check[0]].append(check[1])
        grafo[check[1]].append(check[0])
        peso[(check[0],check[1])] = int(check[2])
        peso[(check[1],check[0])] = int(check[2])
        
        check = input().split(' ')
    
    S = dijkstra(dest)
    for i in S:
        print(i,)

#grafovis = {}
F = []
e = {}
def dijkstra(f):
    global grafo, F, e#, grafovis
    S = [] # Fila de minimos
    for i in grafo:
        e[i] = 10000
        F.append(i)
    e[f] = 0
    while F != []:
        x = extract_min()
        S.append(x)
        for y in grafo[x]:
            if e[x] + peso[(x,y)] < e[y]:
                e[y] = e[x] + peso[(x,y)]
                #grafovis[y] = x
    return S

def extract_min():
    global F, e
    min = 10000
    for i in F:
        if e[i] < min:
            min = e[i]
            no = i
    c = 0
    for i in F:
        if i == no:
            del F[c]
            break
        c += 1
    return no

negocioelectronico()
