oo = float("infinity")

def programa():
	num_vertices,destino = converter()
	linha = ""
	grafo = {}
	for i in range(1,num_vertices+1):
		grafo[i] = {}
	while linha != "-1":
		v1,v2,dist,linha = converter2()
		if v1 != 0:
			grafo[v1][v2] = dist
			grafo[v2][v1] = dist
	lista = dijkstra(grafo,destino)
	for i in lista:
		print(i,)



def dijkstra(grafo,destino):
	pi = {}
	global l
	l = {}
	for n in grafo:
		pi[n] = None
		l[n] = oo
	l[destino] = 0
	s = []
	q = []
	for i in grafo:
		q.append(i)
	while q != []:
		x = extract_min(grafo,q)
		q.remove(x)
		s.append(x)
		for y in grafo[x]:
			relax(grafo,pi,x,y)
	return s


def extract_min(grafo,q):
	global l
	minimo = oo
	no = 0
	for i in q:
		if l[i] < minimo:
			minimo = l[i]
			no = i
	return no

def relax(grafo,pi,x,y):
	global l
	if (l[x] + grafo[x][y]) < l[y]:
		l[y] = l[x] + grafo[x][y]
		pi[y] = x

def converter():
	lol = raw_input("")
	lol = lol.split()
	num_vertices = int(lol[0])
	destino = int(lol[1])
	return num_vertices,destino	

def converter2():
	lol = raw_input("")
	lol = lol.split()
	if len(lol) == 3:
		vertice1 = int(lol[0])
		vertice2 = int(lol[1])
		distancia = int(lol[2])
		return vertice1,vertice2,distancia, 0
	else:
		return 0, 0, 0, "-1"	

programa()
