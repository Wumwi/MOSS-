inf = 9999
dist = []
previous = {}
arcos = {}
adj = {}

def negocio():
	x = input().split()
	nLojas = x[0]
	destino = x[1]
	while True:
		x = input().split()
		x[0] = int(x[0])
		if x[0] == -1: break
		x[0] -= 1
		x[1] = int(x[1])-1
		x[2] = int(x[2])
		
		arcos[(x[0],x[1])] = x[2]
		arcos[(x[1],x[0])] = x[2]
		
		try:adj[x[0]].add(x[1])
		except:
			adj[x[0]] = set()
			adj[x[0]].add(x[1])
		
		try:adj[x[1]].add(x[0])
		except:
			adj[x[1]] = set()
			adj[x[1]].add(x[0])
	
	z = dijkstra(int(nLojas),int(destino)-1)
	
	
def dijkstra(nLojas,destino):
	for i in range(nLojas):
		dist.append(inf)
	dist[destino] = 0
	Q = [i for i in range(nLojas)]
	while Q != []:
		u = getmin(Q)
		for i in range(len(Q)):
			if Q[i] == u:
				del(Q[i])
				break
		print(u+1,)
		for v in adj[u]:
			alt = dist[u] + arcos[(u,v)]
			if alt < dist[v]:
				dist[v] = alt
				previous[v] = u

def getmin(Q):
	min = inf
	for i in Q:
		if dist[i] < min:
			min = dist[i]
			indice = i
	return indice

negocio()