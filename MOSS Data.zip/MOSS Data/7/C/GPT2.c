#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX_REGIONS 100
#define INF INT_MAX

typedef struct {
    int id;
    int dist;
} Pair;

Pair queue[MAX_REGIONS];
int front = -1, rear = -1;

void enqueue(int id, int dist) {
    queue[++rear] = (Pair){id, dist};
}

Pair dequeue() {
    return queue[++front];
}

int isEmpty() {
    return front == rear;
}

void sortQueue() {
    for (int i = front + 1; i < rear; i++) {
        for (int j = i + 1; j <= rear; j++) {
            if (queue[i].dist > queue[j].dist ||
                (queue[i].dist == queue[j].dist && queue[i].id > queue[j].id)) {
                Pair temp = queue[i];
                queue[i] = queue[j];
                queue[j] = temp;
            }
        }
    }
}

int graph[MAX_REGIONS][MAX_REGIONS];
int n, dest;
int distances[MAX_REGIONS];
int visited[MAX_REGIONS];

void bfs() {
    for (int i = 1; i <= n; i++) {
        distances[i] = INF;
        visited[i] = 0;
    }

    distances[dest] = 0;
    enqueue(dest, 0);
    
    while (!isEmpty()) {
        sortQueue();
        Pair current = dequeue();
        int currentId = current.id;

        if (visited[currentId]) continue;
        visited[currentId] = 1;

        for (int i = 1; i <= n; i++) {
            if (graph[currentId][i] > 0 && !visited[i]) {
                if (distances[currentId] + graph[currentId][i] < distances[i]) {
                    distances[i] = distances[currentId] + graph[currentId][i];
                    enqueue(i, distances[i]);
                }
            }
        }
    }
}

int main() {
    scanf("%d %d", &n, &dest);
    int u, v, d;

    // Initialize graph
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            graph[i][j] = 0; // No edges
        }
    }

    while (1) {
        scanf("%d", &u);
        if (u == -1) break;
        scanf("%d %d", &v, &d);
        graph[u][v] = d;
        graph[v][u] = d; // undirected
    }

    bfs();

    for (int i = 1; i <= n; i++) {
        if (i != dest && distances[i] != INF) {
            printf("%d ", i);
        }
    }
    printf("\n");

    return 0;
}
