#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX_REGIONS 100

int graph[MAX_REGIONS][MAX_REGIONS];
int n, dest;
int distances[MAX_REGIONS];

void bellmanFord() {
    for (int i = 1; i <= n; i++) {
        distances[i] = INT_MAX;
    }
    distances[dest] = 0;

    for (int k = 1; k < n; k++) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                if (graph[i][j] > 0 && distances[i] != INT_MAX && distances[i] + graph[i][j] < distances[j]) {
                    distances[j] = distances[i] + graph[i][j];
                }
            }
        }
    }
}

int compare(const void* a, const void* b) {
    int id1 = *(int*)a;
    int id2 = *(int*)b;
    if (distances[id1] == distances[id2]) {
        return id1 - id2; // Sort by id if distances are equal
    }
    return distances[id1] - distances[id2];
}

int main() {
    scanf("%d %d", &n, &dest);
    int u, v, d;

    // Initialize graph
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            graph[i][j] = 0; // No edges
        }
    }

    while (1) {
        scanf("%d", &u);
        if (u == -1) break;
        scanf("%d %d", &v, &d);
        graph[u][v] = d;
        graph[v][u] = d; // undirected
    }

    bellmanFord();

    int order[MAX_REGIONS];
    int count = 0;

    for (int i = 1; i <= n; i++) {
        if (i != dest && distances[i] != INT_MAX) {
            order[count++] = i;
        }
    }

    qsort(order, count, sizeof(int), compare);
    
    for (int i = 0; i < count; i++) {
        printf("%d ", order[i]);
    }
    printf("\n");

    return 0;
}
