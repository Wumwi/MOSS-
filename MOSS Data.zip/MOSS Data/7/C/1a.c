#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MIN(a, b) (a < b ? a : b)
#define MAX(a, b) (a > b ? a : b)

#define MAX_V 50005
#define MAX_S 10000005
#define INF 1000000007

typedef struct STATE {
  int node, cost;
} STATE;

int compare(const void *x, const void *y){
  if((*(STATE*)x).cost == (*(STATE*)y).cost)
    return ((*(STATE*)x).node - (*(STATE*)y).node);
  return ((*(STATE*)x).cost - (*(STATE*)y).cost);
}

typedef struct QUEUE_NODE{
  STATE val;
  struct QUEUE_NODE *next;
} QUEUE_NODE;

typedef struct QUEUE {
  QUEUE_NODE *front, *rear;
  int szQueue;
} QUEUE;

int n, ljo, a, b, c, szPQ, best[MAX_V];
QUEUE adjList[MAX_V];
STATE PQ[MAX_S];
STATE ord[MAX_V];

void add_queue(int px, STATE x){
  QUEUE_NODE *temp;
  temp = (QUEUE_NODE *) malloc(sizeof(QUEUE_NODE));
  temp->val = x;
  if(!adjList[px].szQueue){
    temp->next = NULL;
    adjList[px].front = adjList[px].rear = temp;
  }
  else{
    adjList[px].rear->next = temp;
    adjList[px].rear = temp;
  }
  adjList[px].szQueue ++;
}

void add_PQ(int node, int cost){
  szPQ ++;
  PQ[szPQ].node = node;
  PQ[szPQ].cost = cost;
  int i = szPQ;
  while(i > 1){
    if(PQ[i].cost < PQ[(i / 2)].cost){
      STATE aux = PQ[i];
      PQ[i] = PQ[(i / 2)];
      PQ[(i / 2)] = aux;
      i /= 2;
    }
    else
      break;
  }
}

void pop_PQ(){
  PQ[1] = PQ[szPQ];
  szPQ --;
  int mson, i = 1;
  while(i * 2 <= szPQ){
    if(i * 2 + 1 <= szPQ) mson = (PQ[(i * 2)].cost <= PQ[(i * 2 + 1)].cost) ? (i * 2) : (i * 2 + 1);
    else mson = i * 2;
    if(PQ[i].cost > PQ[mson].cost){
      STATE aux = PQ[i];
      PQ[i] = PQ[mson];
      PQ[mson] = aux;
      i = mson;
    }
    else
      break;
  }
}

int main(){
  int i;

  scanf("%d %d", &n, &ljo);

  for(i = 1; i <= n; i ++){
    adjList[i].front = adjList[i].rear = NULL;
    adjList[i].szQueue = 0;
  }

  while(1){
    scanf("%d", &a);
    if(a == -1)
      break;
    scanf("%d %d", &b, &c);
    STATE aux;
    aux.cost = c;
    aux.node = b;
    add_queue(a, aux);
    aux.node = a;
    add_queue(b, aux);
  }

  szPQ = 0;
  add_PQ(ljo, 0);
  for(i = 1; i <= n; i ++)
    best[i] = INF;

  while(szPQ){
    STATE act = PQ[1];
    pop_PQ();
    if(best[act.node] < INF)
      continue;
    best[act.node] = act.cost;
    QUEUE_NODE *walker = adjList[act.node].front;
    for(i = 0; i < adjList[act.node].szQueue; i ++, walker = walker->next)
      if(act.cost + walker->val.cost < best[walker->val.node])
	add_PQ(walker->val.node, act.cost + walker->val.cost);
  }

  for(i = 0; i < n; i ++){
    ord[i].node = i + 1;
    ord[i].cost = best[i + 1];
  }

  qsort(ord, n, sizeof(STATE), compare);

  for(i = 0; i < n; i ++){
    if(i > 0) printf(" ");
    printf("%d", ord[i].node);
  }
  printf("\n");

  return 0;
}
