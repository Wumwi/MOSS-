#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX_REGIONS 100
#define INF INT_MAX

int graph[MAX_REGIONS][MAX_REGIONS];
int n, dest;
int distances[MAX_REGIONS];

void floydWarshall() {
    for (int k = 1; k <= n; k++) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                if (graph[i][k] != 0 && graph[k][j] != 0) {
                    if (graph[i][j] == 0 || graph[i][j] > graph[i][k] + graph[k][j]) {
                        graph[i][j] = graph[i][k] + graph[k][j];
                    }
                }
            }
        }
    }
}

int compare(const void* a, const void* b) {
    int id1 = *(int*)a;
    int id2 = *(int*)b;
    if (distances[id1] == distances[id2]) {
        return id1 - id2; // Sort by id if distances are equal
    }
    return distances[id1] - distances[id2];
}

int main() {
    scanf("%d %d", &n, &dest);
    int u, v, d;

    // Initialize graph
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            graph[i][j] = (i == j) ? 0 : INF; // no edges
        }
    }

    while (1) {
        scanf("%d", &u);
        if (u == -1) break;
        scanf("%d %d", &v, &d);
        graph[u][v] = d;
        graph[v][u] = d; // undirected
    }

    floydWarshall();

    int order[MAX_REGIONS];
    int count = 0;

    for (int i = 1; i <= n; i++) {
        if (i != dest && graph[dest][i] != INF) {
            order[count++] = i;
            distances[i] = graph[dest][i];
        }
    }

    qsort(order, count, sizeof(int), compare);
    
    for (int i = 0; i < count; i++) {
        printf("%d ", order[i]);
    }
    printf("\n");

    return 0;
}
