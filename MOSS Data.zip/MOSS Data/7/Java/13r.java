import java.util.LinkedList;
import java.util.Scanner;
import java.lang.*;
import java.util.*;

class Qnode {
    int vert;
    int vertkey;
    
    Qnode(int v, int key) {
	vert = v;
	vertkey = key;
    }
}
class heapmin {
    private static int posinvalida = 0;
    int sizeMax,size;
    
    Qnode[] a;
    int[] pos_a;

    heapmin(int vec[], int n) {
	a = new Qnode[n + 1];
	pos_a = new int[n + 1];
	sizeMax = n;
	size = n;
	for (int i = 1; i <= n; i++) {
	    a[i] = new Qnode(i,vec[i]);
	    pos_a[i] = i;
	}

	for (int i = n/2; i >= 1; i--)
	    heapify(i);
    }

    heapmin() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    int extractMin() {
	int vertv = a[1].vert;
	swap(1,size);
	pos_a[vertv] = posinvalida;  // assinala vertv como removido
	size--;
	heapify(1);
	return vertv;
    }

    void decreaseKey(int vertv, int newkey) {

	int i = pos_a[vertv];
	a[i].vertkey = newkey;

	while (i > 1 && compare(i, parent(i)) < 0) { 
	    swap(i, parent(i));
	    i = parent(i);
	}
    }


    void insert(int vertv, int key)
    { 
	if (sizeMax == size)
	    new Error("Heap is full\n");
	
	size++;
	a[size].vert = vertv;
	pos_a[vertv] = size;   // supondo 1 <= vertv <= n
	decreaseKey(vertv,key);   // diminui a chave e corrige posicao se necessario
    }

    void write_heap(){
	System.out.printf("Max size: %d\n",sizeMax);
	System.out.printf("Current size: %d\n",size);
	System.out.printf("(Vert,Key)\n---------\n");
	for(int i=1; i <= size; i++)
	    System.out.printf("(%d,%d)\n",a[i].vert,a[i].vertkey);
	
	System.out.printf("-------\n(Vert,PosVert)\n---------\n");

	for(int i=1; i <= sizeMax; i++)
	    if (pos_valida(pos_a[i]))
		System.out.printf("(%d,%d)\n",i,pos_a[i]);
    }
    
    private int parent(int i){
	return i/2;
    }
    private int left(int i){
	return 2*i;
    }
    private int right(int i){
	return 2*i+1;
    }

    private int compare(int i, int j) {
	if (a[i].vertkey < a[j].vertkey)
	    return -1;
	if (a[i].vertkey == a[j].vertkey)
	    return 0;
	return 1;
    }

  
    private void heapify(int i) {
	int l, r, smallest;

	l = left(i);
	if (l > size) l = i;

	r = right(i);
	if (r > size) r = i;

	smallest = i;
	if (compare(l,smallest) < 0)
	    smallest = l;
	if (compare(r,smallest) < 0)
	    smallest = r;
	
	if (i != smallest) {
	    swap(i, smallest);
	    heapify(smallest);
	}
	
    }

    private void swap(int i, int j) {
	Qnode aux;
	pos_a[a[i].vert] = j;
	pos_a[a[j].vert] = i;
	aux = a[i];
	a[i] = a[j];
	a[j] = aux;
    }
    
    private boolean pos_valida(int i) {
	return (i >= 1 && i <= size);
    }
    public boolean vazio()
    {
        return size==0;
    }
}
class Arco {
    No no_final;
    int peso;
    Arco(No fim,int p){
        no_final = fim;
        peso=p;
    }

    No extremo_final() {
	return no_final;
    }
}
class No {
    LinkedList<Arco> adjs;
    int id;
    int MinDistancia;
    No pai;
    No(int i) {
	adjs = new LinkedList<Arco>();
        id=i;
    }
}
class Grafo {
    No verts[];
    int nvs, narcos;		
    public Grafo(int n) {
	nvs = n;
	narcos = 0;
	verts  = new No[n+1];
	for (int i = 0 ; i <= n ; i++)
	    verts[i] = new No(i);
    }
    
    public int num_vertices(){
	return nvs;
    }

    public int num_arcos(){
	return narcos;
    }

    public LinkedList<Arco> adjs_no(int i) {
	return verts[i].adjs;
    }
}

public class NegocioEletronico {
    static Scanner ler= new Scanner(System.in);
    public static void main(String[] args) {
        int lojas=ler.nextInt(),destino=ler.nextInt();
        Grafo g=LerGrafo(lojas);
        Dijkstra(g,g.verts[destino]);
        System.out.println();
    }
    public static Grafo LerGrafo(int lojas)
    {
        int n,destino,distancia;
        Grafo temp=new Grafo(lojas);
        n=ler.nextInt();
        while(n!=-1)
        {
            destino=ler.nextInt();
            distancia=ler.nextInt();
            temp.verts[n].adjs.add(new Arco(temp.verts[destino],distancia));
            temp.verts[destino].adjs.add(new Arco(temp.verts[n],distancia));
            n=ler.nextInt();
        }
        return temp;
    }
    public static void Dijkstra(Grafo g,No origem)
    {
        boolean visitado[]= new boolean [g.nvs+1];
        LinkedList<Integer> teste= new LinkedList<Integer>();
        int dist[]=new int[g.nvs+1];
        for(int i=0; i<g.nvs+1;i++)
        {
            dist[i]=Integer.MAX_VALUE;
            g.verts[i].MinDistancia=Integer.MAX_VALUE;
            visitado[i]=false;
        } 
        origem.MinDistancia=0;
        dist[origem.id]=0;
        heapmin dt= new heapmin(dist,g.nvs);
        while(!dt.vazio())
        {
            No u=g.verts[dt.extractMin()];
            visitado[u.id]=true;
            teste.add(u.id);
            for(int i=0;i<u.adjs.size();i++)
            {
                int d=u.adjs.get(i).peso+u.MinDistancia;
                No v=u.adjs.get(i).no_final;
                if((d<v.MinDistancia)&&(!visitado[v.id]))
                {
                    v.MinDistancia=d;
                    dt.decreaseKey(v.id, d);
                }
            }
        }
        for(int i=0;i<teste.size();i++)
        {
            int peso=g.verts[teste.get(i)].MinDistancia;
            int id=g.verts[teste.get(i)].id;
                for(int j=i+1;j<teste.size();j++)
                {
                    if((peso==g.verts[teste.get(j)].MinDistancia)&&(id>g.verts[teste.get(j)].id))
                     {
                                int temp=teste.get(j);
                                teste.remove(j);
                                teste.add(i,temp);
                     }
                }
             System.out.print(teste.get(i)+ " ");
        }
        System.out.println();
    }
}
/*
9 7
1 2 32
1 3 14
1 4 15
2 5 35
3 2 20
5 3 22
3 4 25
5 6 24
2 6 40
7 2 40
7 8 33
6 7 15
6 8 25
9 6 22
9 8 21
5 9 17
5 4 33
9 4 45
-1

*/
