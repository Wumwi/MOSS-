import java.util.*;

public class FloydWarshallSolution {
    static final int INF = Integer.MAX_VALUE;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt(); // Number of regions
        int dest = scanner.nextInt(); // Destination region
        int[][] graph = new int[n + 1][n + 1];

        for (int i = 1; i <= n; i++) {
            Arrays.fill(graph[i], INF);
            graph[i][i] = 0; // Distance to itself is 0
        }

        while (true) {
            int u = scanner.nextInt();
            if (u == -1) break;
            int v = scanner.nextInt();
            int d = scanner.nextInt();
            graph[u][v] = Math.min(graph[u][v], d); // In case of multiple edges
            graph[v][u] = Math.min(graph[v][u], d); // Undirected graph
        }

        // Floyd-Warshall algorithm
        for (int k = 1; k <= n; k++) {
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= n; j++) {
                    if (graph[i][k] < INF && graph[k][j] < INF) {
                        graph[i][j] = Math.min(graph[i][j], graph[i][k] + graph[k][j]);
                    }
                }
            }
        }

        List<Integer> order = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            if (i != dest && graph[dest][i] < INF) {
                order.add(i);
            }
        }

        order.sort(Comparator.comparingInt(a -> graph[dest][a]));
        order.sort(Comparator.naturalOrder());

        order.forEach(store -> System.out.print(store + " "));
        System.out.println();
    }
}
