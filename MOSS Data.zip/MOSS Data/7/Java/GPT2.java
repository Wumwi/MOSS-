import java.util.*;

public class BfsPriorityQueueSolution {
    static class Edge {
        int to, weight;

        Edge(int to, int weight) {
            this.to = to;
            this.weight = weight;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt(); // Number of regions
        int dest = scanner.nextInt(); // Destination region
        List<List<Edge>> graph = new ArrayList<>(n + 1);

        for (int i = 0; i <= n; i++) {
            graph.add(new ArrayList<>());
        }

        while (true) {
            int u = scanner.nextInt();
            if (u == -1) break;
            int v = scanner.nextInt();
            int d = scanner.nextInt();
            graph.get(u).add(new Edge(v, d));
            graph.get(v).add(new Edge(u, d)); // Undirected graph
        }

        int[] distances = new int[n + 1];
        boolean[] visited = new boolean[n + 1];
        Arrays.fill(distances, Integer.MAX_VALUE);
        distances[dest] = 0;

        Queue<int[]> queue = new PriorityQueue<>(Comparator.comparingInt(a -> a[1]));
        queue.add(new int[]{dest, 0});

        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            int currentNode = current[0];

            if (visited[currentNode]) continue;
            visited[currentNode] = true;

            for (Edge edge : graph.get(currentNode)) {
                if (!visited[edge.to] && distances[currentNode] + edge.weight < distances[edge.to]) {
                    distances[edge.to] = distances[currentNode] + edge.weight;
                    queue.add(new int[]{edge.to, distances[edge.to]});
                }
            }
        }

        List<Integer> order = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            if (i != dest && distances[i] < Integer.MAX_VALUE) {
                order.add(i);
            }
        }

        order.sort(Comparator.comparingInt(a -> distances[a]));
        order.sort(Comparator.naturalOrder());

        order.forEach(store -> System.out.print(store + " "));
        System.out.println();
    }
}
