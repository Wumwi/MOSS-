import java.util.*;

public class sociologia {

	public static void main(String[] args) {
		
		Scanner inp = new Scanner(System.in);
		int nalunos = inp.nextInt();
		grafoS novo = new grafoS(nalunos);
		novo.criarligacoes(inp);
		novo.DFS();
		novo.DFS_inv();
		novo.ProbA();
		novo.ProbB();
		novo.ProbC();
	}

}

class NoS{
	int no;
	int tempofinal;
	LinkedList<NoS> adj;
	boolean visitado;
	int dia;
	
	NoS (int n){
		no = n;
		tempofinal = 0;
		adj = new LinkedList<NoS>();
		dia = 1;
		visitado = false;
	}
	void addLigacao(NoS x){
		adj.addLast(x);
	}
}

class grafoS{
	int nalu;
	int tempo;
	LinkedList<Integer> grupos;
	NoS relacao[];
	NoS rcontrario[];
	
	grafoS (int nalunos){
		nalu = nalunos;
		tempo = 0;
		relacao = new NoS[nalu+1];
		rcontrario = new NoS[nalu+1];
		grupos = new LinkedList<Integer>();
	}
	private void comecargrafo(){
		for (int i=1;i<=nalu;i++){
			relacao[i] = new NoS(i);
			rcontrario[i] = new NoS(i);
		}
	}
	void criarligacoes(Scanner inp){
		comecargrafo();
		for (int i=1;i<=nalu;i++){
			int namigos = inp.nextInt();
			for (int j=1;j<=namigos;j++){
				int idamigos = inp.nextInt();
				relacao[i].addLigacao(relacao[idamigos]);
				rcontrario[idamigos].addLigacao(rcontrario[i]);
			}
		}
	}
	void  DFS(){
		for (int i=1;i<=nalu;i++){
			if(!relacao[i].visitado)
				visitDFS(relacao[i]);
		}		
	}
	void visitDFS(NoS x){
		x.visitado = true;
		tempo++;
		for (NoS sitio: x.adj){
			if (!sitio.visitado)
				visitDFS(sitio);
		}
		tempo++;
		x.tempofinal = tempo;
		rcontrario[x.no].tempofinal = tempo;
	}
	void DFS_inv(){
		int nelementos = 0;
		while (!allvisited()){
			NoS tmax = findmax();
			nelementos = contaelementos(tmax);
			grupos.addLast(nelementos);
			tmax.tempofinal = 0;
		}
	}
	boolean allvisited(){
		for (int i=1;i<=nalu;i++){
			if (!rcontrario[i].visitado)
				return false;
		}
		return true;	
	}
	
	NoS findmax(){
		int maximo = 0;
		NoS max = new NoS(0);
		for (int i=1;i<=nalu;i++){
			if (!rcontrario[i].visitado){
				if (rcontrario[i].tempofinal > maximo){
					maximo = rcontrario[i].tempofinal;
					max = rcontrario[i];
				}
			}
		}
		return max;	
	}
	int contaelementos(NoS x){
		x.visitado = true;
		int count = 1;
		for (NoS sitio: x.adj){
			if (!sitio.visitado)
				count += contaelementos(sitio);
		}
		return count;
	}
	void limpa(){
		for (int i=1;i<=nalu;i++)
			relacao[i].visitado = false;
	}
	void BFS(){
		limpa();
		relacao[1].visitado = true;
		LinkedList<NoS> listadia = new LinkedList<NoS>();
		listadia.addLast(relacao[1]);
		while (!listadia.isEmpty()){
			NoS x = listadia.removeFirst();
			for (NoS qualquer: x.adj){
				if (!qualquer.visitado){
					qualquer.visitado = true;
					qualquer.dia = x.dia +1;
					listadia.addLast(qualquer);
				}
			}
		}
	}
	void ProbA(){
		int amigosum = 0;
		for (int i=1;i<=nalu;i++){
			if (relacao[i].adj.contains(relacao[1]))
				amigosum++;
		}
		System.out.println(amigosum);
	}
	void ProbB(){
		BFS();
		int max = 0;
		for (int i=1;i<=nalu;i++){
			if (relacao[i].dia > max)
				max = relacao[i].dia;
		}
		System.out.println(max);
	}
	void ProbC(){
		int ngrupos = 0;
		ngrupos = grupos.size();
		System.out.println(ngrupos);
	}
}