#include <stdio.h>
#include <stdlib.h>

void partition(int array[], int temp[], int start, int end);
void mergesort(int array[], int temp[], int start, int mid, int end);

int main (){
	int i;
	int arraysize;
	scanf("%d",&arraysize);
	int array[arraysize];
	int temp[arraysize];
	for(i=0; i<arraysize; i++)
		scanf("%d",&array[i]);
	
	partition(array, temp, 0, arraysize-1);
	
	printf("%d",array[0]);
	if (arraysize>1)
		for (i=1; i<arraysize; i++)
			printf(" %d",array[i]);
	printf("\n");
	return 0;
}

void partition(int array[], int temp[], int start, int end){
	int mid;
	if(start<end){
		mid = (start+end)/2;
		partition(array, temp, start, mid);
		partition(array, temp, mid+1, end);
		mergesort(array, temp, start, mid, end);
	}
}

void mergesort(int array[], int temp[], int start, int mid, int high){
	int i, m, k, l;
	l = start;
	i = start;
	m = mid+1;
	
	while((l<=mid)&&(m<=high)){
		if(array[l]<=array[m]){
			temp[i] = array[l];
			l++;
		}
		else{
			temp[i] = array[m];
			m++;
		}
		i++;
	}
	if(l>mid){
		for(k=m; k<=high; k++){
			temp[i] = array[k];
			i++;
		}
	}
	else{
		for(k=l; k<=mid; k++){
			temp[i] = array[k];
			i++;
		}
	}
	for(k=start; k<=high; k++)
		array[k] = temp[k];
}