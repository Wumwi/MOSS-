#include <stdio.h>
#include <stdlib.h>


//void merge(int vec[], int vecSize);
int intcmp(const void *aa, const void *bb);

/*void mergeSort(int v[], int vecSize) {
    int mid;
    
    if (vecSize > 1) {
        mid = vecSize / 2;
        mergeSort(v, mid);
        mergeSort(v + mid, vecSize - mid);
        merge(v, vecSize);
    }
}*/

int intcmp(const void *aa, const void *bb)
{
    const int *a = aa, *b = bb;
    return (*a < *b) ? -1 : (*a > *b);
}


/*void merge(int vec[], int vecSize) {
    int mid;
    int i, j, k;
    int* tmp;
    
    tmp = (int*) malloc(vecSize * sizeof(int));
    if (tmp == NULL) {
        exit(1);
    }
    
    mid = vecSize / 2;
    
    i = 0;
    j = mid;
    k = 0;
    while (i < mid && j < vecSize) {
        if (vec[i] <= vec[j]) {
            tmp[k] = vec[i++];
        }
        else {
            tmp[k] = vec[j++];
        }
        ++k;
    }
    
    if (i == mid) {
        while (j < vecSize) {
            tmp[k++] = vec[j++];
        }
    }
    else {
        while (i < mid) {
            tmp[k++] = vec[i++];
            
        }
    }
    
    for (i = 0; i < vecSize; ++i) {
        vec[i] = tmp[i];
    }
    
    free(tmp);
}
*/
int main()
{
    int n,i=0,aux=0;
    scanf("%d",&n);
    int v[100000]={0};
    
    if(n>=1 && n<=100000){
        for(i=0;i<n;i++){
            scanf("%d",&aux);
            v[i]=aux;
        }
    }
    
    /*
    for(i=0;i<n;i++){
        for(j=i+1;j<n;j++){
            if(v[i]>v[j]){
                aux=v[i];
                v[i]=v[j];
                v[j]=aux;
            }
        }
    }
    */
    
    
    
    //mergeSort(v,n);
    
    qsort(v,n,sizeof(int),intcmp);
    
    for(i=0;i<(n-1);i++)
        printf("%d ",v[i]);
    
    printf("%d",v[i]);
    printf("\n");
   
    return 0;
};