#include <stdio.h>

void mergesort(int v[], int start, int end);
void merge(int v[], int start,int middle,int end);

int main(int argc, char **argv){
  int n, i, num;
  scanf("%d",&n);
  int v[n];

  for(i=0; i<n; i++){
    scanf("%d",&num);
    v[i]=num;
  }

  mergesort(v,0,n-1);

  for(i=0; i<n; i++){
printf("%d",v[i]);
    if(i<n-1)printf(" ");
    else printf("\n");
  }

  return 0;
}

void mergesort(int v[], int start, int end) {
  int middle;

  if(start<end){
    middle=(start+end)/2;
    mergesort(v, start, middle);
    mergesort(v, middle+1, end);
    merge(v, start, middle, end);
  }
}

void merge(int v[],int start,int middle,int end){
  int i,m,k,l,temp[end+1];

  l=start;
  i=start;
  m=middle+1;

  while((l<=middle)&&(m<=end)){

    if(v[l]<=v[m]){
      temp[i]=v[l];
      l++;
    }
    else{
      temp[i]=v[m];
      m++;
    }
    i++;
  }

  if(l>middle){
    for(k=m;k<=end;k++){
      temp[i]=v[k];
      i++;
    }
  }
  else{
    for(k=l;k<=middle;k++){
      temp[i]=v[k];
      i++;
    }
  }
   
  for(k=start;k<=end;k++){
    v[k]=temp[k];
  }
}


