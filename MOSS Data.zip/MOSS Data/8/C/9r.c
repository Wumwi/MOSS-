#include <stdio.h>
void merge();
void mergeSort();

int main(){
    int n, v[n], i;
    scanf("%d", &n);
    for(i=0; i<n; i++){
        scanf("%d", &v[i]);
    }

    int a=0, b=n-1;
    mergeSort(v,a,b);
    for(i=0; i<n-1; i++)
    {
        printf("%d ", v[i]);
    }
    printf("%d\n", v[i]);

    return 0;
}

void mergeSort(int v[], int a, int b)
	{
		if (a<b)
		{
			int m=((a+b)/2);

			mergeSort(v,a,m);
			mergeSort(v,m+1,b);
			merge(v,a,m,b);
		}
	}

void merge(int v[], int a, int m, int b)
	{
		int i =a, j = m+1, k = 0, aux[100000];

		while(i<=m && j<=b)
		{
			if(v[i]<v[j])
			{
				aux[k] = v[i]; i++;
			}
			else
			{
				aux[k]=v[j]; j++;
			}
			k++;
		}

		while(i<=m)
		{
			aux[k]=v[i];
			i++;
			k++;
		}

		for(i=0; i<k; i++)
		{
			v[i+a]=aux[i];
		}
	}
