#include <stdio.h>

#define MAX 1000000

int main() {
    int N;
    scanf("%d", &N);
    int arr[N];
    int count[MAX] = {0};

    for (int i = 0; i < N; i++) {
        scanf("%d", &arr[i]);
        count[arr[i]]++;
    }

    for (int i = 1; i < MAX; i++) {
        while (count[i] > 0) {
            printf("%d ", i);
            count[i]--;
        }
    }
    printf("\n");

    return 0;
}
