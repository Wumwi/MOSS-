#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//InPlace Merge Sort : complexidade temporal theta(n) e complexidade espacial theta(n)

void merge(int v[], int start, int middle, int end){
	int left=start, right=middle+1, aux;
	while(left<=middle && right<=end){
		if(v[left]<=v[right]){
			left++;
		}
		else{
			aux=v[left];
			v[left]=v[right];
			v[right]=aux;
			left++;
			right++;
			middle++;
		}
	}
	
	return;
}

void mergeSort(int v[], int start, int end){
	int middle=(start+end)/2;
	//for(i=0; i<n; i++)
	//	printf("%d\t", v[i]);
	//printf("mergesort %d %d\n", start, end);



	if(start==end) return;

	mergeSort(v, start, middle);
	mergeSort(v, middle+1, end);
	merge(v, start, middle, end);
}


int main(int argc, char **argv){
	int n;
	scanf("%d", &n);
	int v[n], i;
	for(i=0; i<n; i++){
		scanf("%d", &v[i]);
	}	

	mergeSort(v, 0, n-1);

	for(i=0; i<n; i++){
		printf("%d ", v[i]);
	}
	//printf("\n");
	return 0;
}