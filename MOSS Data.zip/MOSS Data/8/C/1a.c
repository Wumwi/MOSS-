#include <stdio.h>

void merge (int v[], int s, int m, int e) {
  int tmp[e-s+1], i, j, c;
  for (c = 0, i = s, j = m+1; c <= e-s; c++) {
    if (j > e)
      tmp[c] = v[i++];
    else if (i > m)
      tmp[c] = v[j++];
    else if (v[i] < v[j])
      tmp[c] = v[i++];
    else
      tmp[c] = v[j++];
  }

  for (c = 0; c <= e-s; c++)
    v[s+c] = tmp[c];
}

void mergesort(int v[], int start, int end) {
  int middle = (start+end)/2;
  if (end-start) {
    mergesort(v, start, middle);
    mergesort(v, middle+1, end);
    merge(v, start, middle, end);
  }
}

int main (void) {
  int n, i;
  scanf("%d", &n);
  int a[n];

  for (i = 0; i < n; i++)
    scanf("%d", a+i);

  mergesort(a, 0, n-1);

  for (i = 0; i < n-1; i++)
    printf("%d ", a[i]);
  printf("%d\n", a[n-1]);
  return 0;
}
