#include <stdio.h>
#include <stdlib.h> 

void merge(int vec[], int vecSize);
 
void mergeSort(int v[], int vecSize) {
  int mid;
 
  if (vecSize > 1) {
    mid = vecSize / 2;
    mergeSort(v, mid);
    mergeSort(v + mid, vecSize - mid);
    merge(v, vecSize);
  }
}

void merge(int vec[], int vecSize) {
  int mid;
  int i, j, k;
  int* tmp;
 
  tmp = (int*) malloc(vecSize * sizeof(int));
  if (tmp == NULL) {
    exit(1);
  }
 
  mid = vecSize / 2;
 
  i = 0;
  j = mid;
  k = 0;
  while (i < mid && j < vecSize) {
    if (vec[i] <= vec[j]) {
      tmp[k] = vec[i++];
    }
    else {
      tmp[k] = vec[j++];
    }
    ++k;
  }
 
  if (i == mid) {
    while (j < vecSize) {
      tmp[k++] = vec[j++];
    }
  }
  else {
    while (i < mid) {
      tmp[k++] = vec[i++];
 
    }
  }
 
  for (i = 0; i < vecSize; ++i) {
    vec[i] = tmp[i];
  }
 
  free(tmp);
}


int main() {

  int n,new, v[100000];
 
  int i;
  scanf("%d",&n);

  //lê numeros
  if((n>=1 && n<=100000)){
    for(i=0;i<n;i++){
      scanf("%d",&new);
      v[i]=new;
    }

    //algoritmo merge-sort
    mergeSort(v,n);
    
    //imprime
    for(i=0;i<(n-1);i++){
      printf("%d ",v[i]);
    }
    printf("%d",v[i]);
    printf("\n");
  }

  return 0;
}

