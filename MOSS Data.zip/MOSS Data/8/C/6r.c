#include <stdio.h>
int main() {

  int n,x,i,j,aux;

  scanf("%d" , &n);
  x=n;
  if(n<1 || n>100000)
    return 1;
 
  int a[x];
  
  for(i=0 ; i<n ; i++){
    scanf("%d" , &a[i]);
  }


  for(i=0 ; i<n ; i++){
    for(j=i+1 ; j<=n ; j++){

      if(a[i] > a[j]){
	aux = a[i];
	a[i] = a[j];
	a[j] = aux;
      }
    }
  }



    for(i=0 ; i<n ; i++)
      printf("%d " , a[i]);
    printf("\n");

    return 0;
}
