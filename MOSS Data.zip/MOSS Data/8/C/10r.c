#include<stdio.h>


int main(void){
  int n;
  int numeros;
  int valores[100000];
  int aux;
  int i,j;
  
  //numero de elementos
  scanf("%d",&numeros);
  if(numeros==1){
    scanf("%d",&n);
    printf("%d\n",n);}
  
  if(numeros>1 && numeros<=100000){
    
    //gravar os elementos na array
    for(i=0;i<numeros;i++){
      scanf("%d",&n);
     
      if(n>=0 && n<1000000){
	valores[i]=n;}}
  
  //comparar
  for(i=0;i<numeros-1;i++){
    for(j=0;j<numeros-1-i;j++){
      if(valores[j] >= valores[j+1]){
	aux = valores[j];
	valores[j] = valores[j+1];
	valores[j+1] = aux;}
    }
  }
  
  
  
  for(i=0;i<numeros;i++) {
    if (i>0) printf(" ");
    printf("%d",valores[i]);
  }

  printf("\n");

  }
  
  return 0;
  
}
