#include<stdio.h>
int main(){
	int size;
	int i;
	int j;
	int swap;
	scanf("%d",&size);
	int v[size];
	for(i=0;i<size;i++){
		scanf("%d",&v[i]);
	}
	for(i=0;i<(size-1);i++){
		for(j=0;j<(size-i);j++){
			if(v[j]>=v[j+1]){
				swap=v[j];
				v[j]=v[j+1];
				v[j+1]=swap;

			}
		}
	}
	for(i=0;i<size-1;i++){
		printf("%d ",v[i]);
	}
	printf("%d\n",v[size-1]);
	return 0;
}
