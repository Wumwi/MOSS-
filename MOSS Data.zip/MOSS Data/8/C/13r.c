/* são precisos 2 arrays v e u de tamanho igual
v é o array principal (com o input inicial e o output final)
e u é usado como array temporario, para juntar as 2 metades ordenadas em a*/

#include<stdio.h>


void merge(int v[], int start, int mid, int end)
{
    int u[10000];
    int i = start, j = mid + 1, k = 0;
  
    while (i <= mid && j <= end) {
        if (v[i] <= v[j])
            u[k++] = v[i++];
        else
            u[k++] = v[j++];
    }
    while (i <= mid)
        u[k++] = v[i++];
  
    while (j <= end)
        u[k++] = v[j++];
  
    k--;
    while (k >= 0) {
        v[start + k] = u[k];
        k--;
    }
}
  
void mergesort(int v[], int start, int end)
{
    if (start < end) {
        int middle = (start + end)/2;
        mergesort(v, start, middle);
        mergesort(v, middle + 1, end);
        merge(v, start, middle, end);
    }
}

int main (void){

  int v[10000];
  int i,n; 

  scanf ("%d", &n);
  for (i=0;i<n;i++){ scanf ("%d", &v[i]);}
  
  mergesort(v,0,n-1);
   for (i=0;i<n;i++){ printf ("%d ", v[i]);}
   printf ("\n");

  return 0; }
