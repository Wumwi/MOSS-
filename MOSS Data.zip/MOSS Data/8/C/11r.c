/* MergeSort Implementation in C for Problem 02 */
#include <stdlib.h>
#include <stdio.h>

#define MAX 10000
 
/* Function to merge the two haves arrays[start..middle] and arrays[m+1..end] of array arrays[] */
void merge(int arrays[], int start, int middle, int end)
{
    int i, j, k;
    int n1 = middle - start + 1;
    int n2 =  end - middle;
 
    /* create temporary arrays */
    int L[n1], R[n2];
 
    /* Copy data to temporary array L[] and R[] */
    for(i = 0; i < n1; i++)
        L[i] = arrays[start + i];
    for(j = 0; j < n2; j++)
        R[j] = arrays[middle + 1+ j];
 
    /* Merge the temp arrays back into arrays[start..r]*/
    i = 0;
    j = 0;
    k = start;
    while (i < n1 && j < n2)
    {
        if (L[i] <= R[j])
        {
            arrays[k] = L[i];
            i++;
        }
        else
        {
            arrays[k] = R[j];
            j++;
        }
        k++;
    }
 
    /* Copy the remaining elements of L[], if there are any */
    while (i < n1)
    {
        arrays[k] = L[i];
        i++;
        k++;
    }
 
    /* Copy the remaining elements of R[], if there are any */
    while (j < n2)
    {
        arrays[k] = R[j];
        j++;
        k++;
    }
}
 
void mergeSort(int arrays[], int start, int end)
{
    if (start < end)
    {
        int middle = start+(end-start)/2;
        mergeSort(arrays, start, middle);
        mergeSort(arrays, middle+1, end);
        merge(arrays, start, middle, end);
    }
}

/* Function to print an array */
void printArray(int A[], int size)
{
    int i;
    for (i=0; i < size; i++)
    {
        if (i>0) printf(" ");
        printf("%d", A[i]);
    }
    printf("\n");
}
 

/*program to read the numbers to sort*/
int main()
{
    int size, arrays[MAX], i;

    scanf("%d", &size);
    if(size<1 || size >1000000) return -1;

    for (i=0;i<size;i++)
    {
        scanf("%d", &arrays[i]);
        if(arrays[i] < 0 || arrays[i] > 1000000) return -1;
    }

    mergeSort(arrays, 0, size -1);
    printArray(arrays, size);
    return 0;
}