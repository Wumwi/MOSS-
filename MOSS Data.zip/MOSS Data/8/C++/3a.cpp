#include <stdio.h>
#include <iostream>
#include <algorithm> 

using namespace std;

int main()
{
  int array[100010];
  int i,n;

  scanf("%d",&n);

  for (i = 0; i < n; i++)
    scanf(" %d",&array[i]);

  sort (array, array + n);

  printf("%d",array[0]);

  for (i = 1; i < n; i++)
    printf(" %d",array[i]);

  printf("\n");

  return 0;
}
