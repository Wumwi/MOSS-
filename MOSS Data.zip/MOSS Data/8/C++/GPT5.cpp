#include <iostream>
#include <vector>

#define MAX 1000000

int main() {
    int N;
    std::cin >> N;
    std::vector<int> count(MAX, 0);
    
    for (int i = 0; i < N; i++) {
        int num;
        std::cin >> num;
        count[num]++;
    }

    for (int i = 1; i < MAX; i++) {
        while (count[i] > 0) {
            std::cout << i << " ";
            count[i]--;
        }
    }
    std::cout << std::endl;

    return 0;
}
