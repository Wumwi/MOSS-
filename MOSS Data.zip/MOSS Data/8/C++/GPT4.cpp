#include <iostream>
#include <vector>

void selectionSort(std::vector<int>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        std::swap(arr[i], arr[minIndex]);
    }
}

int main() {
    int N;
    std::cin >> N;
    std::vector<int> arr(N);
    
    for (int i = 0; i < N; i++) {
        std::cin >> arr[i];
    }

    selectionSort(arr);

    for (int i = 0; i < N; i++) {
        std::cout << arr[i];
        if (i < N - 1) std::cout << " ";
    }
    std::cout << std::endl;

    return 0;
}
