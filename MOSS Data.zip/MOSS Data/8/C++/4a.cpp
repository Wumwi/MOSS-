#include <iostream>
#include <algorithm>
#include <vector> 

#define MAX 100000

using namespace std;

int main() {

	int num = 0;
	int nums[MAX] = { 0 };
	cin >> num;
	for (int i = 0; i != num; i++) {
		cin >> nums[i];
	}
	vector<int> vec(nums, nums + num);
	sort(vec.begin(), vec.end());
	vector<int>::iterator it;
	for (it = vec.begin(); it != vec.end() - 1; ++it) cout << *it << " ";
	cout << *it << '\n';
#ifdef _DEBUG
	system("PAUSE");
#endif
	return 0;
}