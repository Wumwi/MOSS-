#include <stdio.h>
#include <algorithm>

#define MAX 1000005

using namespace std;

int arr[MAX];

int main() {
  int N;

  scanf("%d", &N);

  for(int i = 0; i < N; i++) {
    scanf("%d", &arr[i]);
  }

  sort(arr, arr + N);

  printf("%d", arr[0]);

  for(int i = 1; i < N; i++) printf(" %d", arr[i]);

  printf("\n");

  return 0;
}
