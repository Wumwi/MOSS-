#include <iostream>
#include <vector>
#include <algorithm>

int main( int argc, char **argv )
{
	int num = 0;
	if( !( std::cin >> num ) )
		return -1;

	std::vector<int> nums;
	nums.resize( num );
	for( int i = 0; i < num; ++i )
		if( !( std::cin >> nums[i] ) )
			return -1;

	std::sort( nums.begin( ), nums.end( ) );

	for( int i = 0; i < num; ++i )
		std::cout << ( i != 0 ? " " : "" ) << nums[i];
	std::cout << '\n';

	return 0;
}