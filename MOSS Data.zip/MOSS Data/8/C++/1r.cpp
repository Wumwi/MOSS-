// Exemplo de ordenacao de n numeros inteiros
// ----------------------------------
// Diogo Sousa em parceria com Pedro Ribeiro (DCC/FCUP) - 17/10/2015
// ----------------------------------

#include <iostream>
#include <algorithm>

using namespace std;

int main() {
  int n;
  cin >> n;
  // Um array exemplo 
  // int v[10] = {33, 4, 28, 18, 15, 2, 8, 17, 42, 39};
  int v[n];
  for(int i=0; i<n; i++){
    cin >> v[i];
  }
  
  // cout << " Antes de ordenar: "; 
  for (int i=0; i<n; i++)
    cout << v[i] << " ";
  cout << endl;
  
  // Chamada ao sort padrao da linguagem C++
  // sort(array_inicio, array_final)
  sort(v, v+n);

  // cout << "Depois de ordenar: ";
  for (int i=0; i<n; i++)
    cout << v[i] << " ";
  // cout << endl;

  return 0;
}
