// Exemplo de ordenacao de 10 numeros inteiros
// ----------------------------------
// Pedro Ribeiro (DCC/FCUP) - 17/10/2015
// ----------------------------------

#include <iostream>
#include <algorithm>

using namespace std;

int main() {
	int nNumbers;

	cin >> nNumbers;

	int v[nNumbers];

	for(int i = 0; i < nNumbers; i++){
		cin >> v[i];
	}
	
	// Chamada ao sort padrao da linguagem C++
	// sort(array_inicio, array_final)
	sort(v, v+nNumbers);

	for (int i=0; i<nNumbers-1; i++){
		cout << v[i] << " ";
	}
	cout << v[nNumbers-1]<< endl;
	return 0;
}