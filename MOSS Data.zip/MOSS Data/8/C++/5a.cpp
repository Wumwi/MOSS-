#include <cstdio>

void merge(int v[], int start, int middle, int end){
	
	int i;
	int comp = end+1;
	int array[comp];
	int a=start;
	int b=middle+1;

	for(i=start;i<=end;i++){
		
		if((v[a]<v[b])&&(a<=middle)&&(b<=end)){
			array[i]=v[a];
			a++;
		}
		
		else if((v[a]>=v[b])&&(a<=middle)&&(b<=end)){
			array[i]=v[b];
			b++;
		}
		
		else if((a>middle)&&(b<=end)){
			array[i]=v[b];
			b++;
		}
		
		else{
			array[i]=v[a];
			a++;
		}
		
	}
	
	for(i=start;i<=end;i++)
		v[i] = array[i];
	
}

void mergesort(int v[], int start, int end){
	
	int middle = (start+end)/2;
	if(start==end)  return;
	mergesort(v, start, middle);
	mergesort(v, middle+1, end);
	merge(v, start, middle, end);
	
}

int main(){
	
	int i,n;

	scanf("%d",&n);

	int v[n];
	
	for(i=0;i<n;i++){
		scanf("%d", &v[i]);
	}
	
	mergesort(v,0,n-1);
	
	for(i=0; i<n-1;i++)
		printf("%d ",v[i]); 
	printf("%d\n",v[i]);
	
	return 0;
}