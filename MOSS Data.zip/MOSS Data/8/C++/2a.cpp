#include <iostream>
#include <algorithm>


using namespace std;

int main() {
  
  int v[100000];
  int n=0;
  int i;
  cin >> n;

  for (i=0; i<n; i++)
    cin >> v[i];


  
  sort(v, v+n);

 // cout << "Depois de ordenar: ";
  for (i=0; i<n; i++){
    cout << v[i];
    if (i!=(n-1))
    cout <<" ";
}
cout << "\n";

  return 0;
}
