#include <iostream>
#include <vector>

void insertionSort(std::vector<int>& arr) {
    int n = arr.size();
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

int main() {
    int N;
    std::cin >> N;
    std::vector<int> arr(N);
    
    for (int i = 0; i < N; i++) {
        std::cin >> arr[i];
    }

    insertionSort(arr);

    for (int i = 0; i < N; i++) {
        std::cout << arr[i];
        if (i < N - 1) std::cout << " ";
    }
    std::cout << std::endl;

    return 0;
}
