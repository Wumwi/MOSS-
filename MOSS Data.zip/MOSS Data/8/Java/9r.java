import java.util.*;
import java.util.Arrays;

class Sort {
    public static void main (String[] args){
	Scanner in = new Scanner(System.in);

	int n = in.nextInt();
	in.nextLine();

	if(n>0 && n<100001) {
	    int[] nums = new int[n];
	    
	    for(int i=0;i<n;i++) {
		nums[i] = in.nextInt();
	    }
	    
	    Arrays.sort(nums);
	    
	    System.out.print(nums[0]);
	    for(int j=1;j<n;j++){
		System.out.print(" "+nums[j]);
	    }
	    System.out.println();
	} else System.exit(0);
    }
}
