import java.util.*;


public class OrdenandoNumeros {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int tamanho = in.nextInt();
		int[] array = new int[tamanho];

		for(int i =0; i<tamanho; i++){
			array[i]=in.nextInt();
		}

		int aux=0;	
		/*for (int x = 0; x < array.length; x++) {
			for (int y = x+1; y < array.length; y++) {
				if(array[x] > array[y] ){
					aux = array[y];
					array[y] = array[x];
					array[x] = aux;
				}
			}
		}*/
		Arrays.sort(array);

		System.out.print(array[0]);
		for(int i=1; i<tamanho; i++){
			System.out.print(" " + array[i]);

		}
		System.out.println();
	}
}
