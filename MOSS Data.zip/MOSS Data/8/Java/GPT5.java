import java.util.Scanner;

public class CountingSort {
    private static final int MAX = 1000000;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int N = scanner.nextInt();
        int[] count = new int[MAX];

        for (int i = 0; i < N; i++) {
            int num = scanner.nextInt();
            count[num]++;
        }

        for (int i = 1; i < MAX; i++) {
            while (count[i] > 0) {
                System.out.print(i + " ");
                count[i]--;
            }
        }
        System.out.println();
        
        scanner.close();
    }
}
