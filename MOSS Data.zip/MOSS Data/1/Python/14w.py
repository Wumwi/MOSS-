def CTontas():
    resultado = []
    while True:
        x = input()
        if x == 0: break
        if x in resultado:resultado = resultado[:(resultado.index(x)+1)]
        else:resultado += [x]
    for i in resultado: print i
