def imprime(item):
	for i in item:
		print(i)
def main():
	x=""
	list=[]
	while x!=0:
		x=input()
		if x in list:
			while list[len(list)-1]!=list[list.index(x)]:
				del(list[len(list)-1])
			else:
				list.append(x)
	del(list[len(list)-1])
	return imprime(list)
main()
			