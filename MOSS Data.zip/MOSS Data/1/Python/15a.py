def cigarras():
    res=[]
    i=0
    x=input()
    while x!=0:
        if x not in res:
            res.append(x)
        else:
            i=i-1
            while res[i]!=x:
                res.remove(res[i])
                i=i-1
        i=i+1
        x=input()
        
    for i in range(len(res)):
        print(res[i])

cigarras()

