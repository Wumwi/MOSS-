count = 0

def acerto(n,caminho,count):
   for i in range(count):
      if n == caminho[i]:
         count = i+1
         return caminho[:i+1]

n = int(input())
caminho = []
while ( n != 0):
   if n in caminho:
      caminho = acerto(n,caminho,count)
   else:
      caminho.append(n)
      count+=1
   n = int(input())

for i in range(len(caminho)):
   print(caminho[i])
