def messy_cicadas():
    path = []
    
    # Read input locations
    while True:
        location = int(input())
        if location == 0:
            break
        path.append(location)
    
    # Find the unique last occurrence
    seen = set()
    final_path = [location for location in reversed(path) if not (location in seen or seen.add(location))]
    
    # Print the final path in the correct order
    for location in reversed(final_path):
        print(location)

# Run the function
messy_cicadas()
