def caminho():
    visitados=[]
    caminho=[]
    final=[]
    num=0
    while num != 30:
        num=num+1
        x = input()
        if x != 0:
            visitados.append(x)
        if x == 0:
            visitados.append(x)
            for j in range(0,len(visitados)):
                if visitados[j+1] != 0:
                    if visitados[j+1] in caminho:
                        caminho=[]
                        caminho.append(visitados[j+1])
                    else:
                        caminho.append(visitados[j+1])
                else:
                    final.append(visitados[0])
                    for a in range(len(caminho)):
                        final.append(caminho[a])
                    for h in range(len(final)):
                        print(final[h])
                    break
        
    
        
        
