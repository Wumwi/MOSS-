def cig():

    local = int(input())
    cam=[]
    while local!=0:
        if local in cam:
            for i in range(len(cam)):
                if local==cam[i]:
                    x=i
            
            while x<len(cam)-1:
                cam[x+1]=0
                x=x+1
        

        else:
            cam.append(local)
        local = int(input())

    for i in range(len(cam)):
        if cam[i]!=0:
            print(cam[i])





cig()
         
