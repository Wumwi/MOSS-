from collections import deque

def messy_cicadas():
    path = deque()
    visited = set()
    
    # Read input locations
    while True:
        location = int(input())
        if location == 0:
            break
        path.append(location)
    
    final_path = deque()
    
    # Traverse in reverse order and remove unnecessary visits
    while path:
        location = path.pop()
        if location not in visited:
            final_path.appendleft(location)
            visited.add(location)
    
    # Print the final path
    for location in final_path:
        print(location)

# Run the function
messy_cicadas()
