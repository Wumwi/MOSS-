tamanho = 0
x = int(input())
caminho =[]
while (x!=0):
	if x not in caminho:
		caminho.append(x)
		tamanho=tamanho+1
	else:
		caminho=corrigir(x,caminho,tamanho)
	x=int(input())
for i in caminho:
   print(i)
def corrigir(x,caminho,tamanho):
	for i in range(tamanho):
		if x==caminho[i]:
			tamanho=i+1
			return caminho[:i+1]
