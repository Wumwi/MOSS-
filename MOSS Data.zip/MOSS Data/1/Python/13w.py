def caminho():
    caminho = []
    x=int(input())
    while (x != 0):
        caminho.append(x)
        x=int(input())

    visitados = []
    for i in caminho:
        if i not in visitados:
            visitados.append(i)
        if i in visitados:
            for j in range(len(visitados)):
                if i == visitados[j]:
                    visitados = visitados[:(j+1)]
                    break

    for i in visitados:
        print(i)
        



    
    
