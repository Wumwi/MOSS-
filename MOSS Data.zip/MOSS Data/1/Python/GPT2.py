def messy_cicadas():
    path = []
    frequency = {}
    
    # Read input locations
    while True:
        location = int(input())
        if location == 0:
            break
        path.append(location)
        if location in frequency:
            frequency[location] += 1
        else:
            frequency[location] = 1
    
    final_path = []
    
    # Track the last occurrence of each location
    for location in reversed(path):
        if frequency[location] == 1:
            final_path.append(location)
        else:
            frequency[location] -= 1
    
    # Print the final path in the correct order
    for location in reversed(final_path):
        print(location)

# Run the function
messy_cicadas()
