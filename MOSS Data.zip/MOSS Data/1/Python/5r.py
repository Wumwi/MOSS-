def cigarras():
    l={}
    lista=[]
    for i in range(31):
        inp=input()
        if i==31 and inp!=0:
            return
        if i==31 and inp==0:
            break
        if inp >=10000:
            return		
        if inp==0 :#or i==30:
            break
        else:
            l[i]=int(inp)
          #  print [i]
    tam=len(l)-1        
    
    if l[0]==l[tam]:
        #lista.append(l[tam])
        print(l[0])
        return  
    
    
    final=l[tam]
    id=0
    for j in range(tam+1):
        j=id	    
        while(tam>id):
           # if j==0 and id==final:
           #     if l[tam]==l[id]
           
           if l[tam]==l[id]:
               
               lista.append(l[tam])	
               id=tam+1
               tam=len(l)-1
               
               # if l[tam]==l[id] and j==0 and id==final:
               # lista.append(l[tam])
               # print lista
               # return
           else:
               tam=tam-1		           
        #lista.append(l[id])
        lista=lista+[int(l[id])]
        
        if l[id]==final:
		break
        id=tam+1    	     	
        tam=len(l)-1
        
    tam2=len(lista)    
    for i in range(tam2):		
        print(lista[i]   )
    
cigarras()
