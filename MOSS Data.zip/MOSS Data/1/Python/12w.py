def cig():
    x=1
    v=[]
    while(x!=0):
        x=int(input())
        if x not in v:
            v.append(x)
        else:
            pos=procura_pos(v,x)
            v=apaga(pos,v)
    v.pop()
    for i in range(len(v)):
        print("%d" %v[i])
        

def procura_pos(v,x):
    for i in range(len(v)):
        if v[i]==x:
            return i

def apaga(pos, v):
    
    y=len(v)-pos-1
    for i in range(y): 
        v.pop()
    return v
        
