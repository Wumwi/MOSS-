import sys

def cigarras():
    a=[]
    k=int(input())
    while k!=0:
        a.append(k)
        k=int(input())
    v=[]
    for i in range(len(a)):
        if a[i] not in v:
            v.append(a[i])
        else:
            v=v[:(v.index(a[i]))+1]+v[i:]
    for i in range(len(v)):
        print(v[i])

cigarras()
