list=[]
n=input()
list=[n]
n=input()
p=0
while n != 0:
    i=0
    while i < len(list):
        if list[i]==n:
            p=n
        i+=1
    if p!=0:
        t=len(list)
        while list[t-1] !=n:
            del(list[t-1])
            t-=1
        p=0
    else:
        list=list+[n]
    n=input()
 
for i in list:
    print(i)
