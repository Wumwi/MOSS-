def messy_cicadas():
    stack = []
    visited = set()
    
    # Read input locations
    while True:
        location = int(input())
        if location == 0:
            break
        stack.append(location)
    
    final_path = []
    
    # Use stack to filter unique visits
    while stack:
        location = stack.pop()
        if location not in visited:
            final_path.append(location)
            visited.add(location)
    
    # Print the final path in the correct order
    for location in reversed(final_path):
        print(location)

# Run the function
messy_cicadas()
