def messy_cicadas():
    path = []
    visited = set()
    
    # Read input locations
    while True:
        location = int(input())
        if location == 0:
            break
        path.append(location)
    
    final_path = []
    
    # Traverse in reverse order and remove unnecessary visits
    for location in reversed(path):
        if location not in visited:
            final_path.append(location)
            visited.add(location)
    
    # Print the final path in the correct order
    for location in reversed(final_path):
        print(location)

# Run the function
messy_cicadas()
