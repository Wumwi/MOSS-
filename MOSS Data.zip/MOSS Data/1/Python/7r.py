def cigarraTonta():
    line = int(input())
    list = []
    listfinal = []
    list.append(line)
    while line !=0:
        list.append(line)
        line = int(input())
    for i in range(0, len(list)-1):
        listfinal.append(list[i])
        for j in range(i+1, len(list)-1):
            if list[j]==list[i]:
                list.pop(j)
                j=j-1
    for x in range(0, len(listfinal)-1):
        print(listfinal[x],"\n")
cigarraTonta()
