#Tratamento dos dados

def trat(lis):
    x=0
    lis.reverse()
    for i in range (len(lis)-1):
        for j in range (i+1,len(lis)-1):
           if (lis[i] == lis[j]):
               if (x==0):
                   x=i
               lis.pop(j)
    for i in range (x+1,len(lis)-1):
        lis.pop(i)
    lis.reverse()
    return lis

#input dos dados

def dados(lis):
    x=input()
    while ( x  != 0):
        lis.append(x)
        x=input()
    return lis

#main

def ex3():
    lis=[]
    lis=dados(lis)
    if(lis != []):
        lis=trat(lis)
        if (lis!=[]):
            for i in range (len(lis)):
                print(lis[i])
ex3()
