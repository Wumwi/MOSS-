#include <stdio.h>

int main() {
    int v[10000],val=1,aux;
    int i,contador=0;

    for(i=0;val!=0;i++){
        scanf("%d",&val);
        v[i]=val;
    }
        
    contador=i;
        
    for(i=0;i<contador;i++){
        if(v[i]!=0){
            for(aux=i+1;aux<contador;aux++){
                if(v[aux]==v[i]){
                    for(;aux>i;aux--)
                        v[aux]=0;
                }
            }
        }
    }
    
        for(i=0;i<contador;i++){
            if(v[i]!=0)
                printf("%d\n",v[i]);
        }
    

  
  return 0;
};
