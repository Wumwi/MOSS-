#include <stdio.h>
#define NMAX 2000

int main(int argc, char *argv[])
{
  int vlocal[NMAX], nlocals=0, i=0, j, ocorreu=0,aux,aux2;
  
  scanf("%d",&vlocal[i]);
  
  while(vlocal[i]!=0)
  {
    i++;
    scanf("%d",&vlocal[i]);
    nlocals++;
  }
  
  for(i=0; i < nlocals ; i++)
  {
    for(j=i+1; j < nlocals ; j++)
    {
      if (vlocal[i]==vlocal[j] && ocorreu==0)
      { 
        aux=i;
	ocorreu=1;
      }
      if (vlocal[i]==vlocal[j])
      {
	aux2=j;
      }
    }

    if (ocorreu==1)
    {
      printf("%d\n", vlocal[aux]);
      i=aux2;
    }
    else if (ocorreu==0)
    {
      printf("%d\n",vlocal[i]);
    }
    ocorreu=0;    
  }   
  
return 0;
}