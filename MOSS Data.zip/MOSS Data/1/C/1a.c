#include <stdio.h>

#define N_LOCATIONS 10001

int main() {
  int orig_path[N_LOCATIONS], impr_path[N_LOCATIONS];
  int i1=0, i2, i3, i4, loca, tmp;

  scanf("%d", &loca);
  if (loca != 0) {
    while (loca != 0) {
      orig_path[i1] = loca;
      i1++;
      scanf("%d", &loca);
    }
 
    for (i2=0, i4=0; i2<i1; i2++) {
      tmp = i2;
      for (i3=i2+1; i3<i1; i3++)
	if (orig_path[i2] == orig_path[i3])
	  tmp = i3;
      impr_path[i4] = orig_path[tmp];
      i2 = tmp;
      i4++;
    }
 
    for (i1=0; i1<i4; i1++)
      printf("%d\n", impr_path[i1]);

  }
  return 0;
}
