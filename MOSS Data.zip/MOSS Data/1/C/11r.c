#include <stdio.h>
#define MAX 30

int main() {

  int x[MAX], i=0, n, j;
 
  scanf("%d",&x[i]);
  while (x[i]!=0){
    i++;  
    scanf("%d",&x[i]);
   }

  for (n=0;n<=i-1;n++){
    for (j=n+1;j<=i-1;j++){
      if (x[j]==x[n]){
	n=j;
      }
    }
    printf("%d\n", x[n]);
  }

  return 0;
     
}
