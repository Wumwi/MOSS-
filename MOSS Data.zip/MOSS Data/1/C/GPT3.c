#include <stdio.h>
#include <stdlib.h>

#define MAX_LOCATIONS 10000

int hashTable[MAX_LOCATIONS] = {0};

int main() {
    int path[MAX_LOCATIONS];
    int finalPath[MAX_LOCATIONS];
    int location, index = 0, finalIndex = 0;

    // Read input locations
    while (1) {
        scanf("%d", &location);
        if (location == 0) {
            break;
        }
        path[index++] = location;
    }

    // Traverse in reverse order and remove unnecessary visits
    for (int i = index - 1; i >= 0; i--) {
        if (hashTable[path[i]] == 0) {
            finalPath[finalIndex++] = path[i];
            hashTable[path[i]] = 1;
        }
    }

    // Print in correct order
    for (int i = finalIndex - 1; i >= 0; i--) {
        printf("%d\n", finalPath[i]);
    }

    return 0;
}
