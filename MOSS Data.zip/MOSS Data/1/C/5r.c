#include <stdio.h>

int main (){
	
	int v[30],val=1,i,ii,aux;
	
	for(i=0;val!=0;i++){
		scanf("%d",&val);
		v[i]=val;
	}
	ii=i;
	
	for(i=0;i<ii;i++){
		if(v[i]!=0){
			for(aux=i+1;aux<ii;aux++){
				if(v[aux]==v[i]) {
					for(;aux>i;aux--) v[aux]=0;}}}}
					
	for(i=0;i<ii;i++){
		if(v[i]!=0) printf("%d\n",v[i]);}
	return 0;
	};
