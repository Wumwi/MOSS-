#include <stdio.h>

int main(){
	
	int i,p,h,m;
	int t[30];
	
	i = 10;
	p = 0;
	h = 0;
	m = 0;
	
	while(i!=0){
	scanf("%d",&i);
		while(h<p){
			if(t[h]==i){
				p=h;
				h++;
			}
			else{
				h++;
				}
				}
	t[p] = i;
	p++;
	h=0;
	}
	
	while(m<p){
		printf("%d\n",t[m]);
		m++;
		}
	
	return 0;
	
	}