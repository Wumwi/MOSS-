#include <stdio.h>
int main ()
 {
  int entrada[30]={0}, saida[30]={0},i, j, conta, numero, t, p;
  i=0;
  scanf("%d", &numero);
  j=0;
  while(numero != 0){
    entrada[i]=numero;
    i=i+1;
    scanf("%d", &numero);
  }
  t=i-1;
  p=0;
  while (t>=j) {
    saida[p]=entrada[j];
    conta=j+1;
    while(conta<=i){
      if(entrada[j]==entrada[conta]){
	j=conta;
	conta=i;
      }
      else{
	conta=conta+1;
      }
    }
    j=j+1;
    p=p+1;
  }
  t=0;
  while(t<p){
    printf("%d\n",saida[t]);
    t=t+1;
}
  return 0;
}

