#include <stdio.h>
int main()
{
    int local, n, caminho[30], i;
    scanf("%d", &local);
    caminho[0] = local;
    n = 1;
    scanf("%d", &local);
    while (local != 0){
        i = 0;
        while (i < n && caminho[i] != local){
            
            i = i + 1;
            if (i == n){
                caminho[n] = local;
                n = n + 1;
            }

        }
        
        if ((i + 1) != n){
            
            n = i + 1;
        }
        scanf("%d", &local);
    }
    for (i = 0; i < n; i++){
        printf("%d\n", caminho[i]);
    }
    return 0;
}
