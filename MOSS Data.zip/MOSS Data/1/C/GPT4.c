#include <stdio.h>

#define MAX_LOCATIONS 10000

int stack[MAX_LOCATIONS];
int visited[MAX_LOCATIONS] = {0};

int main() {
    int top = -1, location;

    // Read input locations
    while (1) {
        scanf("%d", &location);
        if (location == 0) {
            break;
        }
        
        if (top == -1 || stack[top] != location) {
            stack[++top] = location;
        }
    }

    // Mark visited and filter the correct path
    for (int i = 0; i <= top; i++) {
        if (!visited[stack[i]]) {
            visited[stack[i]] = 1;
            printf("%d\n", stack[i]);
        }
    }

    return 0;
}
