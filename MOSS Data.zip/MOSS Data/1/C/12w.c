#include <stdio.h>


int main(){
  int final[30];
  int x;
  int y=0;
  int z;
  int aux=1;
  for(x=0;x<30&&aux!=0;x++){
    
    scanf("%d",&aux);


    if(aux!=0&&aux<10000){
      if(x==0){

	final[x]=aux;
	y++;

      }

      else{

	for(z=0;z<y;z++){

	  if(final[z]==aux){
	    y=z+1;
	  }
	  
	}
	
	if(final[y-1]!=aux){
	  final[y]=aux;
	  y++;
	}
      }
      
    }

  }
  if(y!=0){
    for(x=0;x<y;x++){
      printf("%d\n",final[x]);
    }
  }
  return 0;
}
