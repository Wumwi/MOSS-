#include <stdio.h>

int main() {

int locais[30]={0}, local, i=0, actual=0;

scanf ("%d", &local);

	while (local != 0) {
	
		while (i <= actual) {
			
			if (local != locais[i]) {
					i++;
			}
			else {
				actual=i;
				i++;
			}
		
		}
	
		locais[actual]=local;
		scanf("%d", &local);
		i=0;
		actual++;
	}
	
locais[actual]=0;
	
	

	while (locais[i] != 0) {
		printf("%d\n", locais[i]);
		i++;
	}
		
return 0;	
}
