#include <stdio.h>

int main(){

  int i=0,k,locais,v[30], aux=0;
  scanf("%d",&locais);
  v[i]=locais;
  while(locais!=0){
    i++;
    scanf("%d",&locais);
    v[i]=locais;
    for(k=0;k<=i;k++){
      if(v[k]==v[i])
	i=k;
    }
  }
  
  while(aux<i){
    
    printf("%d\n",v[aux]);
    aux++;
  }
  return 0;
}
    
  
    
      


	
 

