#include <stdio.h>
#include <stdlib.h>

#define MAX_LOCATIONS 10000

typedef struct Node {
    int data;
    struct Node *next;
} Node;

Node *head = NULL;

void addNode(int data) {
    Node *newNode = (Node *)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = head;
    head = newNode;
}

void printListReverse(Node *node) {
    if (node == NULL) return;
    printListReverse(node->next);
    printf("%d\n", node->data);
}

int main() {
    int location;
    int visited[MAX_LOCATIONS] = {0};

    // Read input locations
    while (1) {
        scanf("%d", &location);
        if (location == 0) {
            break;
        }

        if (!visited[location]) {
            addNode(location);
            visited[location] = 1;
        }
    }

    // Print path in the correct order
    printListReverse(head);

    // Free memory
    while (head != NULL) {
        Node *temp = head;
        head = head->next;
        free(temp);
    }

    return 0;
}
