#include <stdio.h>

int main() {
int loc, local[1000], aux[1000], i, j, k, l;

scanf("%d",&loc);
local[0]=loc;

for(i=0;i<30;i++)
	local[i]=0;

for(i=0;loc!=0;i++){
	aux[i]=loc;
	scanf("%d",&loc);}
	
for(j=0, l=0;j<=i;l++,j++){
	for(k=j+1;k<=i;k++){
		if(aux[j]==aux[k]){
			local[l]=aux[k];
			j=k;}
		else
			local[l]=aux[j];
	}
}

for(i=0;local[i]!='\0';i++)
	printf("%d\n",local[i]);
	
return 0;
}

