#include <stdio.h>
#include <stdlib.h>


int main()
{
    printf("Hello world!\n");

    int lugar, caminho[10000], i = 0;
     int j = 0;
    scanf("%d", &lugar);
    while (lugar != 0) {
        caminho[i] = lugar;

        for (j = 0; j < 60; j++) {
            if (caminho[j] == lugar) {
                break;
            }
        }

        i = j +1;

        scanf("%d", &lugar);
    }


    for (j = 0; j < i; j++) {
        printf("%d\n", caminho[j]);
    }
    return 0;
}

