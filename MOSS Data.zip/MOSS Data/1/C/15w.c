
#include <stdio.h>

int main()
{
	int x[100];
	int i, j,n, local;
	scanf("%d",&local);
	x[0]=local;
	n=1;
	scanf("%d",&local);
	while(local!=0){
		i=0;
		while (i<n && x[i]!=local){
			i++;
		}
		if (i==n){
			x[i]=local;
			n++;
		}
		scanf("%d",&local);
	}
	j=0;
	while (j<n){
		printf("%d\n",x[j]);   
		j++;
	}
	
	return 0;
}

