#include <stdio.h>

int main()
{
	int x[30];
	int i = 0;
	int j;

	int k;

	for(k = 0; k < 30; k++)
		x[k] = 0;

	scanf("%d", &k);

	while(k != 0)
    {
		int z;
		for(z = i-1; z >= 0; z--)
		{
			if(x[z] == k)
				break;
		}
		
		if(z >= 0)
		{
			if(x[z] != k)
			{
				x[i++] = k;
			} else
			{
				i = z+1;
			}
		}else
		{
			x[i++] = k;
		}

		scanf("%d", &k);
    }

	for(j = 0; j < i; j++)
		printf("%d\n", x[j]);

	return 0;
}
