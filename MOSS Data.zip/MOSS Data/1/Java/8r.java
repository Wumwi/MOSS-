import java.util.*;
import java.io.*;

//test

class ProbA{
	
	public static void main (String args[]){
		int x, y;
		x=y=0;
		int aux=0;
		int a=0;
		int vector[] = new int [31];
		Scanner kb = new Scanner(System.in);
		
		
		//Input
		
		for(int b=0; b<31; b++){
			vector[b]=kb.nextInt();
			if (vector[b]==0){
				aux = b;
				break;
			}
		}
		
		
		//Tratamento do vector
		
		for(int c=0; c<aux; c++){
			for (int n=(c+1); n<aux; n++){
				if (vector[c] == vector [n]){
					for(int d=c; d<n; d++){
						vector[d]=-1;
					}
				}			
			}
		}
				
				
		//Output
		
		for (int i=0; i<aux-1; i++){
			if(vector[i]>0){
			System.out.println(vector[i]);
			}
		}
		System.out.print(vector[aux-1]);
		
		}
}