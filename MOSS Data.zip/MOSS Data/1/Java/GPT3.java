import java.util.HashSet;
import java.util.Scanner;
import java.util.Stack;

public class MessyCicadas3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Stack<Integer> stack = new Stack<>();
        HashSet<Integer> visited = new HashSet<>();
        
        // Read input locations
        while (true) {
            int location = scanner.nextInt();
            if (location == 0) break;
            stack.push(location);
        }
        
        Stack<Integer> finalPath = new Stack<>();
        
        // Use the stack to store unique locations
        while (!stack.isEmpty()) {
            int location = stack.pop();
            if (!visited.contains(location)) {
                finalPath.push(location);
                visited.add(location);
            }
        }
        
        // Print the final path
        while (!finalPath.isEmpty()) {
            System.out.println(finalPath.pop());
        }
    }
}
