import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class MessyCicadas4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> path = new ArrayList<>();
        HashMap<Integer, Integer> frequencyMap = new HashMap<>();
        
        // Read input locations
        while (true) {
            int location = scanner.nextInt();
            if (location == 0) break;
            path.add(location);
            frequencyMap.put(location, frequencyMap.getOrDefault(location, 0) + 1);
        }
        
        ArrayList<Integer> finalPath = new ArrayList<>();
        
        // Only add last occurrence of each location
        for (int i = path.size() - 1; i >= 0; i--) {
            int location = path.get(i);
            if (frequencyMap.get(location) == 1) {
                finalPath.add(0, location);
            } else {
                frequencyMap.put(location, frequencyMap.get(location) - 1);
            }
        }
        
        // Print the final path
        for (int loc : finalPath) {
            System.out.println(loc);
        }
    }
}
