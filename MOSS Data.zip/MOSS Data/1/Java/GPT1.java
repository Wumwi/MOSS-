import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class MessyCicadas1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> path = new ArrayList<>();
        HashSet<Integer> visited = new HashSet<>();
        
        // Read input locations
        while (true) {
            int location = scanner.nextInt();
            if (location == 0) break;
            path.add(location);
        }
        
        ArrayList<Integer> finalPath = new ArrayList<>();
        
        // Traverse in reverse order and remove unnecessary visits
        for (int i = path.size() - 1; i >= 0; i--) {
            int location = path.get(i);
            if (!visited.contains(location)) {
                finalPath.add(0, location);
                visited.add(location);
            }
        }
        
        // Print the final path
        for (int loc : finalPath) {
            System.out.println(loc);
        }
    }
}
