
import java.util.Scanner;

public class CigarrasTontas {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int test = 0, n = 0, local;
        int ivisitados[] = new int[10000];
        
        while(test == 0){
            local = sc.nextInt();
            if(local == 0) test = 1;
            else{
                ivisitados[n] = local;
                n++;
            }
        }
        
        int n2 = 0;
        int fvisitados [] = new int[n];
        
        for(int i = 0; i < n; i++){
            fvisitados[n2] = ivisitados[i];
            for(int j = i; j < n; j++){
                if(ivisitados[j] == ivisitados[i]){
                    i = j;
                }
            }
            n2++;
        }
        
        for(int i = 0; i < n2; i++){
            System.out.println(fvisitados[i]);
        }
    }
}
