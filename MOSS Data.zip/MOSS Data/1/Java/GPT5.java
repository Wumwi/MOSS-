import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeSet;

public class MessyCicadas5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> path = new ArrayList<>();
        
        // Read input locations
        while (true) {
            int location = scanner.nextInt();
            if (location == 0) break;
            path.add(location);
        }
        
        TreeSet<Integer> finalPathSet = new TreeSet<>();
        
        // Traverse in reverse order and use TreeSet to remove duplicates
        for (int i = path.size() - 1; i >= 0; i--) {
            finalPathSet.add(path.get(i));
        }
        
        // Print the final path
        for (int loc : finalPathSet) {
            System.out.println(loc);
        }
    }
}
