import java.util.*;

public class problemaC {
	public static void main(String[] args) {
		Scanner ip = new Scanner(System.in);
		int caminhop[] = new int[1000];
		int passos = 0;
		int p = ip.nextInt();
		int i = 0;
		while(p!=0){
			caminhop[i] = p;
			i++;
			p = ip.nextInt();
		}
		passos = i;

		for(int k = 0;k<passos;k++){
			int vv = 0;
			System.out.println(caminhop[k]);
			int j = k+1;;
			for(j=k+1;j<passos;j++){
				if(caminhop[k] == caminhop[j]){ vv = 1;k=j;}
			}
		}
	}
}
