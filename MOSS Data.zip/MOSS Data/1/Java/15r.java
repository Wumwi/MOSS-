import java.awt.List;
import java.util.ArrayList;
import java.util.Scanner;


public class Topas_C {
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		int lista[] = new int[1000];
		int k=1;
		int i=0;
		while(k!=0){
			k=in.nextInt();
			lista[i]=k;
			i++;
		}
		for(int j=0;j<i+1;j++){
			for(int l = j+1; l < i+1 ;l++){
				if(lista[j] == lista[l]){
					removeValores(lista,j,l);
					j=l-1;
					j++;
				}
			}
		}
		for(int j=0;j<i;j++){
			if(lista[j]!=0){
				System.out.println(lista[j]);
			}
		}
	}

	private static void removeValores(int lista[],int j, int l) {
		while(j<l){
			lista[j]=0;
			j++;
		}
		
	}
}
