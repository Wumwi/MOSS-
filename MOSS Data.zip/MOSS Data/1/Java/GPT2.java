import java.util.LinkedList;
import java.util.Scanner;

public class MessyCicadas2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LinkedList<Integer> path = new LinkedList<>();
        
        // Read input locations
        while (true) {
            int location = scanner.nextInt();
            if (location == 0) break;
            path.add(location);
        }
        
        LinkedList<Integer> finalPath = new LinkedList<>();
        
        // Traverse and remove unnecessary visits
        for (int i = path.size() - 1; i >= 0; i--) {
            int location = path.get(i);
            if (!finalPath.contains(location)) {
                finalPath.addFirst(location);
            }
        }
        
        // Print the final path
        for (int loc : finalPath) {
            System.out.println(loc);
        }
    }
}
