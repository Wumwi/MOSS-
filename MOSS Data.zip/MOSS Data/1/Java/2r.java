import java.util.Scanner;

public class Cigarra {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		int vector[]=new int[30]; int i=0;
		int n = ler.nextInt(); 
		while(n!=0){
			vector[i]=n;
			n = ler.nextInt();
			i++;
		}
		
		for(int j=0;j<30;j++){
			for(int c=1;c<30;c++){
				if(vector[j]==vector[c])
					j=c;
				
			}
			if(vector[j]==0)
				break;
			
			System.out.println(vector[j]);
		}
		
		
	}
	
}
