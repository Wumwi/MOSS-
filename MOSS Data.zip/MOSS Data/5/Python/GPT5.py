def find(parent, a):
    if parent[a] != a:
        parent[a] = find(parent, parent[a])
    return parent[a]

def union(parent, a, b):
    parent[find(parent, a)] = find(parent, b)

def main():
    min_width, max_width, min_length, max_length, min_height = map(int, input().split())
    start, end = map(int, input().split())
    
    parent = [i for i in range(100)]

    while True:
        line = input().strip()
        if line == '-1':
            break
        u, v, width, length, height = map(int, line.split())
        
        if width >= min_width and height >= min_height:
            union(parent, u, v)

    print(min_length if find(parent, start) == find(parent, end) else 0)

if __name__ == "__main__":
    main()
