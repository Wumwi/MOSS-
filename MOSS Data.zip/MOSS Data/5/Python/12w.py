def encomenda():
    g = {}
    firstline = readinput()
    [origem,destino] = readinput()
    g[origem] = []
    g[destino] = []
    while True:
        lista = readinput()
        if lista[0] == -1 : break 
        [u,v,l,c,a] = lista
        if verifica(firstline,l,c,a) == True:
            c = min(c,firstline[3])
            if u not in g: g[u] = []
            if v not in g: g[v] = []
            g[u].append((v,c))
            g[v].append((u,c))
    
    Q = PQ()
    print(Q)
    comp = {}
    for x in g:
        comp[x] = 0
        Q.push(x,comp[x])
    comp[origem] = 2**30
    Q.change_pri(origem,2**30)
    visited = set()
    while not Q.empty():
        u = Q.front()
        Q.pop()
        visited.add(u)
        for (v,c) in g[u]:
            if v not in visited:
                k = min(comp[u],c)
                if comp[v]< k:
                    comp[v] = k
                    Q.change_pri(v,k)
    print(comp[destino])

def verifica(firstline,l,c,a):  
    if  firstline[0] <= l :
        if firstline[2] <= c:
            if firstline[4] <= a:
                return True
    return False


class PQ:
    def __init__(self):
        self.data = {}
    def front(self):
        f = -1
        for x in self.data:
            if f<0 or self.data[x]>self.data[f]: f = x
        return f
    def pop(self):
        del self.data[self.front()]
    def push(self,key,pri):
        self.data[key] = pri
    def change_pri(self,key,pri):
        self.data[key] = pri
    def empty(self):
        return self.data == {}

def readinput():
     return map(int,input().split())

encomenda()
