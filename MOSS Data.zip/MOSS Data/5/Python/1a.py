Q = []
arcos = {}
adj = {}
dist = {}

def encomenda():
	x = input().split()
	lmin = int(x[0])
	lmax = int(x[1])
	cmin = int(x[2])
	cmax = int(x[3])
	amin = int(x[4])
	x = input().split()
	origem = int(x[0])
	destino = int(x[1])
	
	while True:
		x = input().split()
		ori = int(x[0])
		if ori == -1: break
		dest = int(x[1])
		larg = int(x[2])
		comp = int(x[3])
		alt = int(x[4])
		
		if larg >= lmin and alt >= amin and comp >= cmin:
			arcos[(ori,dest)] = comp
			arcos[(dest,ori)] = comp
			if ori not in Q: Q.append(ori)
			if dest not in Q: Q.append(dest)
			
			try:
				adj[ori].append(dest)
			except:
				adj[ori] = [dest]
				
			try:
				adj[dest].append(ori)
			except:
				adj[dest] = [ori]
	z = dijkstra(cmax,origem,destino)
	if z != None: print z
	else: print 0
	
def dijkstra(cmax,origem,destino):
	for i in Q:
		dist[i] = 0
	dist[origem] = cmax
	
	while Q != []:
		a = getMin()
		u = Q[a]
		del(Q[a])
		if u == destino:
			return dist[u]
		for v in adj[u]:
			alt = max(min(dist[u],arcos[(u,v)]),dist[v])
			if alt > dist[v]:
				dist[v] = alt

def getMin():
	maxValue = 0
	indice = 0
	for i in range(len(Q)):
		if dist[Q[i]] > maxValue:
			maxValue = dist[Q[i]]
			indice = i
	return indice

encomenda()