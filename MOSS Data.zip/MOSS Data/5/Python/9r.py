def dados():
    lista = []
    a = input()
    a = string.split(a)
    for x in a:
        lista = lista + [int(x)]
    return lista


def encomenda():
    grafo = {}
    larg_min,larg_max,comp_min,comp_max,alt_min = dados()
    origem,destino = dados()

    while True:
        aux = dados()

        if aux != [-1]:
            orig, dest, maxlargura, maxcomp, maxaltura = aux

            if not ((aux[2] < larg_min) or (aux[3] < comp_min) or (aux[4] < alt_min)):
                if orig not in grafo:
                    grafo[orig] = {}
                if dest not in grafo:
                    grafo[dest] = {}

                aux =  maxcomp
                grafo[orig][dest] = aux
                grafo[dest][orig] = aux
        else:
            break
	print(grafo)

    if origem in grafo and destino in grafo:
        print(dijkstra(grafo,origem,destino,comp_max))
    else:
        print(0)



def dijkstra(dic,inicio,fim,compMax):
    distancia = {}
    visitados = []
    for i in dic:
        distancia[i] = 0
    distancia[inicio] = compMax
    while len(dic) > len(visitados):
        maior = -1
        vertice = 0
        for i in distancia:
            if i not in visitados:
                if distancia[i] > maior:
                    vertice = i
                    maior = distancia[i]

        visitados.append(vertice)
        for j in dic[vertice]:
            if j not in visitados:
                distancia[j] = max(min(distancia[vertice],dic[vertice][j]), distancia[j])

    return distancia[fim]

 

        
encomenda()
