def readln(): return map(int,input().split())

def encomenda():
    g={}
    lmin,lmax,cmin,cmax,amin=readln()
    noi,nof=readln()
    aresta=readln()
    while aresta[0]!=-1:
        if (aresta[2]>=lmin and aresta[2]<=lmax and aresta[3]>=cmin and aresta[3]<=cmax and aresta[4]>=amin):
            g=insere(aresta,g)
        aresta=readln()
    print(dijkstra(g,noi,nof,cmax))

def dijkstra(g,noi,nof,cmax):
    dist={}
    visitados=[]
    for i in g.keys():
        dist[i]=0
    dist[noi]=cmax
    visit=0
    n=len(g)
    while visit<n:
        maior=-1
        v=0
        for i in dist:
            if i not in visitados:
                if dist[i]>maior:
                    v=i
                    maior=dist[i]
        visitados.append(v)
        visit+=1
        for w in g[v].keys():
            if w not in visitados:
                dist[w]= max(dist[w],min(dist[v],g[v][w]))
    return dist[nof]

def insere(aresta,g):
    a=aresta[0]
    b=aresta[1]
    c=aresta[3]
    try:
        g[a][b]=c
    except KeyError:
        g[a]={}
        g[a][b]=c
    try:
        g[b][a]=c
    except KeyError:
        g[b]={}
        g[b][a]=c
    return g

encomenda()
