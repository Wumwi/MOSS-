from collections import defaultdict, deque

def bfs(graph, start, end, min_width, min_height):
    queue = deque([(start, float('inf'))])
    visited = set()
    
    while queue:
        node, length = queue.popleft()
        if node == end:
            return length

        for edge in graph[node]:
            width, length_edge, height = edge
            if edge[0] not in visited and width >= min_width and height >= min_height:
                visited.add(edge[0])
                new_length = min(length, length_edge)
                queue.append((edge[0], new_length))
                
    return 0

def main():
    min_width, max_width, min_length, max_length, min_height = map(int, input().split())
    start, end = map(int, input().split())
    
    graph = defaultdict(list)
    
    while True:
        line = input().strip()
        if line == '-1':
            break
        u, v, width, length, height = map(int, line.split())
        graph[u].append((v, width, length, height))
        graph[v].append((u, width, length, height))

    result = bfs(graph, start, end, min_width, min_height)
    print(result)

if __name__ == "__main__":
    main()
