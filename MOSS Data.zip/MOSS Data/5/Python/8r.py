def jaula():
    min,lmax,cmin,cmax,hmin = input().split(' ')
    lmin=int(lmin)
    lmax=int(lmax)
    cmin=int(cmin)
    cmax=int(cmax)
    hmin=int(hmin)
    start,end = input().split(' ')
    start=int(start)
    end=int(end)
    graph = {}
    testes = {}
    linhas = []
    # Input e construcao do grafo
    while linhas != '-1':
        linhas = []
        dados = []
        linhas = input()
        if linhas != '-1':
            s,f,l,c,h = linhas.split()
            s = int(s)
            f = int(f)
            l = int(l)
            c = int(c)
            h = int(h)
            if l>=lmin and c>=cmin and h>=hmin:
                dados += [l,c,h]
                testes[s,f] = l,c,h
                testes[f,s] = l,c,h
                if s not in graph:
                    graph[s] = [f]
                else:
                    graph[s] += [f]
                if f not in graph:
                    graph[f] = [s]
                else:
                    graph[f] += [s]
    if graph.has_key(start) and graph.has_key(end):
        print(dijkstra(graph, start, end, testes, cmax))
    else:
        print(0)

def dijkstra(graph, start, end, testes, cmax):
    visited=[]
    distance={}
    for i in graph:
        distance[i]=0
        distance[start]=cmax
        while len(graph)>len(visited):
            length=-1
            edge=0
            for i in distance:
                if i not in visited:
                    if distance[i]>length:
                        edge=i
                        length=distance[i]
            visited.append(edge)
            for i in graph[edge]:
                if i not in visited:
                    distance[i]=max(min(distance[edge],testes[edge,i][1]), distance[i])
       
        return distance[end]
       
       


jaula()
