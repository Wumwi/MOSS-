import heapq
from collections import defaultdict

def dijkstra(graph, start, end, min_width, min_height):
    max_length = {node: 0 for node in graph}
    max_length[start] = float('inf')
    pq = [(-max_length[start], start)]  # Max-heap

    while pq:
        curr_length, node = heapq.heappop(pq)
        curr_length = -curr_length

        if node == end:
            return curr_length

        for edge in graph[node]:
            width, length, height = edge
            if width >= min_width and height >= min_height:
                new_length = min(curr_length, length)
                if new_length > max_length[edge[0]]:
                    max_length[edge[0]] = new_length
                    heapq.heappush(pq, (-new_length, edge[0]))

    return 0

def main():
    min_width, max_width, min_length, max_length, min_height = map(int, input().split())
    start, end = map(int, input().split())
    
    graph = defaultdict(list)
    
    while True:
        line = input().strip()
        if line == '-1':
            break
        u, v, width, length, height = map(int, line.split())
        graph[u].append((v, width, length, height))
        graph[v].append((u, width, length, height))

    result = dijkstra(graph, start, end, min_width, min_height)
    print(result)

if __name__ == "__main__":
    main()
