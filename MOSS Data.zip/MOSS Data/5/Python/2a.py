def encomenda():
    #cria um dicionario para guardar todas as ligacoes e os respectivos comprimentos
    g = {}
    #le a primeira linha do input
    firstline = readinput()
    #le a origem e o destino da encomenda
    [origem,destino] = readinput()
    #adiciona ao dicionario o ponto de origem e destino
    g[origem] = []
    g[destino] = []
    #le as varias linhas de input seguintes
    while True:
        lista = readinput()
        if lista[0] == -1 : break #caso seja -1 termina o input
        [u,v,l,c,a] = lista #guarda os valores das linhas seguintes
        if verifica(firstline,l,c,a) == True: #verifica se o caminho indicado permite a passagem da jaula com as medidas minimas do caminho
            c = min(c,firstline[3]) #compara o comprimento inserido com o comprimento maximo da jaula e guarda o mais pequeno dos dois
            if u not in g: g[u] = [] #se o ponto de partida nao existir no dicionario, insere-o
            if v not in g: g[v] = [] #se o ponto de destino nao existir no dicionario, insere-o
            g[u].append((v,c)) #ao ponto de partida junta-se o ponto de destino e o comprimento maximo que a jaula pode ter
            g[v].append((u,c)) #ao ponto de destino junta-se o ponto de partida e o comprimento maximo que a jaula pode ter

    Q = PQ() #Cria um objecto com o nome do tipo PQ (priority queue)
    comp = {} #dicionario com os comprimentos

    #coloca o ponto de inicio e de destino da encomenda com comprimento igual a zero
    for x in g:
        comp[x] = 0
        Q.push(x,comp[x])

    comp[origem] = 2**30 #coloca o comprimento de origem com um valor surrealmente grande
    Q.change_pri(origem,2**30) #muda o valor do comprimento do no dado
    visited = set() #cria um conjunto para guardar os nos visitados
    while not Q.empty(): #enquanto a fila nao estiver vazia
        u = Q.front() #observa e retira o elemento do topo da queue
        Q.pop()
        visited.add(u) #adiciona esse ponto ao conjunto dos nos visitados
        for (v,c) in g[u]: #percorre todas as ligacoes que partem do ponto u
            if v not in visited: #se o ponto de destino nao estiver no conjunto dos pontos visitados
                k = min(comp[u],c) #guarda o comprimento minimo entre o ponto de origem e o caminho que se esta a observar
                if comp[v]< k: #se o comprimento previamente calculado para esse ponto for menor que k
                    comp[v] = k # entao nos queremos o maximo de ambos
                    Q.change_pri(v,k) #actualizamos o valor na estrutura de dados
    return comp[destino]

#verifica se as medidas do caminho introduzido sao suficientes para passar a jaula com as medidas minimas
#retorna True caso consiga passar a jaula com medidas minimas e retorna False caso contrario
def verifica(firstline,l,c,a):
    if  firstline[0] <= l :
        if firstline[2] <= c:
            if firstline[4] <= a:
                return True
    return False

#classe com a priority queue
class PQ:
    def __init__(self): #inicia a priority queue
        self.data = {}
    def front(self): #retorna o elemento do topo da priority queue
        f = -1
        for x in self.data:
            if f<0 or self.data[x]>self.data[f]:
                f = x
        return f
    def pop(self): #retorna o primeiro elemento da priority queue
        del self.data[self.front()]
    def push(self,key,pri): #insere um elemento na queue
        self.data[key] = pri
    def change_pri(self,key,pri): #altera o valor na estrutura de dados
        self.data[key] = pri
    def empty(self): #retorna True se a queue estiver vazia
        return self.data == {}

def readinput():
    return map(int,input().split())

print(encomenda())
