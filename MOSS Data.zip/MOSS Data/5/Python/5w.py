import string

pred={}
d={}
visited=[]

def ler():
    lista = []
    a = input()
    a = string.split(a)
    for x in a:
        lista = lista + [int(x)]
    return lista

def encomenda():
    G={}
    w={}
    global Q
    (lmin,lmax,cmin,cmax,alt)=ler()
    (origem,destino)=ler()
    linha=ler()
    while(len(linha)!=1):
        (o,dt,l,c,a)=linha
        if(lmin<=l and cmin<=c and a<=alt):
            c=min(c,cmax)
            w[(o,dt)]=c
            w[(dt,o)]=c
            if o not in G:
                G[o]=[dt]
            else:
                G[o]+=[dt]
            if dt not in G:
                G[dt]=[o]
            else:
                G[dt]+=[o]
    
        linha=ler()

    #print "Pesos",w,"\n"
    #print "GRAFO=",G,"\n"
    #return 1
    Q=G.keys()
    Dijkstra(G,w,origem)
    #print "\nDistancias",d,"\n"
    #print "\n",pred,"\n"
    try:
        print(d[destino])
    except:
        print(0)
    
def Dijkstra(G,w,s):
    INITIALIZE_SINGLE_SOURCE(G,s)
    while Q!=[]:
        u=EXTRACT_MAX(Q)
        #print "asjhdjahs", u
        if u==0:
            return 0
        visited.append(u)
        for v in G[u]:
            if v not in visited:
                RELAX(u,v,w)            
   #for i in visited:
    #   print i,

def INITIALIZE_SINGLE_SOURCE(G,s):
    for v in G:
        d[v]=0
        pred[v]=[]
    d[s]=1e10000

def EXTRACT_MAX(Q):
    VMaiorPeso=0
    maxx=0
    #print "Q=",Q
    for v in Q:
        #print d
        if(d[v]>maxx):
            maxx=d[v]
            VMaiorPeso=v
    #print Q
    #print "D=",d[v]
    #print "maxx=",maxx
    #print "max",VMaiorPeso
    if VMaiorPeso == 0:
        return 0
    else:
        Q.remove(VMaiorPeso)
        return VMaiorPeso

def RELAX(u,v,w):
    Max=max((min(w[(u,v)],d[u])),d[v])
    if(Max>d[v]):
        d[v]=Max
        pred[v]=u

encomenda()
