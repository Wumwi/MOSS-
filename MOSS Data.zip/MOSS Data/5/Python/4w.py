def jaula():

	dimensoes=input().split()
	dimensoes=converte(dimensoes)
	
	min_larg = dimensoes[0]
	max_larg = dimensoes[1]
	min_comp = dimensoes[2]
	max_comp = dimensoes[3]
	min_alt  = dimensoes[4]
	
	orig_dest = input().split()
	orig_dest = converte(orig_dest)
	
	origem  = orig_dest[0]
	destino = orig_dest[1]
	
	vertices = []
	pesos    = []
	valores  = []
	while True:
		caminho = input()
		if caminho == "-1":
			break
		caminho = caminho.split()
		caminho = converte(caminho)
		
		orig = caminho[0]
		dest = caminho[1]
		larg = caminho[2]
		comp = caminho[3]
		alt  = caminho[4]		
		if larg >= min_larg and comp >= min_comp and alt >= min_alt:
			vertices += [[orig,dest]]
			pesos    += [comp]
			
			if orig not in valores:
				valores += [orig]
			if dest not in valores:
				valores += [dest]
	return floyd(origem,destino,vertices,pesos,valores)
	
	
def floyd(origem,destino,vertices,pesos,valores):
	matriz=[]
	for z in range(len(valores)):
		matriz.append([0]*len(valores))
		
	for q in range(len(valores)):
		for a in range(len(valores)):			
			matriz[q][a]=find_peso([valores[q],valores[a]],vertices,pesos)
	
	for k in range(len(valores)):
		for y in range(len(valores)):
			for w in range(len(valores)):
				matriz[y][w] = max(matriz[y][w],min(matriz[y][k],matriz[k][w]))

        for i in range(len(valores)):
                if valores[i] == origem:
                        mat_origem = i
                if valores[i] == destino:
                        mat_final = i
        if origem == destino:
                print(0)
        else:
                try:
                        print(matriz[mat_origem][mat_final])
                except:
                        print(0)
                        
def find_peso(search,vertices,pesos):
	for i in range(len(vertices)):
		if vertices[i] == search or vertices[i] == [search[1],search[0]]:
			return pesos[i]
	return 0
	
def converte(x):
	for i in range(len(x)):
		x[i]=int(x[i])
	return x
		
jaula()
