import sys

def floyd_warshall(lengths):
    for k in range(len(lengths)):
        for i in range(len(lengths)):
            for j in range(len(lengths)):
                if lengths[i][k] != -1 and lengths[k][j] != -1:
                    lengths[i][j] = max(lengths[i][j], min(lengths[i][k], lengths[k][j]))

def main():
    min_width, max_width, min_length, max_length, min_height = map(int, input().split())
    start, end = map(int, input().split())
    
    MAX_NODES = 100
    lengths = [[-1] * MAX_NODES for _ in range(MAX_NODES)]
    
    while True:
        line = input().strip()
        if line == '-1':
            break
        u, v, width, length, height = map(int, line.split())
        
        if width >= min_width and height >= min_height:
            lengths[u][v] = max(lengths[u][v], length)
            lengths[v][u] = max(lengths[v][u], length)

    floyd_warshall(lengths)
    result = lengths[start][end]
    
    print(result if result != -1 else 0)

if __name__ == "__main__":
    main()
