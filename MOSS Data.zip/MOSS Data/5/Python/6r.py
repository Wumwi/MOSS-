import sys
INF = sys.maxint

def encomenda():
    # Leitura Primeira Linha
    j_larg_min, j_larg_max, j_comp_min, j_comp_max, j_alt = ler_linha()

    # Leitura Segunda Linha
    origem, destino = ler_linha()

    # Leitura Grafo
    global grafo
    grafo={}
    inp = ler_linha()
    while inp[0] != -1:
        extA, extB, e_larg_max, e_comp_max, e_alt = inp
        if (j_comp_min <= e_comp_max and
            j_larg_min <= e_larg_max and
            j_alt <= e_alt):
            if e_comp_max >= j_comp_max:
                e_comp_max = j_comp_max
            try:
                grafo[extA][extB] = e_comp_max
            except:
                grafo[extA] = {}
                grafo[extA][extB] = e_comp_max
            try:
                grafo[extB][extA] = e_comp_max
            except:
                grafo[extB] = {}
                grafo[extB][extA] = e_comp_max
        inp = ler_linha()

    # Calcula Melhor Caminho
    if bfs(origem, destino):
        print(djikstra(origem, destino))
    else:
        print(0)
    
def djikstra(origem, destino):
    Q = grafo.keys()
    global pi
    pi={}
    for v in Q:
        pi[v] = -1
    pi[origem] = INF
    while Q != [] :
        u = extract_max(pi, Q)
        if u==destino: return pi[destino]
        for v in grafo[u].keys():
            relax(u,v)

def extract_max(pi,Q):
    u = -1
    for i in Q:
        if pi[i] > u:
            u = pi[i]
            aux = i
    Q.remove(aux)
    return aux

def relax(u,v):
    if pi[v] == -1 or minimo(pi[u],grafo[u][v]) > pi[v]:
        pi[v] = minimo(pi[u],grafo[u][v])

def bfs(x,y):
    global visited
    visited = {}
    for i in grafo.keys():
        visited[i] = False
    return bfs_visit(x,y)
    
def bfs_visit(x,y):
    visited[x] = True
    for i in grafo[x].keys():
        if visited[i] == False:
            if i == y:
                return True
            else:
                return bfs_visit(i,y)
    return False

def minimo(a,b):
    if a > b : return b
    else: return a
    
def ler_linha():
    inp = input().split()
    for i in range(len(inp)):
        inp[i] = int(inp[i])
    return inp
    
encomenda()
