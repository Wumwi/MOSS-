def encomenda():
    graph={}
    lmin, lmax, cmin, cmax, haltura = input().split()
    lmin = int(lmin)
    lmax = int(lmax)
    cmin = int(cmin)
    cmax = int(cmax)
    haltura = int(haltura)
    origem, destino = input().split()
    origem = int(origem)
    destino = int(destino)
    aux = input()
    while aux != '-1':
        aux = aux.split()
        A, B, comp = int(aux[0]),int(aux[1]), int(aux[3])
        if graph.has_key(A):
            graph[A][B] = comp
        else:
            graph[A] = {B : comp}
        if graph.has_key(B):
            graph[B][A] = comp
        else:
            graph[B] = {A : comp}

        aux = input()

    output=dijkstra(graph, origem, destino)
    return output



def dijkstra(G, start, end):
    S=[]
    Q=[]
    for i in G.keys():
        if i == start:
            Q.append([i,1000])
        else:
            Q.append([i,0])
    
    
    while Q != []:
        out = 0
        aux = Extract_max(Q)
        no = aux[0]
        comp = aux[1]
        if no == end:
            return comp
        S.append(no)
        for x in G[no].keys():
            if x not in S:
                for y in range(len(Q)):
                    if Q[y][0] == x:
                        if comp < G[no][x]:
                            Q[y][1]= comp
                        else:
                            Q[y][1] = G[no][x]
                       
                        break


def Extract_max(lst):
    maximo = 0
    indice = 0
    for i in range(len(lst)):
        if lst[i][1] > maximo:
            maximo = lst[i][1]
            indice = i

    return lst.pop(indice)
            
print(encomenda())
