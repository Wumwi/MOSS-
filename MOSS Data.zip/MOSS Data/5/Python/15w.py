def func_ler(): 
    x = input()
    a = x.split()                  #
    lista=[]                       #   Ler dados 
    for s in a:                    #
        lista=lista+[int(s)]
    return lista

def read():
    x=0
    jaula   = func_ler()
    caminho = func_ler()
    troco   = []
    while x<>1:
        x = input()
        a = x.split()
        lista=[]
        for s in a:
            lista=lista+[int(s)]
        if lista == [-1]:
            x=1
        else:
            troco.append(lista)
    #print jaula
    #print caminho
    #print troco
    return jaula,caminho,troco


def eliminar_listas(troco,pos):    
    aux = []
    tamanho = len(troco)
    for i in range(tamanho):
        if i not in pos:
            aux.append(troco[i])         
    return aux



def bfs(dicio,origem,destino,path=[]):
    path=path+[origem]
    if origem==destino:
        return True
    if not dicio.has_key(origem):
        return False
    for n in dicio[origem]:
        if n not in path:
            newpath=bfs(dicio,n,destino,path)
            if newpath:
                return True
    return False


def lista_to_dicio(troco):
    dicio   = {}
    tamanho = len(troco) 
    for i in range(tamanho):
        if troco[i][0] not in dicio.keys():
            dicio[troco[i][0]]=[troco[i][1]]
        else:
            dicio[troco[i][0]].append(troco[i][1])
    for i in range(tamanho):
        if troco[i][1] not in dicio.keys():
            dicio[troco[i][1]]=[troco[i][0]]
        else:
            dicio[troco[i][1]].append(troco[i][0])
    return dicio
 

def caminhos_possiveis(dicio,origem,destino,path=[],lista=[]):
    path=path+[origem]
    if origem==destino:
        lista.append(path)
    for n in dicio[origem]:
        if n not in path:
            newpath=caminhos_possiveis(dicio,n,destino,path,lista)
    return lista


def encontrar(origem,destino,troco):
    for i in range(len(troco)):
            if ((origem == troco[i][0]) and (destino == troco[i][1])) or ((origem == troco[i][1]) and (destino == troco[i][0])):
                return troco[i][3]

def main():
    jaula,caminho,troco = read()
    #jaula   = [20, 30, 25, 40, 15]
    #caminho = [4, 3]
    #troco   = [[1, 6, 25, 30, 50], [4, 6, 30, 27, 20], [6, 3, 15, 35, 25], [50, 7, 29, 20, 35], [1, 50, 30, 25, 20], [3, 7, 23, 25, 15], [4, 50, 22, 30, 15], [1, 3, 20, 30, 23], [7, 4, 30, 40, 16]]
  
    
    pos     = []
    tamanho = len(troco)                                                     
    for i in range(tamanho):                                                 
        if not (troco[i][2] >= jaula[0]) and (troco[i][2] <= jaula[1]):      
            pos.append(i)  
    troco = eliminar_listas(troco,pos)
    
    
    pos     = []
    tamanho = len(troco)                                                     
    for i in range(tamanho):                                                 
        if not (troco[i][3] >= jaula[2]) and (troco[i][3] <= jaula[3]):       
            pos.append(i)                                                     
    troco = eliminar_listas(troco,pos)  
    
    
    
    pos     = []
    tamanho = len(troco)                                                      
    for i in range(tamanho):                                                  
        if not (troco[i][4] >= jaula[4]):          
            pos.append(i)                                                    
    troco = eliminar_listas(troco,pos)

    
    dicio = lista_to_dicio(troco)

    if caminho[0] == caminho[1]:
        verifica_existencia = False
    else:
        verifica_existencia = bfs(dicio,caminho[0],caminho[1])
    if verifica_existencia == False:
        print(0)
    else:
        comprimento=[]
        comprimento_temp=[]
        caminho_possivel = caminhos_possiveis(dicio,caminho[0],caminho[1])
        for i in range(len(caminho_possivel)):
            for j in range(len(caminho_possivel[i])-1):
                #print caminho_possivel[i][j],caminho_possivel[i][j+1]
                comprimento_temp.append(encontrar(caminho_possivel[i][j],caminho_possivel[i][j+1],troco))
            #print "comprimento_temp",comprimento_temp
            comprimento.append(min(comprimento_temp))
            comprimento_temp=[]
        #print "comprimento",comprimento
    if verifica_existencia == True:
        print(max(comprimento))
    
                
                      
    #print "dicio: ",dicio
    #print "Caminhos poss: ",caminho_possivel
    
main()
            
        
    
    
    
    
    
