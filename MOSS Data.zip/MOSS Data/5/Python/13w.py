#import copy

def contido(inter,valor):
    return (valor >= inter[0]) and (valor <= inter[1])

grafo = {}

def encomenda():
    temp = input()
    temp = temp.split()
    maxsup = int(temp[3])
    L = [int(temp[0]), 2**30]#int(temp[1])]
    C = [int(temp[2]), 2**30]#int(temp[3]]
    A = [int(temp[4]), 2**30]

    temp = input()
    temp = temp.split()
    start = int(temp[0])
    global end
    end = int(temp[1])

    temp = input()
    temp = temp.split()
    for i in range(len(temp)):
        temp[i]=int(temp[i])
    while temp[0] != -1:
        if contido(L,temp[2]) and contido(C,temp[3]) and contido(A,temp[4]):
            temp[3]=min(temp[3],maxsup)
            if temp[0] not in grafo:
		grafo[temp[0]] = [(temp[1],temp[3])]
            else:
		grafo[temp[0]].append((temp[1],temp[3]))
            if temp[1] not in grafo:
                grafo[temp[1]] = [(temp[0],temp[3])]
            else:
		grafo[temp[1]].append((temp[0],temp[3]))
        else:
            if temp[0] not in grafo:
                grafo[temp[0]] = []
            if temp[1] not in grafo:
                grafo[temp[1]] = []

        temp = input()
        temp = temp.split()
        for i in range(len(temp)):
            temp[i]=int(temp[i])
    
    if end not in grafo:
        grafo[end] = []
    if start not in grafo:
        grafo[start] = []

    resolve(start)

dist={}
pai={}
q={}
global existe_caminho
global nao_existe_caminho
nao_existe_caminho = False
existe_caminho = False

def resolve(start):
    for i in grafo:
        dist[i]=0
        pai[i] = None
        q[i] = 0
    dist[start] = 9999
    while not vazio():
        u = extract_min()
        for v in grafo[u]:
            if v[0]==end:
                existe_caminho = True
            nova=min(dist[u],v[1])
            if dist[v[0]] < nova:
                dist[v[0]] = nova
                pai[v[0]] = u

def extract_min():
    mini = -99999
    for i in dist:
        if q[i] == 0 and dist[i] > mini:
            mini = dist[i]
            k=i
    if mini == 0:
        nao_existe_caminho = True
    q[k] = 1
    return k

def vazio():
    for i in q:
        if q[i]==0:
            return False
    return True

encomenda()
print(dist[end])
