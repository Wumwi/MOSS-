import java.util.*;

public class ZooTransport {
    static int[] parent;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int minWidth = scanner.nextInt();
        int maxWidth = scanner.nextInt();
        int minLength = scanner.nextInt();
        int maxLength = scanner.nextInt();
        int minHeight = scanner.nextInt();
        int start = scanner.nextInt();
        int end = scanner.nextInt();

        parent = new int[100];
        for (int i = 0; i < parent.length; i++) {
            parent[i] = i;
        }

        while (true) {
            int u = scanner.nextInt();
            if (u == -1) break;
            int v = scanner.nextInt();
            int width = scanner.nextInt();
            int length = scanner.nextInt();
            int height = scanner.nextInt();

            if (width >= minWidth && height >= minHeight) {
                union(u, v);
            }
        }

        System.out.println(find(start) == find(end) ? minLength : 0);
    }

    static int find(int a) {
        return parent[a] == a ? a : (parent[a] = find(parent[a]));
    }

    static void union(int a, int b) {
        parent[find(a)] = find(b);
    }
}
