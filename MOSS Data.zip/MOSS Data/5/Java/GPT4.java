import java.util.*;

public class ZooTransport {
    static class Edge {
        int dest, width, length, height;

        Edge(int dest, int width, int length, int height) {
            this.dest = dest;
            this.width = width;
            this.length = length;
            this.height = height;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int minWidth = scanner.nextInt();
        int maxWidth = scanner.nextInt();
        int minLength = scanner.nextInt();
        int maxLength = scanner.nextInt();
        int minHeight = scanner.nextInt();
        int start = scanner.nextInt();
        int end = scanner.nextInt();

        Map<Integer, List<Edge>> graph = new HashMap<>();
        while (true) {
            int u = scanner.nextInt();
            if (u == -1) break;
            int v = scanner.nextInt();
            int width = scanner.nextInt();
            int length = scanner.nextInt();
            int height = scanner.nextInt();

            graph.putIfAbsent(u, new ArrayList<>());
            graph.putIfAbsent(v, new ArrayList<>());
            graph.get(u).add(new Edge(v, width, length, height));
            graph.get(v).add(new Edge(u, width, length, height));
        }

        int result = dijkstra(graph, start, end, minWidth, minHeight);
        System.out.println(result == 0 ? 0 : result);
    }

    private static int dijkstra(Map<Integer, List<Edge>> graph, int start, int end, int minWidth, int minHeight) {
        PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingInt(a -> -a[1])); // max-heap
        pq.offer(new int[]{start, Integer.MAX_VALUE});

        int[] maxLengthPath = new int[graph.size() + 1];
        Arrays.fill(maxLengthPath, 0);
        maxLengthPath[start] = Integer.MAX_VALUE;

        while (!pq.isEmpty()) {
            int[] current = pq.poll();
            int node = current[0];
            int length = current[1];

            if (node == end) return length;

            for (Edge edge : graph.get(node)) {
                if (edge.width >= minWidth && edge.height >= minHeight) {
                    int possibleLength = Math.min(length, edge.length);
                    if (possibleLength > maxLengthPath[edge.dest]) {
                        maxLengthPath[edge.dest] = possibleLength;
                        pq.offer(new int[]{edge.dest, possibleLength});
                    }
                }
            }
        }

        return 0;
    }
}
