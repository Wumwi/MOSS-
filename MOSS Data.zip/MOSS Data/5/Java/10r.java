import java.lang.*;
import java.util.*;


class Heap {
    class HeapNode implements Comparable {
	int prio;
	int node;
	
	HeapNode(int n, int p) {
	    prio = p;
	    node = n;
	}
	
	public int compareTo(Object o) {
	    HeapNode other = (HeapNode) o;
	    if (this.prio > other.prio)
		return -1;
	    else if (this.prio < other.prio)
		return 1;
	    else
		return 0;
	}
    }
    
    static int maxSize;
    int size;
    HeapNode a[];
    int ord[];
    
    Heap (int n) {
	maxSize = n;
	size = 0;
	a = new HeapNode[maxSize + 1];
	ord = new int[maxSize + 1];
    }

    private int left(int i) {
	if (2*i > size) 
	    return i;
	return 2*i;
    }
    
    private int right(int i) {
	if (2 * i + 1 > size) 
	    return i;
	return (2*i)+1;
    }
    
    private int parent(int i) {
	return i/2;
    }

    boolean isFull() {
	return size == maxSize;
    }

    boolean isEmpty() {
	return size==0;
    }
    
    HeapNode remove() {
	HeapNode tmp = null;
	
	if (!isEmpty()) {
	    ord[a[1].node] = -1;
	    tmp = a[1];
	    ord[a[size].node] = 1;
	    a[1] = a[size];
	    size--;
	}
	heapify(1);
	return tmp;
    }
    
    void swap(int i, int j) {
	HeapNode aux;
	ord[a[i].node] = j;
	ord[a[j].node] = i;
	aux = a[i];
	a[i] = a[j];
	a[j] = aux;
    }
    

    void decreaseKey(int no, int newkey) {
	HeapNode aux;
	int i = ord[no];
	a[i].prio = newkey;
	
	while(i > 1 && a[i].compareTo(a[parent(i)]) < 0) {
	    swap(i, parent(i));
	    i = parent(i);
	}
    }
    
    void heapify(int i) {
	int biggest = i;
	if (a[left(i)].compareTo(a[biggest]) < 0)
	    biggest = left(i);
	if (a[right(i)].compareTo(a[biggest]) < 0)
	    biggest = right(i);
	
	if (i != biggest) {
	    swap(i,biggest);
	    heapify(biggest);
	}
    }
    
    void add(int no, int prio) {
	if (!isFull()) {
	    size++;
	    ord[no] = size;
	    a[size] = new HeapNode(no,prio);
	    decreaseKey(no, prio);
	}
    }
	
}
    



class Graph {
    class Edge {
	int dest,largura, comprimento, altura;
	
	Edge (int d, int l, int c, int a) {
	    dest = d;
	    largura = l;
	    comprimento = c;
	    altura = a;
	}
    }

    class Node {
	LinkedList<Edge> edges;
	
	Node() {
	    edges = new LinkedList<Edge>();
	}
    }
    
    int comprimentoMax, comprimentoMin, larguraMax, larguraMin, alturaMin,origem, destino;
    Vector<Node> graph;
    Vector<Integer> bijecao;
    int nNodes;
    
    Graph(int cMax, int cMin, int lMax, int lMin, int aMin,int inicio, int fim) {
	graph = new Vector<Node>();
	bijecao = new Vector<Integer>();
	nNodes = 0;
	comprimentoMax = cMax;
	comprimentoMin = cMin;
	larguraMax = lMax;
	larguraMin = lMin;
	alturaMin = aMin;
	origem = inicio;
	destino = fim;
    }
    
    void addEdge(int origin, int dest, int c, int l, int a) {
	Edge e;
	Node o = new Node();
	int indOri, indDest;
	
	indOri = bijecao.indexOf(origin);
	if (indOri == -1) {
	    graph.add(o);
	    bijecao.add(origin);
	    nNodes++;
	    indOri = nNodes - 1;
	}
	indDest = bijecao.indexOf(dest);
	if (indDest == -1) {
	    graph.add(o);
	    bijecao.add(dest);
	    nNodes++;
	    indDest = nNodes - 1;
	}
	// if (c>comprimentoMin && l>larguraMin && a>alturaMin) {
	e = new Edge(indDest, Math.min(c,comprimentoMax),Math.min(l,larguraMax),a);
	graph.elementAt(indOri).edges.addFirst(e);
	// }
    }
    
    void lerGrafo(Scanner in) {
	int inicio, dest, largura, comprimento, altura;
	inicio = in.nextInt();
	while (inicio != -1) {
	    dest = in.nextInt();
	    largura = in.nextInt();
	    comprimento = in.nextInt();
	    altura = in.nextInt();
	    addEdge(inicio,dest,largura,comprimento,altura);
	    addEdge(dest,inicio,largura,comprimento,altura);
	    inicio = in.nextInt();
	}
	origem = bijecao.indexOf(origem);
	destino = bijecao.indexOf(destino);
    }
    
    void imprimirGrafo() {
	for (int i = 0; i<nNodes; i++) {
	    System.out.printf("no %d\n",i);
	    for (Edge e: graph.elementAt(i).edges)
		System.out.printf("%d ",e.dest);
	    System.out.printf("\n");
	}
    }
    
    
    void calcularComprimentoMaximo() {
	int visitados[] = new int[nNodes];
	Heap h = new Heap(nNodes);
	int aux = origem;
	
	for (int i=0; i<nNodes; i++)
	    visitados[i] = -1;
	
	visitados[aux] = comprimentoMax;
	
	while (aux != destino) {
	    for (Edge e: graph.elementAt(aux).edges) {
		if (visitados[e.dest] == -1) {
		    visitados[e.dest] = Math.min(e.comprimento, visitados[aux]);
		    h.add(e.dest, visitados[e.dest]);
		}
		else if (visitados[e.dest] < Math.min(visitados[aux], e.comprimento)) {
		    visitados[e.dest] = Math.min(visitados[aux], e.comprimento);
		    h.decreaseKey(e.dest,visitados[e.dest]);
		}
	    }
	    aux = (h.remove()).node;
	}
	System.out.printf("%d",visitados[destino]);
    }
	    
}

class Encomenda {
    static Scanner in = new Scanner(System.in);
    
    public static void main(String args[]) {
	int origem, dest;
	int cMin, cMax, lMin, lMax, aMin;
	
	lMin = in.nextInt();
	lMax = in.nextInt();
	cMin = in.nextInt();
	cMax = in.nextInt();
	aMin = in.nextInt();

	origem = in.nextInt();
	dest= in.nextInt();
	
	Graph g = new Graph(cMax, cMin, lMax, lMin, aMin, origem, dest);
	
	g.lerGrafo(in);
		
	g.calcularComprimentoMaximo();
    }
}