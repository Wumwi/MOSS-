import java.util.*;

public class ZooTransport {
    static final int MAX_NODES = 100;
    static final int INF = Integer.MAX_VALUE;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int minW = scanner.nextInt();
        int maxW = scanner.nextInt();
        int minL = scanner.nextInt();
        int maxL = scanner.nextInt();
        int minH = scanner.nextInt();
        int start = scanner.nextInt();
        int end = scanner.nextInt();

        int[][] width = new int[MAX_NODES][MAX_NODES];
        int[][] length = new int[MAX_NODES][MAX_NODES];
        for (int i = 0; i < MAX_NODES; i++) {
            Arrays.fill(width[i], INF);
            Arrays.fill(length[i], 0);
        }

        int u, v, w, l, h;
        while (true) {
            u = scanner.nextInt();
            if (u == -1) break;
            v = scanner.nextInt();
            w = scanner.nextInt();
            l = scanner.nextInt();
            h = scanner.nextInt();

            if (w >= minW && h >= minH) {
                width[u][v] = Math.min(width[u][v], w);
                width[v][u] = Math.min(width[v][u], w);
                length[u][v] = Math.max(length[u][v], l);
                length[v][u] = Math.max(length[v][u], l);
            }
        }

        for (int k = 0; k < MAX_NODES; k++)
            for (int i = 0; i < MAX_NODES; i++)
                for (int j = 0; j < MAX_NODES; j++)
                    if (width[i][k] != INF && width[k][j] != INF) {
                        width[i][j] = Math.min(width[i][j], width[i][k]);
                        length[i][j] = Math.max(length[i][j], Math.min(length[i][k], length[k][j]));
                    }

        int result = length[start][end];
        System.out.println((result < minL || result > maxL) ? 0 : result);
    }
}
