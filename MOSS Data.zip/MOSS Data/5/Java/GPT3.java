import java.util.*;

public class ZooTransport {
    static class Edge {
        int destination, width, length, height;

        Edge(int destination, int width, int length, int height) {
            this.destination = destination;
            this.width = width;
            this.length = length;
            this.height = height;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int minW = scanner.nextInt();
        int maxW = scanner.nextInt();
        int minL = scanner.nextInt();
        int maxL = scanner.nextInt();
        int minH = scanner.nextInt();
        int start = scanner.nextInt();
        int end = scanner.nextInt();

        Map<Integer, List<Edge>> graph = new HashMap<>();
        while (true) {
            int u = scanner.nextInt();
            if (u == -1) break;
            int v = scanner.nextInt();
            int w = scanner.nextInt();
            int l = scanner.nextInt();
            int h = scanner.nextInt();

            graph.putIfAbsent(u, new ArrayList<>());
            graph.putIfAbsent(v, new ArrayList<>());
            graph.get(u).add(new Edge(v, w, l, h));
            graph.get(v).add(new Edge(u, w, l, h));
        }

        int result = bfs(graph, start, end, minW, minH);
        System.out.println((result < minL || result > maxL) ? 0 : result);
    }

    private static int bfs(Map<Integer, List<Edge>> graph, int start, int end, int minW, int minH) {
        Queue<int[]> queue = new LinkedList<>();
        queue.offer(new int[]{start, Integer.MAX_VALUE});
        Set<Integer> visited = new HashSet<>();
        visited.add(start);

        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            int node = current[0], length = current[1];

            if (node == end) return length;

            for (Edge edge : graph.getOrDefault(node, new ArrayList<>())) {
                if (!visited.contains(edge.destination) && edge.width >= minW && edge.height >= minH) {
                    int possibleLength = Math.min(length, edge.length);
                    queue.offer(new int[]{edge.destination, possibleLength});
                    visited.add(edge.destination);
                }
            }
        }
        return 0;
    }
}
