#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct l_edge
{
  int fr, to, l, c, a;
} typedef l_edge;

struct edge
{
  int to, l, c, a;
} typedef edge;

int lmin, lmax, cmin, cmax, amin;
int ini, end, ct = 0;
l_edge *input;
edge **nei;
int *n_nei;
int *v_list;
int *vis;

int cmp(const void *a, const void *b)
{
  return (*(int*)a - *(int*)b);
}

int bseh(int vl)
{
  int lo = 0, hi = ct - 1;
  while (lo <= ct)
    {
      int med = (lo + hi) / 2;
      if (v_list[med] == vl)
	return med;
      else if (v_list[med] < vl)
	lo = med + 1;
      else
	hi = med - 1;
    }
  return -1;
}

void dfs(int cur, int cap)
{
  vis[cur] = 1;
  int i;
  for (i = 0; i < n_nei[cur]; i++)
    if (!vis[nei[cur][i].to] && nei[cur][i].c >= cap && nei[cur][i].l >= lmin && nei[cur][i].a >= amin)
      dfs(nei[cur][i].to, cap);
}

int ok(int cap)
{
  int i;
  for (i = 0; i < ct; i++)
    vis[i] = 0;
  dfs(ini, cap);
  if (vis[end])
    return 1;
  return 0;
}

int main()
{
  int i;
  scanf("%d %d %d %d %d", &lmin, &lmax, &cmin, &cmax, &amin);
  scanf("%d %d", &ini, &end);
  input = (l_edge *) malloc(sizeof(l_edge));
  l_edge st;
  
  while (scanf("%d", &st.fr) != EOF && st.fr != -1)
    {
      scanf("%d %d %d %d", &st.to, &st.l, &st.c, &st.a);
      input = (l_edge *) realloc(input, (1 + ct) * sizeof(l_edge));      
      input[ct++] = st;
    }

  v_list = (int *) malloc((2 * ct + 5) * sizeof(int));
  for (i = 0; i < ct; i++)
    {
      v_list[i] = input[i].fr;
      v_list[i + ct] = input[i].to;
    }

  qsort (v_list, 2 * ct, sizeof(int), cmp);

  int pos = 0;
  for (i = 1; i < 2 * ct; i++)
    if (v_list[i] != v_list[pos])
      {
	v_list[pos + 1] = v_list[i];
	pos++;
      }

  int l_inp = ct;
  ct = pos + 1;
  ini = bseh(ini);
  end = bseh(end);
  nei = (edge **) malloc((ct + 5) * sizeof(edge *));
  n_nei = (int *) malloc((ct + 5) * sizeof(int));
  vis = (int *) malloc((ct + 5) * sizeof(int));

  for (i = 0; i < ct; i++)
    {
      nei[i] = (edge *) malloc(sizeof(edge));
      n_nei[i] = 0;
    }

  for (i = 0; i < l_inp; i++)
    {
      int fr = bseh(input[i].fr);
      int to = bseh(input[i].to);
      edge e;
      e.l = input[i].l, e.c = input[i].c, e.a = input[i].a;
      n_nei[fr]++;
      nei[fr] = (edge *) realloc(nei[fr], n_nei[fr] * sizeof(edge));
      e.to = to;
      nei[fr][n_nei[fr] - 1] = e;
      n_nei[to]++;
      nei[to] = (edge *) realloc(nei[to], n_nei[to] * sizeof(edge));
      e.to = fr;
      nei[to][n_nei[to] - 1] = e;
    }

  int lo = cmin - 1, hi = cmax;
  if (ini == -1 || hi == -1)
    hi = lo;
  while (lo < hi)
    {
      int med = (lo + hi) / 2;
      if (med == lo)
	med++;
      if (ok(med))
	lo = med;
      else
	hi = med - 1;
    }

  if (lo >= cmin)
    printf("%d\n", lo);
  else
    printf("0\n");

  return 0;
}
