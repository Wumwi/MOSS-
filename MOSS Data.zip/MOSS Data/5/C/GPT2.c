#include <stdio.h>
#include <limits.h>

#define MAX_NODES 100
#define INF INT_MAX

int min(int a, int b) {
    return a < b ? a : b;
}

int adj[MAX_NODES][MAX_NODES];
int max_length[MAX_NODES][MAX_NODES];

void floyd_warshall(int n) {
    for (int k = 0; k < n; k++)
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                if (adj[i][k] && adj[k][j])
                    max_length[i][j] = max(max_length[i][j], min(max_length[i][k], max_length[k][j]));
}

int main() {
    int minW, maxW, minL, maxL, minH;
    int start, end;
    scanf("%d %d %d %d %d", &minW, &maxW, &minL, &maxL, &minH);
    scanf("%d %d", &start, &end);

    int u, v, w, l, h, node_count = 0;
    while (1) {
        scanf("%d", &u);
        if (u == -1) break;
        scanf("%d %d %d %d", &v, &w, &l, &h);

        if (w >= minW && h >= minH) {
            adj[u][v] = adj[v][u] = 1;
            max_length[u][v] = max_length[v][u] = min(maxL, l);
        }
        node_count = max(node_count, max(u, v));
    }

    floyd_warshall(node_count + 1);
    int result = max_length[start][end];

    printf("%d\n", (result == 0) ? 0 : result);

    return 0;
}
