#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX_NODES 100
#define INF INT_MAX

typedef struct {
    int width, length, height;
} Dimensions;

typedef struct {
    int u, v;
    Dimensions dim;
} Edge;

int min(int a, int b) {
    return a < b ? a : b;
}

int max(int a, int b) {
    return a > b ? a : b;
}

int max_length_path(int start, int end, int n, Edge edges[], int edge_count, Dimensions cage) {
    int dist[MAX_NODES];
    for (int i = 0; i < MAX_NODES; i++) {
        dist[i] = 0;
    }
    dist[start] = INT_MAX;

    for (int i = 0; i < edge_count; i++) {
        int u = edges[i].u;
        int v = edges[i].v;

        if (edges[i].dim.width >= cage.width && edges[i].dim.height >= cage.height) {
            dist[v] = max(dist[v], min(dist[u], edges[i].dim.length));
            dist[u] = max(dist[u], min(dist[v], edges[i].dim.length));
        }
    }

    return dist[end];
}

int main() {
    int minW, maxW, minL, maxL, minH;
    int start, end;
    scanf("%d %d %d %d %d", &minW, &maxW, &minL, &maxL, &minH);
    scanf("%d %d", &start, &end);

    Edge edges[MAX_NODES];
    int edge_count = 0;

    while (1) {
        int u, v, w, l, h;
        scanf("%d", &u);
        if (u == -1) break;
        scanf("%d %d %d %d", &v, &w, &l, &h);
        edges[edge_count++] = (Edge){u, v, {w, l, h}};
    }

    Dimensions cage = {minW, minL, minH};
    int result = max_length_path(start, end, MAX_NODES, edges, edge_count, cage);

    if (result < minL || result > maxL) {
        printf("0\n");
    } else {
        printf("%d\n", result);
    }

    return 0;
}
