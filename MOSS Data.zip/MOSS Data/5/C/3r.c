/*
 ============================================================================
 Name        : negocios_electronicos.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description :
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#ifndef GRAPHS_H
#define GRAPHS_H





typedef int LABEL_NO;   // tipo escolhido para label dum n� dum grafo
/* typedef char * LABEL_NO;  */


typedef int LABEL_ARC;  // tipo de valores que est�o associados aos arcos
/* typedef char LABEL_ARC;  */


typedef struct arco {
  int no_final;
  LABEL_ARC valor;
  struct arco *prox;
} ARCO;


typedef struct vertex {
  LABEL_NO label;
  ARCO *adjs;
  int distancia;
  int cor;
  int pai;
} VERTEX;


typedef struct repgraph {
  VERTEX *grafo;
  int nvs, narcos;
} GRAFO;




#define VERTEX_I(i,g) ( (g).grafo[i] )
// o vertex i do grafo

#define LABEL_VERTEX(i,g) ( (g).grafo[i].label )
// proximo adjacente


#define NUMB_VERTICES(g) ( (g).nvs )
// numero de vertices

#define NUMB_ARCOS(g) ( (g).narcos )
// numero de arcos


#define ADJS_NO(i,g) ( (g).grafo[i].adjs )
// #define ADJS_NO(i,g) (((g).grafo[i]).adjs)
// apontador para o primeiro adjacente

#define PROX_ADJ(arco) ((arco) -> prox)
// proximo adjacente

#define ADJ_VALIDO(arco) (((arco) != NULL))
// se arco � v�lido

#define EXTREMO_FINAL(arco) ((arco) -> no_final)
// qual o extremo final de arco

#define VALOR_ARCO(arco) ((arco) -> valor)
// qual o valor do arco




#endif

static ARCO* cria_arco(int, LABEL_ARC valor_ij);
static void free_arcs(ARCO *);

// para criar um grafo com nverts vertices e sem ramos
extern GRAFO new_graph(int nverts)
{
  GRAFO g;
  g.grafo = (VERTEX *) malloc(sizeof(VERTEX)*nverts);
  if (g.grafo == NULL) {
    fprintf(stderr,"ERROR: cannot allocate graph\n");
    exit(1);
  }
  g.nvs = nverts;
  g.narcos = 0;
  while (nverts) {
    nverts--;
    ADJS_NO(nverts,g) = NULL;
  }
  return g;
}

// para destruir um grafo criado
extern void destroy_graph(GRAFO g)
{ int i;
  if (g.grafo != NULL) {
    for (i=0; i<g.nvs; i++)
      free_arcs(ADJS_NO(i,g));
    free(g.grafo);
  }
}


// para inserir um novo arco num grafo
extern GRAFO insert_new_arc(int i, int j, LABEL_ARC valor_ij, GRAFO g)
{ /* insere arco (i,j) no grafo g, bem como o seu label  */

  ARCO *arco = cria_arco(j,valor_ij);
  PROX_ADJ(arco) = ADJS_NO(i,g);
  ADJS_NO(i,g) = arco;  // novo adjacente fica � cabe�a da lista
  g.narcos++;
  return g;
}

// para remover um arco de um grafo
extern GRAFO remove_arc(ARCO *arco, int i, GRAFO g)
{ /* retira o arco dado de g */

  ARCO *aux = ADJS_NO(i,g), *prev = NULL;
  while (aux != arco && ADJ_VALIDO(aux)) {
    prev = aux;
    aux = PROX_ADJ(aux);
  }
  if (aux == arco) {
    if (prev == NULL) {
      VERTEX_I(i,g).adjs = PROX_ADJ(arco);
    } else PROX_ADJ(prev) = PROX_ADJ(arco);
    free(arco);
    g.narcos--;
  }
  return g;
}



// ----  as duas funcoes abaixo sao auxiliares nao publicas ----

// reservar memoria para um novo arco e inicializa-lo
static ARCO *cria_arco(int j, LABEL_ARC v)
{ // cria um novo adjacente
  ARCO *arco = (ARCO *) malloc(sizeof(ARCO));
  if (arco == NULL) {
    fprintf(stderr,"ERROR: cannot create arc\n");
    exit (1);
  }
  EXTREMO_FINAL(arco) = j;
  VALOR_ARCO(arco) = v;
  PROX_ADJ(arco) = NULL;
  return arco;
}

// libertar uma lista de arcos
static void free_arcs(ARCO *arco)
{ // liberta lista de adjacentes
  if (arco == NULL) return;
  free_arcs(PROX_ADJ(arco));
  free(arco);
}

#ifndef HEAPMIN_H
#define HEAPMIN_H

#include<stdio.h>

typedef struct qnode {
  int vert, vertkey;
} QNODE;

typedef struct heapMin {
  int sizeMax, size;
  QNODE *a;
  int *pos_a;
} HEAPMIN;




#endif



#define LEFT(i) (2*(i))
#define RIGHT(i) (2*(i)+1)
#define PARENT(i) ((i)/2)

static void heapify(int i,HEAPMIN *q);
static void swap(int i,int j,HEAPMIN *q);
static int compare(int i, int j, HEAPMIN *q);


static int compare(int i, int j, HEAPMIN *q){
  if (q -> a[i].vertkey < q -> a[j].vertkey)
    return -1;
  if (q -> a[i].vertkey == q -> a[j].vertkey)
    return 0;
  return 1;
}


int extractMin(HEAPMIN *q) {
  int v = q -> a[1].vert;
  swap(1,q->size,q);
  q -> size--;
  heapify(1,q);
  return v;
}

void decreaseKey(int v, int newkey, HEAPMIN *q){
  int i = q -> pos_a[v];
  q -> a[i].vertkey = newkey;

  while(i > 1 && compare(i,PARENT(i),q) < 0){
    swap(i,PARENT(i),q);
    i = PARENT(i);
  }
}


static void heapify(int i,HEAPMIN *q) {
  // para heap de minimo
  int l, r, smallest;
  l = LEFT(i);
  if (l > q -> size) l = i;
  r = RIGHT(i);
  if (r > q -> size) r = i;

  smallest = i;
  if (compare(l,smallest,q) < 0)
    smallest = l;
  if (compare(r,smallest,q) < 0)
    smallest = r;

  if (i != smallest) {
    swap(i,smallest,q);
    heapify(smallest,q);
  }
}

static void swap(int i,int j,HEAPMIN *q){
  QNODE aux;
  q -> pos_a[q -> a[i].vert] = j;
  q -> pos_a[q -> a[j].vert] = i;
  aux = q -> a[i];
  q -> a[i] = q -> a[j];
  q -> a[j] = aux;
}



HEAPMIN *build_heap_min(int vec[], int n){
  HEAPMIN *q = (HEAPMIN *)malloc(sizeof(HEAPMIN));
  int i;
  q -> sizeMax = n;
  q -> size = n;   // posicao 0 nao vai ser ocupada
  q -> a = (QNODE *) malloc(sizeof(QNODE)*(n+1));
  q -> pos_a = (int *) malloc(sizeof(int)*n);
  for (i=0; i< n; i++) {
    q -> a[i+1].vert = i;
    q -> a[i+1].vertkey = vec[i];
    q -> pos_a[i] = i+1;  // posicao de vertice i na heap
  }

  for (i=n/2; i>=1; i--)
    heapify(i,q);
  return q;
}


void insert(int v, int key, HEAPMIN *q)
{
  if (q -> sizeMax == q -> size) {
    fprintf(stderr,"Heap is full\n");
    exit(1);
  }
  q -> size++;
  q -> a[q->size].vert = v;
  q -> pos_a[v] = q -> size;   // supondo 0 <= v < n
  //  q -> a[q->size].vertkey = key;
  decreaseKey(v,key,q);   // obriga corrigir posicao
}


// --------- auxiliar para ver conteudo  ---------------------
void write_heap(HEAPMIN *q){
  int i;

  printf("Max size: %d\n", q -> sizeMax);
  printf("Current size: %d\n", q -> size);

  printf("(Vert,Key)\n---------\n");
  for(i=1; i <= q -> size; i++)
    printf("(%d,%d)\n",q->a[i].vert,q->a[i].vertkey);

  printf("-------\n(Vert,PosVert)\n---------\n");

  for(i=0; i < q -> sizeMax; i++)
    if (q -> pos_a[i] <= q -> size)
      printf("(%d,%d)\n",i,q->pos_a[i]);
}


void destroy_heap(HEAPMIN *q){
  if (q != NULL) {
    free(q -> a);
    free(q -> pos_a);
    free(q);
  }
}





GRAFO grafo;

HEAPMIN *hpMin;
void ler_construir_grafo();

void dijkstra(int no_inicial);

int main(void) {
	int nvertices, arcodestino;

	scanf("%d", &nvertices);
	scanf("%d", &arcodestino);

	ler_construir_grafo(nvertices);

	dijkstra(arcodestino);

	return EXIT_SUCCESS;
}

void ler_construir_grafo(int nvertices) {

	int regiao1, regiao2, peso;

	grafo = new_graph(nvertices + 1);

	scanf("%d", &regiao1);

	while (regiao1 != -1) {
		scanf("%d", &regiao2);
		scanf("%d", &peso);
		insert_new_arc(regiao1, regiao2, peso, grafo);
		insert_new_arc(regiao2, regiao1, peso, grafo);
		scanf("%d", &regiao1);
	}

}

void dijkstra(int no_inicial) {

	int vertice;
	int distancia[grafo.nvs];

	for (vertice = 1; vertice < grafo.nvs; vertice++) {
		distancia[vertice] = INT_MAX;
		grafo.grafo[vertice].cor = 0;
		grafo.grafo[vertice].pai = 0;
	}

	distancia[no_inicial] = 0;

	hpMin = build_heap_min(distancia, grafo.nvs);

	while (hpMin->size != 0) {
		vertice = extractMin(hpMin);
		if (vertice != 0) {
			printf("%d ", vertice);
		}

		ARCO *adj = ADJS_NO(vertice, grafo);
		while (adj != NULL ) {
			if ((distancia[vertice] + adj->valor)
					< distancia[EXTREMO_FINAL(adj)]) {
				distancia[EXTREMO_FINAL(adj)] =
						(distancia[vertice] + adj->valor);

				decreaseKey(EXTREMO_FINAL(adj), distancia[EXTREMO_FINAL(adj)],
						hpMin);

				grafo.grafo[EXTREMO_FINAL(adj)].pai = vertice;

			}

			adj = PROX_ADJ(adj);
		}
		grafo.grafo[vertice].cor = 2;

	}

}

