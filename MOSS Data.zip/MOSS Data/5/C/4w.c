#include <stdio.h>
#include <stdlib.h>

//#include "Graph.h"

//Graph.h
struct EDGE;
struct VERTEX;
struct GRAPH;

typedef struct EDGE Edge;
typedef struct VERTEX Vertex;
typedef struct GRAPH Graph;

void    vertex_addEdge(Vertex* v1, Vertex* v2, int weight); //Adds an edge from v1 to v2

Graph*  graph_create();
Vertex* graph_addVertex(Graph* graph, int vertexID);
Vertex* graph_getVertex(Graph* graph, int vertexID);

void    graph_print(Graph* graph);

struct EDGE
{
	int weigth;
	Vertex* end;

	Edge* nextEdge;
};

struct VERTEX
{
	int id;
	Edge* edgesList;

	Vertex* nextVertex;
};

struct GRAPH
{
	int numVertices;
	Vertex* verticesList;
};

//Graph.c

void vertex_addEdge(Vertex* v1, Vertex* v2, int weight)
{
	Edge* e       = (Edge*) malloc(sizeof(Edge));
	e->end        = v2;
	e->weigth     = weight;
	e->nextEdge   = v1->edgesList;
	v1->edgesList = e;
}

Graph* graph_create()
{
	Graph* g        = (Graph*) malloc(sizeof(Graph));

	g->numVertices  = 0;
	g->verticesList = NULL;

	return g;
}

Vertex* graph_addVertex(Graph* graph, int vertexID)
{
	Vertex* v = graph_getVertex(graph, vertexID);

	if(v == NULL)
	{
		v                   = (Vertex*) malloc(sizeof(Vertex));
		v->id               = vertexID;
		v->edgesList        = NULL;
		v->nextVertex       = graph->verticesList;
		graph->verticesList = v;

		graph->numVertices++;
	}

	return v;
}

Vertex* graph_getVertex(Graph* graph, int vertexID)
{
	Vertex* v = graph->verticesList;

	while(v != NULL)
	{
		if(v->id == vertexID)
			return v;

		v = v->nextVertex;
	}

	return NULL;
}

void graph_print(Graph* graph)
{
	Vertex* v;
	Edge* e;

	v = graph->verticesList;

	while(v != NULL)
	{
		printf("v: %d", v->id);
		e = v->edgesList;

		while(e != NULL)
		{
			printf(" -> %d(%d)", e->end->id, e->weigth);
			e = e->nextEdge;
		}

		printf("\n");

		v = v->nextVertex;
	}
}

//PRIORITY QUEUE STRUCTS AND FUNCTIONS
struct NODE;
struct PQUEUE;

typedef struct NODE Node;
typedef struct PQUEUE PQueue;

struct NODE
{
	Vertex* vertex;
	int key;
};

struct PQUEUE
{
	int size;
	int sizeMax;
	Node* nodes;
};

void upHeap(Node* heap, int index)
{
	int current = index;
	int parent = (index-1)/2;

	Node node = heap[index];

	while(current > 0)
	{
		if(heap[parent].key < node.key)
		{
			heap[current] = heap[parent];

			current = parent;
			parent = (current-1)/2;
		} else
			break;
	}

	heap[current] = node;
}

void downHeap(Node* heap, int last, int index)
{
	int current = index;
	int child = (index*2)+1;

	Node value = heap[index];

	while(child <= last)
	{
		if(child < last)
			if(heap[child].key < heap[child+1].key)
				child++;

		if(heap[child].key > value.key)
		{
			heap[current] = heap[child];
			current = child;
			child = (current*2)+1;
		} else
			break;
	}

	heap[current] = value;
}

PQueue* createPQueue(int sizeMax)
{
	PQueue* queue = (PQueue*) malloc(sizeof(PQueue));

	queue->size = 0;
	queue->sizeMax = sizeMax;
	queue->nodes = (Node*) malloc(sizeof(Node)*sizeMax);

	return queue;
}

void destroyPQueue(PQueue* queue)
{
	free(queue->nodes);
	free(queue);
}

void pushToPQueue(PQueue* queue, Vertex* vertex, int key)
{
	if(queue->size == queue->sizeMax)
		return;

	queue->nodes[queue->size].vertex = vertex;
	queue->nodes[queue->size].key = key;

	upHeap(queue->nodes, queue->size);

	queue->size++;
}

Node popFromPQueue(PQueue* queue)
{
	Node node;
	
	if(queue->size > 0)
	{
		node = queue->nodes[0];

		if(queue->size > 1)
		{
			queue->nodes[0] = queue->nodes[queue->size-1];

			downHeap(queue->nodes, queue->size-2, 0);
		}

		queue->size--;
	}

	return node;
}

int getNodeIndexFromPQueue(PQueue* pPQueue, int id)
{
	int i;

	for(i = 0; i < pPQueue->size; i++)
		if(pPQueue->nodes[i].vertex->id == id)
			return i;

	return -1;
}

//MAIN PROGRAM FUNCTIONS

int adaptedDijkstra(PQueue* queue, int target)
{
	Node n;
	Edge* e;

	int index;

	int weight;

	n = popFromPQueue(queue);

	while(queue->size > 0 && n.vertex->id != target)
	{
		e = n.vertex->edgesList;

		while(e != NULL)
		{
			weight = n.key;

			index = getNodeIndexFromPQueue(queue, e->end->id);

			if(index != -1) //if end of edge not finished
			{
				if(weight > e->weigth || weight == 0)
					weight = e->weigth;

				if(weight > queue->nodes[index].key)
				{
					queue->nodes[index].key = weight;
					upHeap(queue->nodes, index);
				}
			}

			e = e->nextEdge;
		}


		n = popFromPQueue(queue);
	}

	if(n.vertex->id == target)
		return n.key;

	return 0;
};

int main()
{
	Graph* graph = graph_create();

	int minL;
	int maxL;
	int minC;
	int maxC;
	int minA;

	int source;
	int target;

	int x;
	int y;
	int l, c, a;

	PQueue* queue;

	Vertex* v1;
	Vertex* v2;

	scanf("%d %d %d %d %d", &minL, &maxL, &minC, &maxC, &minA);
	scanf("%d %d", &source, &target);

	scanf("%d", &x);

	graph_addVertex(graph, source);
	graph_addVertex(graph, target);

	while(x != -1)
	{
		scanf("%d %d %d %d", &y, &l, &c, &a);

		if(l >= minL && c >= minC && a >= minA)
		{
			v1 = graph_addVertex(graph, x);
			v2 = graph_addVertex(graph, y);
			
			vertex_addEdge(v1, v2, c>maxC?maxC:c);
			vertex_addEdge(v2, v1, c>maxC?maxC:c);
		}

		scanf("%d", &x);
	}

	//graph_print(graph);

	if(graph->numVertices == 0)
	{
		printf("%d\n", 0);

		return 0;
	}

	queue = createPQueue(graph->numVertices);

	pushToPQueue(queue, graph_getVertex(graph, source), 0);

	v1 = graph->verticesList;

	while(v1 != NULL)
	{
		if(v1->id != source) //Already added source
			pushToPQueue(queue, v1, 0);

		v1 = v1->nextVertex;
	}

	//Algorithm
	printf("%d\n", adaptedDijkstra(queue, target));

	destroyPQueue(queue);

	//TO DO: FIX MEMORY LEAKS
	return 0;
}