#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <queue>

#define MAX_NODES 100

typedef struct {
    int width, length, height;
} Dimensions;

typedef struct {
    int node, max_length;
} Node;

int adj[MAX_NODES][MAX_NODES];
Dimensions dim[MAX_NODES][MAX_NODES];
int visited[MAX_NODES];

int bfs(int start, int end, int minW, int minH) {
    std::queue<Node> q;
    q.push({start, INT_MAX});
    visited[start] = 1;

    while (!q.empty()) {
        Node cur = q.front();
        q.pop();

        if (cur.node == end) return cur.max_length;

        for (int i = 0; i < MAX_NODES; i++) {
            if (adj[cur.node][i] && !visited[i] && dim[cur.node][i].width >= minW && dim[cur.node][i].height >= minH) {
                int possible_length = min(cur.max_length, dim[cur.node][i].length);
                q.push({i, possible_length});
                visited[i] = 1;
            }
        }
    }

    return 0;
}

int main() {
    int minW, maxW, minL, maxL, minH;
    int start, end;
    scanf("%d %d %d %d %d", &minW, &maxW, &minL, &maxL, &minH);
    scanf("%d %d", &start, &end);

    int u, v, w, l, h;
    while (1) {
        scanf("%d", &u);
        if (u == -1) break;
        scanf("%d %d %d %d", &v, &w, &l, &h);
        adj[u][v] = adj[v][u] = 1;
        dim[u][v] = dim[v][u] = {w, l, h};
    }

    int result = bfs(start, end, minW, minH);
    printf("%d\n", result);

    return 0;
}
