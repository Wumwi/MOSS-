#include <stdio.h>

#define MAX_NODES 100

int parent[MAX_NODES];
int find(int a) {
    return parent[a] == a ? a : (parent[a] = find(parent[a]));
}

void union_sets(int a, int b) {
    parent[find(a)] = find(b);
}

int main() {
    int minW, maxW, minL, maxL, minH;
    int start, end;
    scanf("%d %d %d %d %d", &minW, &maxW, &minL, &maxL, &minH);
    scanf("%d %d", &start, &end);

    for (int i = 0; i < MAX_NODES; i++) parent[i] = i;

    int u, v, w, l, h;
    while (1) {
        scanf("%d", &u);
        if (u == -1) break;
        scanf("%d %d %d %d", &v, &w, &l, &h);
        if (w >= minW && h >= minH) {
            union_sets(u, v);
        }
    }

    printf("%d\n", find(start) == find(end) ? minL : 0);
    return 0;
}
