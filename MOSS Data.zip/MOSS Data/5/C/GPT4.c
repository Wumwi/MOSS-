#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <queue>

#define MAX_NODES 100

typedef struct {
    int node, max_length;
} Node;

typedef struct {
    int width, length, height;
} Dimensions;

Dimensions dim[MAX_NODES][MAX_NODES];
int adj[MAX_NODES][MAX_NODES];

int dijkstra(int start, int end, int minW, int minH) {
    std::priority_queue<Node> pq;
    int dist[MAX_NODES] = {0};
    dist[start] = INT_MAX;
    pq.push({start, INT_MAX});

    while (!pq.empty()) {
        Node current = pq.top();
        pq.pop();

        if (current.node == end) return current.max_length;

        for (int i = 0; i < MAX_NODES; i++) {
            if (adj[current.node][i] && dim[current.node][i].width >= minW && dim[current.node][i].height >= minH) {
                int possible = min(current.max_length, dim[current.node][i].length);
                if (possible > dist[i]) {
                    dist[i] = possible;
                    pq.push({i, possible});
                }
            }
        }
    }
    return 0;
}

int main() {
    int minW, maxW, minL, maxL, minH;
    int start, end;
    scanf("%d %d %d %d %d", &minW, &maxW, &minL, &maxL, &minH);
    scanf("%d %d", &start, &end);

    int u, v, w, l, h;
    while (1) {
        scanf("%d", &u);
        if (u == -1) break;
        scanf("%d %d %d %d", &v, &w, &l, &h);
        adj[u][v] = adj[v][u] = 1;
        dim[u][v] = dim[v][u] = {w, l, h};
    }

    int result = dijkstra(start, end, minW, minH);
    printf("%d\n", result);

    return 0;
}
