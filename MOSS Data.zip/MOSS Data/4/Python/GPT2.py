def dfs(student, adj_list, visited):
    visited[student] = True
    group_size = 1
    for neighbor in adj_list[student]:
        if not visited[neighbor]:
            group_size += dfs(neighbor, adj_list, visited)
    return group_size

def solve_scenario_dfs(students, relations):
    adj_list = defaultdict(list)
    visited = [False] * students

    for student, related in relations.items():
        for r in related:
            adj_list[student].append(r)
            adj_list[r].append(student)

    groups_with_four_or_more = 0
    people_outside_groups = 0

    for i in range(students):
        if not visited[i]:
            group_size = dfs(i, adj_list, visited)
            if group_size >= 4:
                groups_with_four_or_more += 1
            else:
                people_outside_groups += group_size

    return groups_with_four_or_more, people_outside_groups

# Main
num_scenarios = int(input())
for case_num in range(1, num_scenarios + 1):
    students = int(input())
    relations = {}
    for _ in range(students):
        data = list(map(int, input().split()))
        student = data[0] - 1
        relations[student] = [x - 1 for x in data[2:]]
    
    groups, outsiders = solve_scenario_dfs(students, relations)
    print(f"Caso #{case_num}")
    print(f"{groups} {outsiders}")
