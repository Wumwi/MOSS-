import copy
"""
def dfs(g,s,visto=None):
    if s not in g.keys():
        return []
    if visto == None:
        visto = [s]
    for k in g[s]:
        if k not in visto: 
            visto.append(k)
            dfs(g,k,visto)
    return visto
"""

vistos = []
ordem = []
def dfs(g,u):
    global vistos
    vistos.append(u)
    for v in g[u]:
        if v not in vistos: dfs(g,v)
    ordem.append(u)

#vistos = []
#g -> transposto
def dfs_xpto(g,u):
    vistos.append(u)
    c = 1
    for v in g[u]:
        if v not in vistos:
            c += dfs_xpto(g,v)
    return c

"""
def dfs2(g,s,x,visto=None):
    if s not in g.keys():
        return []
    if visto == None:
        visto = [s]
    for k in g[s]:
        if k not in visto and k not in x: 
            visto.append(k)
            dfs2(g,k,x,visto)
    return visto
"""
    
def gt(g):#grafo transposto
    gr={}
    for i in g:
        adj=[j for j in g for k in g[j] if k==i]
        gr[i]=adj
    return gr

final ={}

def socio():
    ng=0
    np=0
    d={}
    maxvertex=0
    linhas=input()
    for z in range(linhas):
        y=input()
        l=y.split()
        code=int(l[0])
        if int(l[1])==0:#vai considerar o caso em que a pessoa nao se relaciona com ninguem
            d[code]=[]
            pass
        else: 
            partners=l[2:]
            for j in range(len(partners)):
                partners[j]=int(partners[j])
            d[code]=partners
    global vistos
    vistos = []
    for u in d:
       if u not in vistos:
           dfs(d,u)
    w = ordem
    q=[]#visitados do transposto
    f=[]
    groups=[]
    transpos=gt(d)
    w.reverse()
    #print w
    #print transpos
    vistos = []
    for k in w:
        if k not in vistos:
            c=dfs_xpto(transpos,k)
            #print "##",c
            if c>=4: ng+=1
            else: np+=c
    print(ng,np)


x=input()
for i in range(x):
    print("Caso"+ " "+"#"+str(i+1))
    socio()    


