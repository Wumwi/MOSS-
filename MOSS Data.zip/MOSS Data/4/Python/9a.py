#---------------------------------------##----------------------#
#Funcao para devolver os fortemente conexos do grafo
#p-> pilha fin->ultimo g->grupo

def fconex(gra):
    
    gca = [ ]
    p = [ ]
    fin = { }
        
    def visit(no):
        if no in fin: return
	num = len(fin)
        fin[no] = num
        p_pos = len(p)
        p.append(no)
        for successor in gra[no]:
            visit(successor)
            fin[no] = min(fin[no], fin[successor])
        if num == fin[no]:
	    g = tuple(p[p_pos:])
            del p[p_pos:]
            gca.append(g)
	    for no in g:
	        fin[no] = len(gra)
    
    for no in gra:
        visit(no)
    return gca

#--------------------------------------##-----------------------#
#criar output

def criout(gca,na):
    pe=0
    ng=0
    totalg = 0
    for i in range(len(gca)):
        if (len(gca[i])>=4):
            ng+=1
            totalg += len(gca[i])
    if (ng!=0):
        pe = na-totalg
    else:
        pe = na
    return ng,pe


#--------------------------------------##-----------------------#
#output

def out(gca,na,i):
    ng=0
    pe=0
    ng,pe=criout(gca,na)
    print("Caso #"+str(i+1))
    print(ng,pe)

#--------------------------------------##-----------------------#
# converte lista de strings para ints

def conv(s1):
    for i in range(len(s1)):
        s1[i] = int(s1[i])
    return s1

#--------------------------------------##-----------------------#
# inserir grafo

def insg (s1,gra):
     if (s1[1] != 0):
         for j in range(2,len(s1),1):
             if gra.has_key(s1[0]):
                 gra[s1[0]].append(s1[j])
             else:
                 gra[s1[0]] = [s1[j]]
     else:
         gra[s1[0]] = []
     return gra

#--------------------------------------##-----------------------#
# inserir nalunos

def insn (nalunos,gra):
    for i in range(nalunos):
        al = input()
        s1 = al.split()
        s1 = conv(s1)
        gra = insg(s1,gra)
    return gra

#--------------------------------------##-----------------------#
#t1 valor n e key
def t1(gra):
    k = gra.keys()
    v = gra.values()
    for i in range(len(v)):
        j = 0
        while j < len(v[i]):
            if v[i][j] not in k:
                v[i].pop(j)
            j += 1


#--------------------------------------##-----------------------#
# Corre e cria o grafo 

def cenas(nalunos):
    gra={}
    insn(nalunos,gra)
    t1(gra)
    return fconex(gra)
        
#--------------------------------------##-----------------------#
#le os n casos

def iniciar(gca):
    casos = input()
    for i in range(casos):
        nalunos = input()
        out(cenas(nalunos),nalunos,i)

#--------------------------------------##-----------------------#
#funcao principal

def ex1():
    gca=[]
    iniciar(gca)
ex1()
