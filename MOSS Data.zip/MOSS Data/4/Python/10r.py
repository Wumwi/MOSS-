import sys,string
def strongly_connected_components(graph):
       
    result = [ ]
    stack = [ ]
    low = { }
        
    def visit(node):
        if node in low: return
	
	num = len(low)
        low[node] = num
        stack_pos = len(stack)
        stack.append(node)
	
        for successor in graph[node]:
            visit(successor)
            low[node] = min(low[node], low[successor])
        
        if num == low[node]:
	    component = tuple(stack[stack_pos:])
            del stack[stack_pos:]
            result.append(component)
	    for item in component:
	        low[item] = len(graph)
    
    for node in graph:
        visit(node)
    
    return result


def topological_sort(graph):
    count = { }
    for node in graph:
        count[node] = 0
    for node in graph:
        for successor in graph[node]:
            count[successor] += 1

    ready = [ node for node in graph if count[node] == 0 ]
    
    result = [ ]
    while ready:
        node = ready.pop(-1)
        result.append(node)
        
        for successor in graph[node]:
            count[successor] -= 1
            if count[successor] == 0:
                ready.append(successor)
    
    return result


def robust_topological_sort(graph):
   
    components = strongly_connected_components(graph)

    node_component = { }
    for component in components:
        for node in component:
            node_component[node] = component

    component_graph = { }
    for component in components:
        component_graph[component] = [ ]
    
    for node in graph:
        node_c = node_component[node]
        for successor in graph[node]:
            successor_c = node_component[successor]
            if node_c != successor_c:
                component_graph[node_c].append(successor_c) 

    return topological_sort(component_graph)



def ler():
    contar={}
    numpessoas=input()
    while numpessoas>0:
        numpessoas-=1
        a=input().split(' ')
        quemconta=int(a[0])
        aux=a[2:]
        #for i in range(int(a[1])):
            #contar[quemconta][i]=int(aux[i])
        #print aux
        #num=(int(a[1]))
        #if num>0:
        #print a
        #print a[1]
        if int(a[1])!=0:
            for i in range(int(a[1])):
                aux[i]=int(aux[i])
            contar[quemconta]=aux
            #i+=1
    #print type(contar[1][1])
    return contar


numcasos=input()
caso=1
while caso<=numcasos:
    grupos=0
    fora=0
    contar=ler()
    #contar[0]=[]
    #print contar    
    if __name__ == '__main__':
        res= robust_topological_sort(contar)
    tam=len(res)
    for i in range(tam):
        if len(res[i])>=4:
            grupos+=1
        else:
            fora+=1
    print('Caso #%d' %caso)
    print(grupos,fora)
    caso+=1
