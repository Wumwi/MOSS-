def read_input():

    num_students=input()

    dic={}
    dic_student={}
    dic_case_student={}
    end=False

    for i in range (0,num_students):
        a=input().split()
        case_student=int(a[0])
        num_case_student=int(a[1])
        
        list_aux=[]
        
        if dic_student.has_key(case_student) or case_student<1:
            end=True
        else:
            dic_student[case_student]=0
            
            if len(dic_student)==1 and len(dic_case_student)==0:
                  dic_case_student[case_student]=0                         
            
        for j in range(0,num_case_student):
            element=int(a[j+2])
            list_aux.append(element)
            
            if not dic_case_student.has_key(element):
                if element<1:
                    end=True
                else:
                    dic_case_student[element]=0

        dic[case_student]=list_aux
  
    if end==False and check(end,dic_student,dic_case_student)==False:
        return (num_students,dic)
    else:
        return (num_students,{})

def check(end,d_s,d_cs):

    if end==False:
        for i in d_cs.keys():
            if not d_s.has_key(i):
                end=True
                break
            
    return end

def search(dic,index,group,n,stack,aux):

    if index in aux: return (group,n)

    k = len(aux)
    aux[index] = k
    stack_pos = len(stack)
    stack.append(index)
    
    for i in dic[index]:
        if i not in aux:
            (group,n) = search(dic,i,group,n,stack,aux)
            aux[index] = min(aux[index], aux[i])
        elif i in stack:
            aux[index] = min(aux[index], aux[i])
            
    if k == aux[index]:
        list_aux = stack[stack_pos:]
        del stack[stack_pos:]
        if len(list_aux)>=4:
            group+=1
            n=n-len(list_aux)
    
    return (group,n)

def main():

    num_scenarios=input()

    for i in range (0,num_scenarios):
        (n,dic)=read_input()
        group=0

        if dic!={}:
            stack = [ ]
            aux = { }
            for index in dic:
                (group,n) = search(dic,index,group,n,stack,aux)

        string = "Caso #" + str(i+1)
        print(string)
        print(group,n)

main()
