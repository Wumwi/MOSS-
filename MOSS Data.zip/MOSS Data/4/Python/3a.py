
def ler():
  global N, G
  N = input()
  G = {}
  for i in range(N):
    lst = map(int,input().split())
    G[lst[0]] = lst[2:]
  
def dfs1(u):
  for v in G[u]:
    if v not in V:
      V.append(v)
      dfs1(v)
  S.append(u)  
  
def dfs2(u):  
  if u in V:
    return
  V.append(u)
  GRUPO.append(u)
  for v in Gt[u]:
    if v not in V:  
      dfs2(v)
    
def resolver():
  global S, V, Gt, GRUPO
  V = []
  S = []  
  for u in G:
    if u not in S:
      V.append(u)
      dfs1(u)
  Gt = {}
  for u in G:
    Gt[u] = []
  for u in G:
    for v in G[u]:
      Gt[v].append(u)
  V = []   
  A, B = 0, 0
  while S != []:
    u = S.pop()
    if u not in V:
      GRUPO = []
      dfs2(u)
      if len(GRUPO) >= 4:
        A += 1
      else:
        B += len(GRUPO)
  print(A, B      )
        
      
C = input()
for i in range(C):
  print("Caso #%d" % (i+1))
  ler()
  resolver()
