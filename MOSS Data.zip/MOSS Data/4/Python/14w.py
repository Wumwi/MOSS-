def ler():
    contar={}
    numpessoas=input()
    #if numpessoas<4:
        #return 0
    while numpessoas>0:
        numpessoas-=1
        a=input().split(' ')
        quemconta=int(a[0])
        aux=a[2:]
        if int(a[1])!=0:
            for i in range(int(a[1])):
                aux[i]=int(aux[i])
            contar[quemconta]=aux
        else:
            contar[quemconta]=[]
    return contar


def fecho_transitivo(graph,node):
    dicaux=graph
    tam=len(graph.keys())
    for destino in graph[node]:
        for dest2 in graph[destino]:
            #print dest2,destino
           #print dicaux
            #if dest2>=tam:
                #print destino
                #print'erro',dest2
                #print graph
                #print graph[node],dest2
                #graph[destino].remove(dest2)
                #print 'final',graph
            if dest2 not in dicaux[node]:
                dicaux[node].append(dest2)
                #print dicaux[node]
    return dicaux

def contagem_grupos(dic):
    indgrup=[]
    grupos=fora=count=0
    for i in dic.keys():
        dic[i]=sorted(dic[i])
    for i in range(1,len(dic.keys())+1):
        for j in range(1,len(dic.keys())+1):
            if dic[i]==dic[j] and dic[i]!=[]:# and i!=j:#and len(dic[i])>=4 and len(dic[j])>=4:
                #print i,dic[i],'IGUAL A',j,dic[j]
                if j not in indgrup:
                    indgrup.append(j)
                    count+=1
                    #print indgrup,count
        if count>=4:
            #print 'novo grupo', indgrup,count
            grupos+=1
            count=0
        else:
            #print 'mandar fora',count,indgrup
            if len(indgrup)==count:
                indgrup=[]
            else:
                for k in range(count):
                    #print 'FORA',indgrup[len(indgrup)-1]
                    indgrup.pop(len(indgrup)-1)
            #print 'indgrup final',indgrup
            count=0
            
    for i in range(1,len(dic.keys())+1):
        if i not in indgrup:
            #print 'fora',i,fora
            fora+=1
    return grupos,fora


numcasos=input()
caso=1
while caso<=numcasos:
    #print 'INICIO'
    grupos=0
    fora=0
    contar=ler()
    #if contar==0:
        #break
    #print contar, caso
    for node in contar:
        res=fecho_transitivo(contar,node)
    grupos,fora=contagem_grupos(res)
    print('Caso #%d' %caso)
    print(grupos,fora)
    caso+=1
