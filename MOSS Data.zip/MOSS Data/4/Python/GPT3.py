class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))
        self.size = [1] * n

    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, a, b):
        rootA = self.find(a)
        rootB = self.find(b)
        if rootA != rootB:
            if self.size[rootA] < self.size[rootB]:
                self.parent[rootA] = rootB
                self.size[rootB] += self.size[rootA]
            else:
                self.parent[rootB] = rootA
                self.size[rootA] += self.size[rootB]

def solve_scenario_union_find(students, relations):
    uf = UnionFind(students)

    for student, related in relations.items():
        for r in related:
            uf.union(student, r)

    root_count = defaultdict(int)
    for i in range(students):
        root = uf.find(i)
        root_count[root] += 1

    groups_with_four_or_more = sum(1 for size in root_count.values() if size >= 4)
    people_outside_groups = sum(size for size in root_count.values() if size < 4)

    return groups_with_four_or_more, people_outside_groups

# Main
num_scenarios = int(input())
for case_num in range(1, num_scenarios + 1):
    students = int(input())
    relations = {}
    for _ in range(students):
        data = list(map(int, input().split()))
        student = data[0] - 1
        relations[student] = [x - 1 for x in data[2:]]
    
    groups, outsiders = solve_scenario_union_find(students, relations)
    print(f"Caso #{case_num}")
    print(f"{groups} {outsiders}")
