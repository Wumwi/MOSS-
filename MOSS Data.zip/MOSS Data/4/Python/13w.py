def ler_valores():
    seq = input()
    aux = seq.split()
    lista = []
    for x in aux:
        lista = lista + [int(x)]
    return lista


def sociologia():
    n_cenarios = input()
    output_final=""
    for i in range(1,n_cenarios+1):
        num_alunos = input()
        sabe_historia={}
        for x in range(1,num_alunos+1):
            sabe_historia[x]=[x]
        while num_alunos > 0:
            a = ler_valores()
            aluno = a[0] 
            n_amigos = a[1]
            lst_amigos = a[2:]
            for k in lst_amigos:
                sabe_historia[k].append(aluno)

                            
            num_alunos -= 1
#        print sabe_historia
        output1,output2=valida_Grupos(verifica_Cenario(sabe_historia))
        output_final+="Caso #" + str(i) + "\n" + str(output1) + " "  + str(output2)
        if i != (n_cenarios):
            output_final+="\n"
    return output_final


def verifica_Cenario(d):
    grupos=[]
    visitados=[]
    tamanho = len(d.keys())
    for x in range(1,(tamanho+1)):
        if x not in visitados:
            grupos.append(dfs(d,x,visitados))
            visitados+=grupos[-1]

    return grupos

def dfs(g,s,lst,V=[]):
    if V == []:
        V = [s]
    for x in g[s]:
        if (x not in V) and (x not in lst):
            V += [x]
            dfs(g,x,lst,V)
    return V
   

def valida_Grupos(list):
    n_grupos=0
    pess_sem_grupos =0
    for x in range(len(list)):
        if len(list[x]) >= 4:
            n_grupos+=1
        else:
            pess_sem_grupos += len(list[x])
    
    return n_grupos, pess_sem_grupos
        
print(sociologia())
