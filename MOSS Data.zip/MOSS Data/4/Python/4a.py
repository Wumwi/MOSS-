def dfs(g,s,visited=None):
    if visited==None:
        visited=[s]
    for v in g[s]:
        if v not in visited:
            visited.append(v)
            dfs(g,v,visited)
    return visited

class grapho:

    def __init__(self):
        self.size = 0
        self.nos = []
        self.dicionario = {}

    def add_no(self,n):
        self.size = self.size + 1
        self.nos.append(n)
        self.dicionario[n] = []
    
    def nr_nos(self):
        return self.nos
    
    def getgrapho(self):
        return self.dicionario
    
def introduzir():
    cenarios = input() #introduzir o nr de canrios
    for i in range(cenarios):
        grafo = grapho()
        l_grupos = []
        num_grupos = 0
        countdic = {}
        semgrupo = 0
        alunos = input() #introduzir o nr de alunos com q s relaciona
        for j in range(alunos):
            aluno_l = input().split() #introduzir os alunos relacionados
            no = int(aluno_l[0]) #converter de string para inteiro
            rel_aluno = int(aluno_l[1])
            grafo.add_no(no) #inserir no dicionario o aluno
            if rel_aluno > 0:
                for k in range(2,len(aluno_l)): #criar uma lista com os alunos relacionados apenas
                    relacionados = int(aluno_l[k])
                    grafo.dicionario[no].append(relacionados)
        for q in grafo.nr_nos(): #percorrer as varias listas do dicionario
            new_group = dfs(grafo.getgrapho(),q)
            new_group.sort()
            if len(new_group) < 4: #grupo com menos d 4 elementos
                semgrupo = semgrupo + 1
            elif new_group not in l_grupos:
                l_grupos.append(new_group)
                indice_g = (len(l_grupos)-1)
                countdic[indice_g] = 1
            else:
                for m in range(len(l_grupos)): #grupo com 4 ou mais de 4 pessoas
                    if l_grupos[m] == new_group:
                        indice_g = m
                countdic[indice_g] = countdic[indice_g] + 1

        for p in range(len(countdic)):
            if countdic[p] < 4:
                semgrupo = semgrupo + countdic[p] #n tem grupo
            else:
                num_grupos = num_grupos + 1 #tem grupo

        print("Caso #"+str(i+1))
        print(str(num_grupos)+" "+str(semgrupo))

introduzir()
