def relation():
    x=input()
    transposto={}
    grafo={}
    vertex=[]
    result=[]
    global cam
    cam = []
    global stack
    stack=[]
    global visi
    visi=[]
    for i in range(x):
        cenario=input()
        cenario=cenario.split()
        pai=None
        for i in range(len(cenario)):
            k=int(cenario[i])
            if pai == None:
                pai=k
                grafo[pai]=[]
                vertex.append(pai)
            if i > 1:
                grafo[pai].append(k)
                if k not in transposto:
                    transposto[k]=[pai]
                else:
                    transposto[k].append(pai)
    for g in vertex:
        if not transposto.has_key(g):
            transposto[g]=[]
    root=grafo.keys()[0]
    m=dfs(vertex,root,grafo)
    for k in grafo:
        if k not in m:
            j=dfs(vertex,k,grafo,m)
    s=len(stack)
    while len(stack) > 0:
        d=stack.pop()
        if d not in visi:
            result.append(dfs1(transposto,d))
            cam=[]
    c=0
    l=0
    for i in result:
        if len(i) >= 4:
            c=c+1
        else:
            l=l+len(i)
    return [c,l]
    
def dfs(vertex,root,grafo,visited=None):
    if visited == None:
        visited=[root]
    if len(stack) == len(vertex):
        return stack
    else:
        for i in grafo[root]:
            if i not in visited:
                visited.append(i)
                dfs(vertex,i,grafo,visited)
        stack.append(root)
    return stack

def dfs1(transposto,root):
    if root not in visi:
        visi.append(root)
    cam.append(root)
    for i in transposto[root]:
        if i not in visi:
            visi.append(i)
            dfs1(transposto,i)
    return cam
    

def cenarios():
    x=input()
    for i in range(x):
        b = relation()
        visi=[]
        stack=[]
        print("Caso #"+str(i+1))
        print(b[0],b[1])
        

cenarios()
