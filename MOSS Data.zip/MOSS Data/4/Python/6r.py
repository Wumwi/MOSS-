import string

######ler dados#####
def ler_dados():
    lista = []
    a = input()
    a = string.split(a)
    for x in a:
        lista = lista + [int(x)]
    return lista



def Trabalho_a():
    a = []
    b = []
    temp = []
    n_cenarios = []
    x = 0
    temp1 = []
    graf_key = []

    
    cenarios = int(input())
    for i in range(cenarios):
        grafo = {}
        descr_cenarios = int(input())
        n_cenarios.append(descr_cenarios)
        for j in range(descr_cenarios):
            a = ler_dados()
            temp = []
            if a[1] != 0:
                for z in range(2,len(a)):
                    temp.append(a[z])
                grafo[a[0]] = temp
                
            else:
                grafo[a[0]] = []
        caminhos(grafo,descr_cenarios,i)

def caminhos(grafo,temporaria,temporaria2):
    graf_key = grafo.keys()
    grupo1_temp=[]
    grupo2_temp=[]
    grupos=[]
#1PASSAGEM!!!!(caminho numa direc�ao)
    for toma in graf_key:
        grup_temp = []
        for ab in range(len(graf_key)):
            a = bfs(grafo,toma,ab+1, [])
            if a == True:
                if ab not in grup_temp:
                    grup_temp.append(ab)
        inc (grup_temp)
        grupo1_temp.append(grup_temp)

        final = []
        final2= []
        
    final=elimina_rep(grupo1_temp)
    
#2 PASSAGEM!!!(Caminho em direc�ao contraria)
    final2=teste(grafo,final,temporaria,temporaria2)    
     
        

  
def teste(grafo,grupo1_temp,temp,temporaria2):
    tamanho=0
    contador=0
    final=[]
    b=[]
    c=[]
    c=elimina_rep(grupo1_temp)
    for i in range(len(c)):
        b=[]
        for j in range(len(c[i])):
            a = bfs(grafo,c[i][j],c[i][0], [])
            if a==True:
                b.append(c[i][j])
        final.append(b)
    for z in range(len(final)):
        if len(final[z])>=4:
            contador+=1
            tamanho=tamanho+len(final[z])
    print"Caso #%d"%temporaria2
    if (tamanho-temp)<0:
        print(contador," ",(tamanho-temp)*-1)
    else:
        print(contador,tamanho-temp)
                                   
                    

    
def bfs(g,s,t,vis):
    if s==t:
        return True
    vis.append(s)
    adj=g[s]
    for x in adj:
        if not (x in vis):
            if bfs(g,x,t,vis):
                return True
    vis.pop()
    return False



def inc(lista):
    for i in range(len(lista)):
        lista[i]=lista[i]+1
    return lista

def elimina_rep(lista):
    a=[]
    for i in range(len(lista)):
        if lista[i] not in a:
            a.append(lista[i])
    return a

def elimina_azia(lista):
    final=[]
    for i in range(len(lista)):
        if len(lista[i])==1:
            valor_eliminar=lista[i][0]
            for a in range(len(lista)):
                if valor_eliminar in lista[a]:
                    final.append(elimina_valor(lista[a],valor_eliminar))
    print(final)

def elimina_valor(lista,valor):
    for i in range(len(lista)):
        if valor==lista[i]:
            temp=i
    del lista[temp]
    return lista

Trabalho_a()

