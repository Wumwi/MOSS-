def readiln():
    return map(int, input().split())

def search(povo, genesis, visited):
    for i in povo[genesis]:
        if i not in visited:
            visited.append(i)
            search(povo, i, visited)
    return visited

num_cenarios = input()
for i in xrange(num_cenarios):
    povo, grupos = {}, {}
    num_pessoas = input()
    for j in xrange(num_pessoas):
        aux = readiln()
        pessoa, num_amigos = aux[0], aux[1]
        aux = aux[2:]
        povo[pessoa], grupos[pessoa] = aux, []
        
    caminhos, grupos, egrupo, negrupo, adicionados = {}, {}, 0, 0, []
    for j in povo:
        caminhos[j] = search(povo, j, [j])
        
    for j in caminhos:
        grupos[j] = []
        for k in caminhos[j]:
            if j in caminhos[k]:
                grupos[j].append(k)
        if len(grupos[j]) > 3:
            if j not in adicionados:
                egrupo += 1
                adicionados += grupos[j]
        else:
            negrupo += 1

    print("Caso #%d" % (i))
    print(egrupo, negrupo)
