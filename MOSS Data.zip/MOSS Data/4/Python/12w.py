def dfs(g,s,visto=None):
    if s not in g.keys():
        return []
    if visto == None:
        visto = [s]
    for k in g[s]:
        if k not in visto: 
            visto.append(k)
            dfs(g,k,visto)
    return visto

def dfs2(g,s,x,visto=None):
    if s not in g.keys():
        return []
    if visto == None:
        visto = [s]
    for k in g[s]:
        if k not in visto and k not in x: 
            visto.append(k)
            dfs2(g,k,x,visto)
    return visto
    
def gt(g):#grafo transposto
    gr={}
    for i in g:
        adj=[j for j in g for k in g[j] if k==i]
        gr[i]=adj
    return gr

final ={}

def socio():
    ng=0
    np=0
    d={}
    maxvertex=0
    linhas=input()
    for z in range(linhas):
        y=input()
        l=y.split()
        code=int(l[0])
        if code>maxvertex:
            maxvertex=code
        if int(l[1])==0:#vai considerar o caso em que a pessoa nao se relaciona com ninguem
            d[code]=[]
            pass
        else: 
            partners=l[2:]
            for j in range(len(partners)):
                partners[j]=int(partners[j])
            d[code]=partners
    r=[]
    w=[]
    for u in d:
       if u not in r:
           r=dfs2(d,u,w)
           for j in r:
               if j not in w:
                   w.append(j)
                   
    f=[]
    q=[]#visitados do transposto
    groups=[]
    transpos=gt(d)
    for k in w:
        if k not in f:
            q=dfs2(transpos,k,f)
            f=q
            f.sort()
            groups.append(f)
    for p in range(len(groups)-1):
        for p1 in range(p+1,len(groups)):
            if groups[p]==groups[p1]:
                groups[p]=None
    
    for c in groups:
        if c!=None:
            if len(c)>=4:
                ng+=1
            else:
                np+=len(c)
    final[i+1]=[ng,np]#i+1 porque o ciclo for dos casos comeca em 0   
    

x=input()
for i in range(x):
    socio()
for v in final:
    print("Caso"+" "+"#"+str(v))
    print(str(final[v][0]) + " " + str(final[v][1]))
