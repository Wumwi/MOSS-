#!/usr/bin/env python

#Implementacao do algoritmo de Tarjan
def fconexos(grafo):
 
	grupos = [ ]
	pilha = [ ]
	low = { }
 
	def visit(no):
		if no in low: return

		n = len(low)
		low[no] = n
		pos = len(pilha)
		pilha.append(no)

		for successor in grafo[no]:
			visit(successor)
			low[no] = min(low[no], low[successor])
 
		if n == low[no]:
			x = pilha[pos:]
			del pilha[pos:]
			grupos.append(x)
			for y in x:
				low[y] = len(grafo)

	for no in grafo:
		visit(no)

	return grupos

def escrever(result,x):
	g = 0
	s = 0
	for i in range(len(result)):
		if len(result[i]) < 4:
			s+=len(result[i])
		else:
			g+=1

	print("Caso #"+str(x+1))
	print(g,s)

def sociologia():
	cenario = {}
	saida = []
	num_cenarios = input()
	c = 0
	for i in range(num_cenarios): 
		num_alunos = input()
		for k in range(num_alunos):
			linha = input()
			s = linha.split() 
			lista = []
			if (int(s[1]) != 0):
				for n in range(2,len(s)):
					lista.append(s[n])
			cenario[s[0]] = lista

		grupos = fconexos(cenario)
		escrever(grupos,i)
sociologia()
