def sociologia():
    n_casos=input()
    caso=1
    while n_casos > 0:
        x=trata_caso()
        print("Caso #%d" % (caso))
        n_grupos=0
        n_sozinhos=0
        for i in x:
            if len(i) >3:
                n_grupos+=1
            if len(i)<=3:
                n_sozinhos+=len(i)
        print(n_grupos,n_sozinhos)
        caso+=1
        n_casos-=1        

def tarjan(dic):
    resultado =[]
    stck=[]
    low={}
    for no in dic:
        check(no,resultado,stck,low,dic)
    return resultado

def trata_caso():
    dic = {}
    n_pessoas=input()
    while n_pessoas > 0:
        pessoa = get_pessoa()

        dic[pessoa[0]]=[]
        i=2
        while pessoa[1] > 0:
            dic[pessoa[0]]+=[pessoa[i]]
            pessoa[1]-=1
            i+=1
        n_pessoas-=1
    return tarjan(dic)

def check(no,resultado,stck,low,dic):
    if no in low:
        return
    comp_low = len(low)
    low[no] = comp_low
    stck_pos = len(stck)
    stck.append(no)
    for next in dic[no]:
        check(next,resultado,stck,low,dic)
        low[no] = min(low[no], low[next])
    if comp_low == low[no]:
        grp = tuple(stck[stck_pos:])
        del stck[stck_pos:]
        resultado.append(grp)
        for i in grp:
            low[i] = len(dic)
	        
def get_pessoa():
    x=input().split()
    for i in range(len(x)):
           x[i]=int(x[i])
    return x

sociologia()
