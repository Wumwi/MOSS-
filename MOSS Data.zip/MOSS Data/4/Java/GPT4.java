import java.util.*;

public class SociologyExperimentAdjListBFS {
    private static final int MAX = 100;
    private static List<Integer>[] adjList = new ArrayList[MAX];
    private static boolean[] visited = new boolean[MAX];
    private static int students;

    private static int bfs(int start) {
        Queue<Integer> queue = new LinkedList<>();
        queue.add(start);
        visited[start] = true;
        int groupSize = 1;

        while (!queue.isEmpty()) {
            int student = queue.poll();
            for (int neighbor : adjList[student]) {
                if (!visited[neighbor]) {
                    queue.add(neighbor);
                    visited[neighbor] = true;
                    groupSize++;
                }
            }
        }
        return groupSize;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int scenarios = scanner.nextInt();

        for (int caseNum = 1; caseNum <= scenarios; caseNum++) {
            students = scanner.nextInt();

            for (int i = 0; i < students; i++) {
                adjList[i] = new ArrayList<>();
                visited[i] = false;
            }

            for (int i = 0; i < students; i++) {
                int student = scanner.nextInt() - 1;
                int relations = scanner.nextInt();
                for (int j = 0; j < relations; j++) {
                    int related = scanner.nextInt() - 1;
                    adjList[student].add(related);
                    adjList[related].add(student);
                }
            }

            int groupsWithFourOrMore = 0;
            int peopleOutsideGroups = 0;

            for (int i = 0; i < students; i++) {
                if (!visited[i]) {
                    int groupSize = bfs(i);
                    if (groupSize >= 4) {
                        groupsWithFourOrMore++;
                    } else {
                        peopleOutsideGroups += groupSize;
                    }
                }
            }

            System.out.println("Caso #" + caseNum);
            System.out.println(groupsWithFourOrMore + " " + peopleOutsideGroups);
        }
        scanner.close();
    }
}
