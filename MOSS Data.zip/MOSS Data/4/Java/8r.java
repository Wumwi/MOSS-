import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Scanner;

class No{
	int val;
	int tempof;
	LinkedList<No> adj;
	boolean visitado;
	int dia;

	No(int n){
		val = n;
		tempof = 0;
		adj = new LinkedList<No>();
		visitado = false;
	}
	void addLigacao(No x){
		adj.addLast(x);
	}
}

class Grafo{
	int tempo, nalunos;
	No g[];
	No gt[];
	LinkedList<Integer> grupos;

	Grafo(int np){
		this.nalunos = np;
		tempo = 0;
		g = new No[np+1];
		gt = new No[np+1];
		grupos = new LinkedList<Integer>();
	}
	private void inicializar(){
		for(int i = 1; i<=nalunos; i++){
			g[i] = new No(i);
			gt[i] = new No(i);
		}
	}
	void criaGrafo(Scanner in){
		inicializar();
		for(int i = 1; i<=nalunos; i++){
			int namigo = in.nextInt();
			for(int j = 0; j<namigo; j++){
				int amigo = in.nextInt();
				g[i].addLigacao(g[amigo]);
				gt[amigo].addLigacao(gt[i]);
			}
		}
	}
	private void limp(){
		for(int i=1; i<=nalunos; i++){
			g[i].visitado=false;
		}
	}
	void BFS(){
		limp();
		LinkedList<No> lista = new LinkedList<No>();
		g[1].visitado=true;
		lista.addLast(g[1]);

		while(!lista.isEmpty()){
			No x = lista.removeFirst();
			for(No aux : x.adj){
				if(!aux.visitado){
					aux.visitado=true;
					aux.dia=x.dia+1;
					lista.addLast(aux);
				}
			}
		}    
	}

	private int max(){
		int max=0;
		for(int i=1; i<=nalunos; i++){
			if(g[i].dia>max) max=g[i].dia;
		}
		return max+1; 
	}
	void b(){
		System.out.println(max()); 

	}
}

public class Soci_1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int ncasos = input.nextInt();
		Grafo graf = new Grafo(ncasos);
		graf.criaGrafo(input);
		graf.BFS();
		graf.b();
	}

}
	