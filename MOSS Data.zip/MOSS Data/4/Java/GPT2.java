import java.util.*;

public class SociologyExperimentDFS {
    private static final int MAX = 100;
    private static boolean[][] adj = new boolean[MAX][MAX];
    private static boolean[] visited = new boolean[MAX];
    private static int students;

    private static int dfs(int student) {
        visited[student] = true;
        int groupSize = 1;
        for (int i = 0; i < students; i++) {
            if (adj[student][i] && !visited[i]) {
                groupSize += dfs(i);
            }
        }
        return groupSize;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int scenarios = scanner.nextInt();

        for (int caseNum = 1; caseNum <= scenarios; caseNum++) {
            students = scanner.nextInt();
            Arrays.fill(visited, false);
            for (int i = 0; i < students; i++) {
                Arrays.fill(adj[i], false);
            }

            for (int i = 0; i < students; i++) {
                int student = scanner.nextInt();
                int relations = scanner.nextInt();
                for (int j = 0; j < relations; j++) {
                    int related = scanner.nextInt();
                    adj[student - 1][related - 1] = true;
                    adj[related - 1][student - 1] = true;
                }
            }

            int groupsWithFourOrMore = 0;
            int peopleOutsideGroups = 0;

            for (int i = 0; i < students; i++) {
                if (!visited[i]) {
                    int groupSize = dfs(i);
                    if (groupSize >= 4) {
                        groupsWithFourOrMore++;
                    } else {
                        peopleOutsideGroups += groupSize;
                    }
                }
            }

            System.out.println("Caso #" + caseNum);
            System.out.println(groupsWithFourOrMore + " " + peopleOutsideGroups);
        }
        scanner.close();
    }
}
