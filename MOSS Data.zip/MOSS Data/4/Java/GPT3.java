import java.util.*;

public class SociologyExperimentUnionFind {
    private static final int MAX = 100;
    private static int[] parent = new int[MAX];
    private static int[] size = new int[MAX];
    private static int students;

    private static void initUnionFind() {
        for (int i = 0; i < students; i++) {
            parent[i] = i;
            size[i] = 1;
        }
    }

    private static int find(int x) {
        if (parent[x] != x) {
            parent[x] = find(parent[x]);
        }
        return parent[x];
    }

    private static void union(int a, int b) {
        int rootA = find(a);
        int rootB = find(b);
        if (rootA != rootB) {
            if (size[rootA] < size[rootB]) {
                parent[rootA] = rootB;
                size[rootB] += size[rootA];
            } else {
                parent[rootB] = rootA;
                size[rootA] += size[rootB];
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int scenarios = scanner.nextInt();

        for (int caseNum = 1; caseNum <= scenarios; caseNum++) {
            students = scanner.nextInt();
            initUnionFind();

            for (int i = 0; i < students; i++) {
                int student = scanner.nextInt() - 1;
                int relations = scanner.nextInt();
                for (int j = 0; j < relations; j++) {
                    int related = scanner.nextInt() - 1;
                    union(student, related);
                }
            }

            int groupsWithFourOrMore = 0;
            int peopleOutsideGroups = 0;
            boolean[] counted = new boolean[MAX];

            for (int i = 0; i < students; i++) {
                int root = find(i);
                if (!counted[root]) {
                    if (size[root] >= 4) {
                        groupsWithFourOrMore++;
                    } else {
                        peopleOutsideGroups += size[root];
                    }
                    counted[root] = true;
                }
            }

            System.out.println("Caso #" + caseNum);
            System.out.println(groupsWithFourOrMore + " " + peopleOutsideGroups);
        }
        scanner.close();
    }
}
