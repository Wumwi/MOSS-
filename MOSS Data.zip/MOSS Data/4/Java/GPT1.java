import java.util.*;

public class SociologyExperimentBFS {
    private static final int MAX_STUDENTS = 100;
    private static boolean[][] graph = new boolean[MAX_STUDENTS][MAX_STUDENTS];
    private static boolean[] visited = new boolean[MAX_STUDENTS];
    private static int students;

    private static int bfs(int start) {
        Queue<Integer> queue = new LinkedList<>();
        queue.add(start);
        visited[start] = true;
        int groupSize = 1;

        while (!queue.isEmpty()) {
            int student = queue.poll();
            for (int i = 1; i <= students; i++) {
                if (graph[student][i] && !visited[i]) {
                    queue.add(i);
                    visited[i] = true;
                    groupSize++;
                }
            }
        }
        return groupSize;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int scenarios = scanner.nextInt();

        for (int caseNum = 1; caseNum <= scenarios; caseNum++) {
            students = scanner.nextInt();
            Arrays.fill(visited, false);
            for (int i = 0; i < students; i++) {
                Arrays.fill(graph[i], false);
            }

            for (int i = 0; i < students; i++) {
                int student = scanner.nextInt();
                int relations = scanner.nextInt();
                for (int j = 0; j < relations; j++) {
                    int related = scanner.nextInt();
                    graph[student - 1][related - 1] = true;
                    graph[related - 1][student - 1] = true;
                }
            }

            int groupsWithFourOrMore = 0;
            int peopleOutsideGroups = 0;

            for (int i = 0; i < students; i++) {
                if (!visited[i]) {
                    int groupSize = bfs(i);
                    if (groupSize >= 4) {
                        groupsWithFourOrMore++;
                    } else {
                        peopleOutsideGroups += groupSize;
                    }
                }
            }

            System.out.println("Caso #" + caseNum);
            System.out.println(groupsWithFourOrMore + " " + peopleOutsideGroups);
        }
        scanner.close();
    }
}
