import java.util.*;

public class SociologyExperimentOptimizedDFS {
    private static final int MAX = 100;
    private static List<Integer>[] graph = new ArrayList[MAX];
    private static boolean[] visited = new boolean[MAX];
    private static int students;

    private static int dfs(int node) {
        visited[node] = true;
        int size = 1;
        for (int neighbor : graph[node]) {
            if (!visited[neighbor]) {
                size += dfs(neighbor);
            }
        }
        return size;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int scenarios = scanner.nextInt();

        for (int caseNum = 1; caseNum <= scenarios; caseNum++) {
            students = scanner.nextInt();

            for (int i = 0; i < students; i++) {
                graph[i] = new ArrayList<>();
                visited[i] = false;
            }

            for (int i = 0; i < students; i++) {
                int student = scanner.nextInt() - 1;
                int relations = scanner.nextInt();
                for (int j = 0; j < relations; j++) {
                    int related = scanner.nextInt() - 1;
                    graph[student].add(related);
                    graph[related].add(student);
                }
            }

            int groupsWithFourOrMore = 0;
            int peopleOutsideGroups = 0;

            for (int i = 0; i < students; i++) {
                if (!visited[i]) {
                    int groupSize = dfs(i);
                    if (groupSize >= 4) {
                        groupsWithFourOrMore++;
                    } else {
                        peopleOutsideGroups += groupSize;
                    }
                }
            }

            System.out.println("Caso #" + caseNum);
            System.out.println(groupsWithFourOrMore + " " + peopleOutsideGroups);
        }
        scanner.close();
    }
}
