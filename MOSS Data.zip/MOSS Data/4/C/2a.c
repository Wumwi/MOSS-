#include <stdio.h>
#include <stdlib.h>

int ** nei;
int * n_nei;
int ** anei;
int * n_anei;
int * vis;
int * stack;
int ct, ins, iso, loc;

void dfs_d(int cur)
{
  vis[cur] = 1;
  int i;
  for (i = 0; i < n_nei[cur]; i++)
    if (vis[nei[cur][i]] == 0)
      dfs_d(nei[cur][i]);
  vis[cur] = 2;
  stack[ct++] = cur;
  return;
}

void dfs_u(int cur)
{
  vis[cur] = 1;
  int i;
  for (i = 0; i < n_anei[cur]; i++)
    if (vis[anei[cur][i]] == 0)
      dfs_u(anei[cur][i]);
  vis[cur] = 2;
  loc++;
  return;
}

int main()
{
  int T, t, i, j;
  scanf("%d", &T);
  for (t = 1;  t <= T; t++)
    {
      int n;
      scanf("%d", &n);

      nei = (int **) malloc((n + 5) * sizeof(int *));
      n_nei = (int *) malloc((n + 5) * sizeof(int));
      anei = (int **) malloc((n + 5) * sizeof(int *));
      n_anei = (int *) malloc((n + 5) * sizeof(int));
      vis = (int *) malloc((n + 5) * sizeof(int));
      stack = (int *) malloc((n + 5) * sizeof(int));
      ct = 0, ins = 0, iso = 0;

      for (i = 0; i < n; i++)
	{
	  n_nei[i] = n_anei[i] = vis[i] = 0;
	  anei[i] = (int *) malloc(sizeof (int));
	}

      for (i = 0; i < n; i++)
	{
	  int a, m;
	  scanf("%d %d", &a, &m);
	  nei[a - 1] = (int *) malloc((m + 5) * sizeof(int));
	  n_nei[a - 1] = m;
	  for (j = 0; j < m; j++)
	    {
	      scanf("%d", &nei[a - 1][j]);
	      nei[a - 1][j]--;
	      int to = nei[a - 1][j];
	      n_anei[to]++;
	      anei[to] = (int *) realloc(anei[to], n_anei[to] * sizeof(int));
	      anei[to][n_anei[to] - 1] = a - 1;
	    }
	}
      
      for (i = 0; i < n; i++)
	if (vis[i] == 0)
	  dfs_d(i);

      for (i = 0; i < n; i++)
	vis[i] = 0;

      for (i = ct - 1; i >= 0; i--)
	if (vis[stack[i]] == 0)
	  {
	    loc = 0;
	    dfs_u(stack[i]);
	    if (loc > 3)
	      ins++;
	    else
	      iso += loc;
	  }

      printf("Caso #%d\n", t);
      printf("%d %d\n", ins, iso);
    }
  return 0;
}
