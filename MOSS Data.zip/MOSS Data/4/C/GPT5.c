#include <stdio.h>
#include <string.h>

#define MAX 100

int adj[MAX][MAX];
int visited[MAX];
int students;

void dfs(int node, int *size) {
    visited[node] = 1;
    (*size)++;
    for (int i = 1; i <= students; i++) {
        if (adj[node][i] && !visited[i]) {
            dfs(i, size);
        }
    }
}

int main() {
    int scenarios;
    scanf("%d", &scenarios);

    for (int case_num = 1; case_num <= scenarios; case_num++) {
        scanf("%d", &students);
        memset(adj, 0, sizeof(adj));
        memset(visited, 0, sizeof(visited));

        for (int i = 1; i <=
