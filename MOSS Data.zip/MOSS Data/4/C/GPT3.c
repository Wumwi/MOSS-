#include <stdio.h>

#define MAX 100

int parent[MAX];
int size[MAX];
int students;

void init(int n) {
    for (int i = 1; i <= n; i++) {
        parent[i] = i;
        size[i] = 1;
    }
}

int find(int x) {
    if (parent[x] != x) {
        parent[x] = find(parent[x]);
    }
    return parent[x];
}

void union_sets(int a, int b) {
    int rootA = find(a);
    int rootB = find(b);
    if (rootA != rootB) {
        if (size[rootA] < size[rootB]) {
            parent[rootA] = rootB;
            size[rootB] += size[rootA];
        } else {
            parent[rootB] = rootA;
            size[rootA] += size[rootB];
        }
    }
}

int main() {
    int scenarios;
    scanf("%d", &scenarios);

    for (int case_num = 1; case_num <= scenarios; case_num++) {
        scanf("%d", &students);
        init(students);

        for (int i = 1; i <= students; i++) {
            int student, count;
            scanf("%d %d", &student, &count);
            for (int j = 0; j < count; j++) {
                int other;
                scanf("%d", &other);
                union_sets(student, other);
            }
        }

        int groups_with_four_or_more = 0;
        int people_outside_groups = 0;
        int counted[MAX] = {0};

        for (int i = 1; i <= students; i++) {
            int root = find(i);
            if (!counted[root]) {
                if (size[root] >= 4) {
                    groups_with_four_or_more++;
                } else {
                    people_outside_groups += size[root];
                }
                counted[root] = 1;
            }
        }

        printf("Caso #%d\n%d %d\n", case_num, groups_with_four_or_more, people_outside_groups);
    }
    return 0;
}
