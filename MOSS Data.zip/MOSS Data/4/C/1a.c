#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_V 10005

int n, nconn[MAX_V], id, nc, adjList[MAX_V][MAX_V];
int dfs_num[MAX_V], dfs_low[MAX_V], vis[MAX_V];
int dfsCounter, numScc, qttGroups, qttIso, S[MAX_V], ps;
int SCC[MAX_V], szScc, onGroup[MAX_V];

void scc(int u){
  dfs_low[u] = dfs_num[u] = dfsCounter ++;
  S[ps ++] = u;
  vis[u] = 1;
  int i;
  for(i = 0; i < nconn[u]; i ++){
    int v = adjList[u][i];
    if(!dfs_num[v])
       scc(v);
    if(vis[v])
      dfs_low[u] = (dfs_low[u] <= dfs_low[v]) ? dfs_low[u] : dfs_low[v];
  }
  if(dfs_low[u] == dfs_num[u]){
    numScc ++;
    int szScc = 0;
    while(1){
      int v = S[ps - 1];
      ps --;
      vis[v] = 0;
      SCC[szScc ++] = v;
      if(u == v) break;
    }
    if(szScc >= 4){
      qttGroups ++;
      for(i = 0; i < szScc; i ++)
	onGroup[SCC[i]] = 1;
    }
  }
}

int main(){
  int c, cc, i, j;

  scanf("%d", &c);
  for(cc = 1; cc <= c; cc ++){

    scanf("%d", &n);
    for(i = 0; i < n; i ++){
      scanf("%d %d", &id, &nc);
      id --;
      nconn[id] = nc;
      for(j = 0; j < nconn[id]; j ++){
	scanf("%d", &adjList[id][j]);
	adjList[id][j] --;
      }
    }

    memset(dfs_num, 0, sizeof(dfs_num));
    memset(dfs_low, 0, sizeof(dfs_low));
    memset(vis, 0, sizeof(vis));
    memset(onGroup, 0, sizeof(onGroup));
    dfsCounter = numScc = qttIso = qttGroups = ps = 0;

    for(i = 0; i < n; i ++)
      if(!dfs_num[i])
	scc(i);

    for(i = 0; i < n; i ++)
      if(!onGroup[i])
	qttIso ++;

    printf("Caso #%d\n", cc);
    printf("%d %d\n", qttGroups, qttIso);
  }

  return 0;
}
