#include <stdio.h>
#include <string.h>

#define MAX 100

int adj[MAX][MAX];
int visited[MAX];
int students;

void dfs(int s, int *group_size) {
    visited[s] = 1;
    (*group_size)++;
    for (int i = 1; i <= students; i++) {
        if (adj[s][i] && !visited[i]) {
            dfs(i, group_size);
        }
    }
}

int main() {
    int scenarios;
    scanf("%d", &scenarios);

    for (int case_num = 1; case_num <= scenarios; case_num++) {
        scanf("%d", &students);
        memset(adj, 0, sizeof(adj));
        memset(visited, 0, sizeof(visited));

        for (int i = 1; i <= students; i++) {
            int student, count;
            scanf("%d %d", &student, &count);
            for (int j = 0; j < count; j++) {
                int other;
                scanf("%d", &other);
                adj[student][other] = 1;
                adj[other][student] = 1;
            }
        }

        int big_groups = 0, outside_people = 0;
        for (int i = 1; i <= students; i++) {
            if (!visited[i]) {
                int group_size = 0;
                dfs(i, &group_size);
                if (group_size >= 4)
                    big_groups++;
                else
                    outside_people += group_size;
            }
        }

        printf("Caso #%d\n%d %d\n", case_num, big_groups, outside_people);
    }
    return 0;
}
