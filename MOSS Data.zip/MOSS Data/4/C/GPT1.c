#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STUDENTS 100

int graph[MAX_STUDENTS][MAX_STUDENTS];
int visited[MAX_STUDENTS];
int students;

void bfs(int start, int *group_size) {
    int queue[MAX_STUDENTS];
    int front = 0, back = 0;

    queue[back++] = start;
    visited[start] = 1;
    (*group_size)++;

    while (front < back) {
        int student = queue[front++];
        for (int i = 1; i <= students; i++) {
            if (graph[student][i] && !visited[i]) {
                queue[back++] = i;
                visited[i] = 1;
                (*group_size)++;
            }
        }
    }
}

int main() {
    int scenarios;
    scanf("%d", &scenarios);

    for (int case_num = 1; case_num <= scenarios; case_num++) {
        scanf("%d", &students);

        memset(graph, 0, sizeof(graph));
        memset(visited, 0, sizeof(visited));

        for (int i = 1; i <= students; i++) {
            int student, num_relations;
            scanf("%d %d", &student, &num_relations);
            for (int j = 0; j < num_relations; j++) {
                int related;
                scanf("%d", &related);
                graph[student][related] = graph[related][student] = 1;
            }
        }

        int groups_with_four_or_more = 0;
        int people_outside_groups = 0;

        for (int i = 1; i <= students; i++) {
            if (!visited[i]) {
                int group_size = 0;
                bfs(i, &group_size);
                if (group_size >= 4) {
                    groups_with_four_or_more++;
                } else {
                    people_outside_groups += group_size;
                }
            }
        }

        printf("Caso #%d\n%d %d\n", case_num, groups_with_four_or_more, people_outside_groups);
    }

    return 0;
}
