#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100

typedef struct {
    int count;
    int adj[MAX];
} Node;

Node graph[MAX];
int visited[MAX];
int students;

void bfs(int start, int *group_size) {
    int queue[MAX];
    int front = 0, back = 0;
    queue[back++] = start;
    visited[start] = 1;
    (*group_size)++;

    while (front < back) {
        int curr = queue[front++];
        for (int i = 0; i < graph[curr].count; i++) {
            int neighbor = graph[curr].adj[i];
            if (!visited[neighbor]) {
                queue[back++] = neighbor;
                visited[neighbor] = 1;
                (*group_size)++;
            }
        }
    }
}

int main() {
    int scenarios;
    scanf("%d", &scenarios);

    for (int case_num = 1; case_num <= scenarios; case_num++) {
        scanf("%d", &students);

        memset(graph, 0, sizeof(graph));
        memset(visited, 0, sizeof(visited));

        for (int i = 1; i <= students; i++) {
            int student, count;
            scanf("%d %d", &student, &count);
            for (int j = 0; j < count; j++) {
                int other;
                scanf("%d", &other);
                graph[student].adj[graph[student].count++] = other;
                graph[other].adj[graph[other].count++] = student;
            }
        }

        int groups_with_four_or_more = 0, people_outside_groups = 0;
        for (int i = 1; i <= students; i++) {
            if (!visited[i]) {
                int group_size = 0;
                bfs(i, &group_size);
                if (group_size >= 4) {
                    groups_with_four_or_more++;
                } else {
                    people_outside_groups += group_size;
                }
            }
        }

        printf("Caso #%d\n%d %d\n", case_num, groups_with_four_or_more, people_outside_groups);
    }

    return 0;
}
