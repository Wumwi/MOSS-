#include <stdio.h>
#include <stdlib.h>

int width_min, width_max, length_min, length_max, height_min, ans;
int a, b, aux_width, aux_length, aux_height;


int main(){

  scanf("%*d"); 
  scanf("%d %d %d %d %d", &width_min, &width_max, &length_min, &length_max, &height_min);
  scanf("%*d %*d");

  ans = 0;

  while(1){
    scanf("%d", &a);
    if(a == -1) break;
    scanf("%d %d %d %d", &b, &aux_width, &aux_length, &aux_height);
    if(aux_width >= width_min && aux_length >= length_min && aux_height >= height_min)
      ans ++;
  }

  printf("%d\n", ans);
  
  return 0;
}
