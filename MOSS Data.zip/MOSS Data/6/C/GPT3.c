#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int start, end;
    int maxWidth, maxLength, maxHeight;
} Section;

int main() {
    int numPlaces;
    scanf("%d", &numPlaces);

    int minWidth, maxWidth, minLength, maxLength, minHeight;
    scanf("%d %d %d %d %d", &minWidth, &maxWidth, &minLength, &maxLength, &minHeight);

    int origin, destination;
    scanf("%d %d", &origin, &destination);

    Section *sections = malloc(100 * sizeof(Section));
    int count = 0;

    while (1) {
        int start;
        int result = scanf("%d", &start);
        if (result == EOF || start == -1) break;
        sections[count].start = start;
        scanf("%d %d %d %d", &sections[count].end, 
              &sections[count].maxWidth, &sections[count].maxLength, 
              &sections[count].maxHeight);
        count++;
    }

    int validSections = 0;
    for (int i = 0; i < count; i++) {
        if ((sections[i].start != origin && sections[i].end != origin) &&
            (sections[i].start != destination && sections[i].end != destination) &&
            (sections[i].maxWidth >= minWidth && sections[i].maxWidth <= maxWidth &&
             sections[i].maxLength >= minLength && sections[i].maxLength <= maxLength &&
             sections[i].maxHeight >= minHeight)) {
            validSections++;
        }
    }

    printf("%d\n", validSections);
    free(sections);
    return 0;
}
