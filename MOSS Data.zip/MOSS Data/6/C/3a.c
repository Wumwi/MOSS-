#include<string.h>
#include<stdbool.h>
#include<stdio.h>

int main(){
    int s, d, c, l ,a, count = 0,
        N, larMax, larMin, compMax, compMin, Altura,
        source, destiny; 
    scanf("%d",&N);
    scanf("%d %d %d %d %d",&larMin,&larMax,&compMin,&compMax,&Altura);
    scanf("%d %d",&source,&destiny);
    
    while(true){
        scanf("%d",&s);
        if (s==-1)
            break;
        scanf("%d %d %d %d",&d,&l,&c,&a);
        if (l>=larMin && c>=compMin && a>=Altura)
            ++count;
    }
    printf("%d\n",count);
    return 0;
}
