#include <stdio.h>

typedef struct {
    int start, end;
    int maxWidth, maxLength, maxHeight;
} Section;

int main() {
    int numPlaces;
    scanf("%d", &numPlaces);

    int minWidth, maxWidth, minLength, maxLength, minHeight;
    scanf("%d %d %d %d %d", &minWidth, &maxWidth, &minLength, &maxLength, &minHeight);

    int origin, destination;
    scanf("%d %d", &origin, &destination);

    Section sections[100];
    int count = 0;

    while (1) {
        int result = scanf("%d", &sections[count].start);
        if (result == EOF || sections[count].start == -1) break;
        scanf("%d %d %d %d", &sections[count].end, &sections[count].maxWidth, 
              &sections[count].maxLength, &sections[count].maxHeight);
        count++;
    }

    int validSections = 0;
    for (int i = 0; i < count; i++) {
        if ((sections[i].start != origin && sections[i].end != origin) &&
            (sections[i].start != destination && sections[i].end != destination)) {
            if (sections[i].maxWidth >= minWidth && sections[i].maxWidth <= maxWidth &&
                sections[i].maxLength >= minLength && sections[i].maxLength <= maxLength &&
                sections[i].maxHeight >= minHeight) {
                validSections++;
            }
        }
    }

    printf("%d\n", validSections);
    return 0;
}
