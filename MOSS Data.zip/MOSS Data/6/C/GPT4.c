#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int start, end;
    int maxWidth, maxLength, maxHeight;
} Section;

int main() {
    int numPlaces;
    if (scanf("%d", &numPlaces) != 1) return 1;

    int minWidth, maxWidth, minLength, maxLength, minHeight;
    if (scanf("%d %d %d %d %d", &minWidth, &maxWidth, &minLength, &maxLength, &minHeight) != 5) return 1;

    int origin, destination;
    if (scanf("%d %d", &origin, &destination) != 2) return 1;

    Section sections[100];
    int count = 0;

    while (1) {
        int start;
        if (scanf("%d", &start) != 1 || start == -1) break;
        sections[count].start = start;
        if (scanf("%d %d %d %d", &sections[count].end, 
                  &sections[count].maxWidth, &sections[count].maxLength, 
                  &sections[count].maxHeight) != 4) return 1;
        count++;
    }

    int validSections = 0;
    for (int i = 0; i < count; i++) {
        if ((sections[i].start != origin && sections[i].end != origin) &&
            (sections[i].start != destination && sections[i].end != destination) &&
            (sections[i].maxWidth >= minWidth && sections[i].maxWidth <= maxWidth &&
             sections[i].maxLength >= minLength && sections[i].maxLength <= maxLength &&
             sections[i].maxHeight >= minHeight)) {
            validSections++;
        }
    }

    printf("%d\n", validSections);
    return 0;
}
