#include <stdio.h>

typedef struct {
    int start, end;
    int maxWidth, maxLength, maxHeight;
} Section;

void readDimensions(int *minWidth, int *maxWidth, int *minLength, int *maxLength, int *minHeight) {
    scanf("%d %d %d %d %d", minWidth, maxWidth, minLength, maxLength, minHeight);
}

void readSections(Section sections[], int *count) {
    while (1) {
        int start;
        int result = scanf("%d", &start);
        if (result == EOF || start == -1) break;
        sections[*count].start = start;
        scanf("%d %d %d %d", &sections[*count].end, 
              &sections[*count].maxWidth, &sections[*count].maxLength, 
              &sections[*count].maxHeight);
        (*count)++;
    }
}

int isValidSection(Section s, int minWidth, int maxWidth, int minLength, int maxLength, int minHeight) {
    return (s.maxWidth >= minWidth && s.maxWidth <= maxWidth &&
            s.maxLength >= minLength && s.maxLength <= maxLength &&
            s.maxHeight >= minHeight);
}

int main() {
    int numPlaces, origin, destination;
    scanf("%d", &numPlaces);

    int minWidth, maxWidth, minLength, maxLength, minHeight;
    readDimensions(&minWidth, &maxWidth, &minLength, &maxLength, &minHeight);
    
    scanf("%d %d", &origin, &destination);

    Section sections[100];
    int count = 0;
    readSections(sections, &count);

    int validSections = 0;
    for (int i = 0; i < count; i++) {
        if ((sections[i].start != origin && sections[i].end != origin) &&
            (sections[i].start != destination && sections[i].end != destination) &&
            isValidSection(sections[i], minWidth, maxWidth, minLength, maxLength, minHeight)) {
            validSections++;
        }
    }

    printf("%d\n", validSections);
    return 0;
}
