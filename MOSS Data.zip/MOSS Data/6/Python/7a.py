trocos = {}

def a():
	nLocais = input()
	x = input().split()
	lmin = int(x[0])
	lmax = int(x[1])
	cmin= int(x[2])
	cmax = int(x[3])
	amin = int(x[4])

	x = input().split()
	origem = int(x[0])
	destino = int(x[1])

	nTrocos = 0
	while True:
		x = input().split()
		ori = int(x[0])
		if ori == -1: break
		dest = int(x[1])
		larg = int(x[2])
		comp = int(x[3])
		alt = int(x[4])

		if larg >= lmin and comp >= cmin and alt >= amin:
			nTrocos += 1
	print(nTrocos)

a()
