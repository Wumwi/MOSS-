def a():
    ext=read_input()
    lmin,lmax,cmin,cmax,amin= read_input()
    ori,dest=read_input()
    first=read_input()
    score=0
    while first != [-1]:
        if lmin <= first[2]  and cmin <= first[3]  and amin <= first[4]:
            score+=1
        first = read_input()
    print(score)
    









def read_input():
    x=map(int,input().split())
    return x


a()

