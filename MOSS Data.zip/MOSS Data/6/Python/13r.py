def probA():
    contar=0
    grafo={}
    props={}
    nos=input()
    lmin,lmax,cmin,cmax,amin=input().split(" ")
    origem,destino=input().split(" ")
    lmin=int(lmin)
    lmax=int(lmax)
    cmin=int(cmin)
    cmax=int(cmax)
    amin=int(amin)
    origem=int(origem)
    destino=int(origem)
 
    linha=input()
    while linha!="-1":
        a, b, Clmax, Ccmax, Camax=linha.split(" ")
        a=int(a)
        b=int(b)
        Clmax=int(Clmax)
        Ccmax=int(Ccmax)
        Camax=int(Camax)
 
        if (a,b) in props.keys():
            props[a,b]+=[Clmax,Ccmax,Camax]
        else:
            props[a,b]=[Clmax,Ccmax,Camax]
            
        linha=input()

#    print "props",props
    for i in props.keys():
 #       print "i",i
  #      print "lmin",lmin
   #     print "cmin",cmin
    #    print "amin",amin
  #      print props[i][0]
        if lmin<=props[i][0] and cmin<=props[i][1] and amin<=props[i][2]:
     #       print "+1"
      #      print "-----------"
            contar=contar+1

    print(contar)

 


probA()
