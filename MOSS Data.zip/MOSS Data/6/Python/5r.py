def readinput():
    return map(int,input().split())

def encomenda():
    count=0
    ext=input()
    x=readinput()
    print(x)
    lmin,lmax,cmin,cmax,hmin=x[0],x[1],x[2],x[3],x[4]
    readinput()
    x=readinput()
    while x[0] != -1:
        print(x)
        if x[2]>=lmin and x[3]>=cmin and x[4]>=hmin:
            count+=1
        x=readinput()
    print(count)

encomenda()
