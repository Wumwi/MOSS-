def problema():
    medidas=[]
    ntrocos=input()
    medidas=input().split()
    od=input().split()
    x=input().split()
    v=[]
    c=0
    print(x)
    while x[0] != "-1":
        v.append(x)
        x=input().split()
    for i in range(len(v)):
        if v[i][2]>= medidas[0]:
            if v[i][3]>= medidas[2]:
                if v[i][4]>= medidas[4]:
                    if v[i][1] <= ntrocos:
                        if v[i][0] <= ntrocos:
                            c=c+1    
    return c

print(problema())
