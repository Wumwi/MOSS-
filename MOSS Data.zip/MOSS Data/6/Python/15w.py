def A():
	x = input().split()
	valores=[]
	for i in range(len(x)):
		valores[1] = int(valores[1])
	return valores



#while valores[0] != -1
#	if 
