import numpy as np

class Section:
    def __init__(self, start, end, max_width, max_length, max_height):
        self.start = start
        self.end = end
        self.max_width = max_width
        self.max_length = max_length
        self.max_height = max_height

def main():
    num_places = int(input())
    min_width, max_width, min_length, max_length, min_height = map(int, input().split())
    origin, destination = map(int, input().split())

    sections = []

    while True:
        line = input().strip()
        if line == "-1":
            break
        start, end, max_w, max_l, max_h = map(int, line.split())
        sections.append(Section(start, end, max_w, max_l, max_h))

    valid_sections = sum(
        1 for section in sections
        if (section.start != origin and section.end != origin and
            section.start != destination and section.end != destination) and
           (min_width <= section.max_width <= max_width and
            min_length <= section.max_length <= max_length and
            section.max_height >= min_height)
    )

    print(valid_sections)

if __name__ == "__main__":
    main()
