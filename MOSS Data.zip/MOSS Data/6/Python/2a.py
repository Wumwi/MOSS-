def readln(): return map(int,input().split())

def encomenda():
    g={}
    count=0
    n=input()
    lmin,lmax,cmin,cmax,amin=readln()
    noi,nof=readln()
    aresta=readln()
    while aresta[0]!=-1:
        if (lmin<=aresta[2] and cmin<=aresta[3] and amin<=aresta[4]):
           count+=1
        aresta=readln()
    print(count)

encomenda()
    
    
