
def entrada():
        n = input()
        limites = []
        linha = input().split()
        l,L,c,C,h = map(int,linha)
        
        linha = input().split()
        linha = input().split()
        count = 0
        while (len(linha) > 1):
                o,d,lt,ct,ht = map(int,linha)
                if lt >= l and ct >= c:
                        count += 1
                linha = input().split()
        print(count)
entrada()
