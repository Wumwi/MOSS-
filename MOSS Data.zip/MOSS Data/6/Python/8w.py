def funcao():
    x=le_valores()
    return x

def le_valores():
    count=0
    n=input()
    x=input()
    x=x.split()
    larMin,larMax,compMin,compMax,altMin=int(x[0]),int(x[1]),int(x[2]),int(x[3]),int(x[4])
    seg=input()
    seg=seg.split()
    par,dest=int(seg[0]),int(seg[1])
    x=input()
    while x!="-1":
        x=x.split()
        i,d,lM,cM,aM=int(x[0]),int(x[1]),int(x[2]),int(x[3]),int(x[4])
        if d!=dest and i!=par:
            if lM>=larMin:
                if cM>=compMin:
                    if aM>=altMin:
                        count+=1
        x=input()
    return count

#print funcao()
