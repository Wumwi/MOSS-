import string
def encomenda():
    n=input()
    temp=input()
    lmin,lmax,cmin,cmax,amin=temp.split(' ')
    int (lmin)
    int(lmax)
    int(cmin)
    int(cmax)
    int(amin)
    
    temp=input()
    cam=0
    final=-1
    temp=input()
    ori,des,l,c,a=temp.split(' ')
    a=int(a)
    c=int(c)
    l=int(l)
    
    while ori!=-1:
        if (l>=lmin) and (c>=cmin) and (a>=amin):
            cam+=1
        temp=input()
        if int(temp[0]+temp[1])==final:
            break
        else:
            ori,des,l,c,a=temp.split(' ')
            print(l,c,a, "===>",lmin,cmin,amin)
            print(cam)
            a=int(a)
            c=int(c)
            l=int(l)
    print(cam)
encomenda()
