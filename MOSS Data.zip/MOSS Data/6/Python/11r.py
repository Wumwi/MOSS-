def bfs (G,visited,pos):

    adj=[]
    k=pos[0]
    adj.extend(G[k])

    counter=0

    while len(visited)!=0:
        for i in G[k]:

            if len(adj)==0:
                break

            if i==pos[1]:
                counter+=1

            elif visited.count(i)==1:
                adj.extend(G[i])
                visited.remove(i)

            k=adj.pop(0)       

    return counter

def main():

    G={}
    case={}
    visited=[]

    local=input()

    x=input().split()
    jaula=[int(x[0]),int(x[1]),int(x[2]),int(x[3]),int(x[4])]

    x=input().split()
    pos=[int(x[0]),int(x[1])]

    x=input().split()

    while x!=['-1']:

        a=int(x[0])
        b=int(x[1])

        if a<=local and b<=local and a>=0 and b>=0:
            
            size=[int(x[2]),int(x[3]),int(x[4])]

            #if size[0]>=jaula[0] and size[0]<=jaula[1] and size[1]>=jaula[2] and size[1]<=jaula[3] and size[2]>=jaula[4]:

            if visited.count(a)==0:
                visited.append(a)
                G[a]=[]

            else:
                G[a]=G[a]+[b]
                    
            if visited.count(b)==0:
                visited.append(b)
                G[b]=[]

            else:
                G[b]=G[b]+[a]
            
        x=input().split()

    print(bfs(G,visited,pos))

main()
