def encomenda():
    trocos = 0
    n = input() #numero de pontos
    x = input().split() #leitura das dimensoes
    lmin = int(x[0])
    lmax = int(x[1])
    cmin = int(x[2])
    cmax = int(x[3])
    hmin = int(x[4])
    y = input().split() #pontos de inicio e fim
    start=int(y[0])
    end=int(y[1])
    linhas=input().split()
    while linhas[0] != '-1':
        e1=int(linhas[0])
        e2=int(linhas[1])
        l=int(linhas[2])
        c=int(linhas[3])
        h=int(linhas[4])
        if l>=lmin and c>=cmin and h>=hmin:
            trocos += 1
        linhas = input().split()
    return trocos

print(encomenda())
