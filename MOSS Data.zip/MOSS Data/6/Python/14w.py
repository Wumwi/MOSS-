

def ProbA():
    count = 0
    num_locais = input()
    
    dim_jaula = input().split()
    largura_min = int(dim_jaula[0])
    largura_max = int(dim_jaula[1])
    comp_min = int(dim_jaula[2])
    comp_max =int(dim_jaula[3])
    alt_min =int(dim_jaula[4])
    
    aux = input().split()
    origem = int(aux[0])
    destino = int(aux[1])

    dados = input().split()
    
    while dados[0] != '-1':
        A = int(dados[0])
        B = int(dados[1])
        largura = int(dados[2])
        comp = int(dados[3])
        altura = int(dados[4])
        if comp >= comp_min and comp <= comp_max :
            if largura >= largura_min and largura <= largura_max :
                if altura >= alt_min :
                    count +=2
        dados = input().split()
    return count
                 


print(ProbA())
