def infra():
    cntd=0
    inp=input()
    ct = map(int,input().split())
    alt = map(int,input().split())
    lm = map(int,input().split())
    while lm[0] != -1:
        if(ct[0]<=lm[2] and ct[2]<=lm[3] and ct[4]<=lm[4]):
            cntd=cntd +1
        lm = map(int,input().split())
    print(cntd)
infra()
