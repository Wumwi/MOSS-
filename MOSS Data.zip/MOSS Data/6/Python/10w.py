def IEST():
    numero_d_caminhos = 0
    d = 0
    n_locais = input()
    medidas = map(int, input().split())
    l_min = medidas[0]
    l_max = medidas[1]
    c_min = medidas[2]
    c_max = medidas[3]
    alt_min = medidas[4]
    origem_destino = map(int, input().split())
    while d != -1:
        dados = map(int, input().split())
        if dados[0] == -1:
            d = -1
        if d != -1:
            if dados[4] >= alt_min and dados[2] >= l_min and dados[3] >= c_min:
                numero_d_caminhos = numero_d_caminhos + 1
    print(numero_d_caminhos)

