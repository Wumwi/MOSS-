import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Section {
    int start, end;
    int maxWidth, maxLength, maxHeight;

    public Section(int start, int end, int maxWidth, int maxLength, int maxHeight) {
        this.start = start;
        this.end = end;
        this.maxWidth = maxWidth;
        this.maxLength = maxLength;
        this.maxHeight = maxHeight;
    }
}

public class CageTransport {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numPlaces = scanner.nextInt();
        int minWidth = scanner.nextInt();
        int maxWidth = scanner.nextInt();
        int minLength = scanner.nextInt();
        int maxLength = scanner.nextInt();
        int minHeight = scanner.nextInt();

        int origin = scanner.nextInt();
        int destination = scanner.nextInt();

        List<Section> sections = new ArrayList<>();

        while (true) {
            int start = scanner.nextInt();
            if (start == -1) break;
            int end = scanner.nextInt();
            int maxW = scanner.nextInt();
            int maxL = scanner.nextInt();
            int maxH = scanner.nextInt();
            sections.add(new Section(start, end, maxW, maxL, maxH));
        }

        int validSections = 0;
        for (Section s : sections) {
            if (s.start != origin && s.end != origin && s.start != destination && s.end != destination) {
                if (s.maxWidth >= minWidth && s.maxWidth <= maxWidth &&
                    s.maxLength >= minLength && s.maxLength <= maxLength &&
                    s.maxHeight >= minHeight) {
                    validSections++;
                }
            }
        }

        System.out.println(validSections);
        scanner.close();
    }
}
