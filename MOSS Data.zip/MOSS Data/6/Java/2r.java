import java.util.*;

class infra_estrutura{

	public static void main(String[] args)
	{
		Scanner std = new Scanner(System.in);
		int nLocal = std.nextInt();
		int lMin = std.nextInt();
		int lMax = std.nextInt();
		int cMin = std.nextInt();
		int cMax = std.nextInt();
		int altMin = std.nextInt();
		int origem = std.nextInt();
		int destino = std.nextInt();
		int inicio[] = new int[nLocal*2];
		int fim[] = new int[nLocal*2];
		int l[] = new int[nLocal*2];
		int c[] = new int[nLocal*2];
		int a[] = new int[nLocal*2];
		int i=0;
		int aux = 0;
		aux = std.nextInt();
		while(aux!=(-1))
		{
			inicio[i] = aux;
			fim[i] = std.nextInt();
			l[i] = std.nextInt();
			c[i] = std.nextInt();
			a[i] = std.nextInt();
			i++;
			aux = std.nextInt();
		}
		boolean f1,f2,f3;
		f1 = false;
		f2 = false;
		f3 = false;
		int conta=0;
		for(int j=0;j<=i;j++)
		{
			if(l[j] >= lMax)
			{
				f1 = true;
			}
			else
			{
				if(l[j]<=lMax && l[j]>=lMin)
				{
					f1 = true;
				}
				else
				{
					f1 = false;
				}
			}
			if(c[j] >= cMax)
			{
				f2 = true;
			}
			else
			{
				if(c[j]<=cMax && c[j]>=cMin)
				{
					f2 = true;
				}
				else
				{
					f2 = false;
				}
			}
			if(a[j]>=altMin)
			{
				f3 = true;
			}
			else
			{
				f3 = false;
			}
			if(f1 == true && f2 == true && f3 == true)
			{
				conta++;
				f1 = false;
				f2 = false;
				f3 = false;
			}
		}
		System.out.println(conta);
	}
}
