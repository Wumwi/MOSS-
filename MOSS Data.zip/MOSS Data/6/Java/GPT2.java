import java.util.Scanner;

class Section {
    int start, end;
    int maxWidth, maxLength, maxHeight;

    public Section(int start, int end, int maxWidth, int maxLength, int maxHeight) {
        this.start = start;
        this.end = end;
        this.maxWidth = maxWidth;
        this.maxLength = maxLength;
        this.maxHeight = maxHeight;
    }
}

public class CageTransport {
    private static void readDimensions(Scanner scanner, int[] dimensions) {
        for (int i = 0; i < dimensions.length; i++) {
            dimensions[i] = scanner.nextInt();
        }
    }

    private static Section[] readSections(Scanner scanner, int[] dimensions) {
        Section[] sections = new Section[100];
        int count = 0;
        while (true) {
            int start = scanner.nextInt();
            if (start == -1) break;
            int end = scanner.nextInt();
            int maxW = scanner.nextInt();
            int maxL = scanner.nextInt();
            int maxH = scanner.nextInt();
            sections[count++] = new Section(start, end, maxW, maxL, maxH);
        }
        return sections;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int numPlaces = scanner.nextInt();
        int[] dimensions = new int[5];
        readDimensions(scanner, dimensions);
        
        int origin = scanner.nextInt();
        int destination = scanner.nextInt();
        
        Section[] sections = readSections(scanner, dimensions);
        
        int validSections = 0;
        for (Section s : sections) {
            if (s != null && s.start != origin && s.end != origin &&
                s.start != destination && s.end != destination &&
                s.maxWidth >= dimensions[0] && s.maxWidth <= dimensions[1] &&
                s.maxLength >= dimensions[2] && s.maxLength <= dimensions[3] &&
                s.maxHeight >= dimensions[4]) {
                validSections++;
            }
        }

        System.out.println(validSections);
        scanner.close();
    }
}
