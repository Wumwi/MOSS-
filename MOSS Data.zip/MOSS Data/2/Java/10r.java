//package cenas;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

class Arco {
    int no_final;
    int valor;
    
    
    Arco(int fim, int v){
	no_final = fim;
	valor = v;
	
    }
    
    int extremo_final() {
	return no_final;
    }

    int valor_arco() {
	return valor;
    }
}


class No {
    int deph;
    LinkedList<Arco> adjs;
    No() {
	adjs = new LinkedList<Arco>();
	
    }
    
}


class Grafo {
    No verts[];
    int nvs, narcos;
			
    public Grafo(int n) {
	nvs = n;
	narcos = 0;
	verts  = new No[n+1];
	for (int i = 0 ; i <= n ; i++)
	    verts[i] = new No();
        // para vertices numerados de 1 a n (posicao 0 nao vai ser usada)
    }
    
    public int num_vertices(){
	return nvs;
    }

    public int num_arcos(){
	return narcos;
    }

    public LinkedList<Arco> adjs_no(int i) {
	return verts[i].adjs;
    }
    
    public void insert_new_arc(int i, int j, int valor_ij){
	verts[i].adjs.addFirst(new Arco(j,valor_ij));
        narcos++;
    }

    public Arco find_arc(int i, int j){
	for (Arco adj: adjs_no(i))
	    if (adj.extremo_final() == j) return adj;
	return null;
    }
}
public class Luxo {
	static int mini=500;
	//public static LinkedList<Integer> dephs= new LinkedList<Integer>();
	public static void main(String args[]){
		Scanner in= new Scanner(System.in);
		int tempMin=in.nextInt();
		int tempMax=in.nextInt();
		int origem=in.nextInt();
		int destino=in.nextInt();
	
		Grafo g = new Grafo(in.nextInt());
		int n=in.nextInt();
		for(int i=0;i<n;i++){
			int t=in.nextInt();
			int t2=in.nextInt();
			int t3=in.nextInt();
			if(t3>tempMin && t3<tempMax){
				g.insert_new_arc(t,t2, t3);
				g.insert_new_arc(t2,t, t3);
			}
			in.nextInt();
		}
		int nofixexptowindo=bfs(g,origem,destino,0);
		
		if(mini==500){
			System.out.println("Nao");	
		}else{
			System.out.println("Sim "+mini);

		}
	}
	public static LinkedList<Integer> visited= new LinkedList<Integer>();
	
	private static int bfs(Grafo g,int origem, int destino,int count) {
		LinkedList<Integer> stack = new LinkedList<Integer>();
		stack.push(origem);
		visited.add(origem);
		
		while(!stack.isEmpty()) {
			int node = (int)stack.pop();
			for(Arco a: g.adjs_no(origem)){
				if(!visited.contains(a.extremo_final())){
					
					if(destino==a.extremo_final()){
						//System.out.print(destino +" " +a.extremo_final());
						if(mini>count+1){
							mini=count+1;
						}
						//dephs.add(count+1);
						return 1;
					}
					bfs(g,a.extremo_final(),destino,count+1);
				}
			}
		
		}
		return 0;
	}
}
