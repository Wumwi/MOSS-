import java.util.Scanner;

public class AlphabetSoup {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String word1 = scanner.next();
        String word2 = scanner.next();
        scanner.close();

        char[] arr1 = word1.toCharArray();
        char[] arr2 = word2.toCharArray();
        
        int i = 0;
        int minLength = Math.min(arr1.length, arr2.length);

        // Find the first differing character
        while (i < minLength && arr1[i] == arr2[i]) {
            i++;
        }

        // If we found a differing pair
        if (i < arr1.length && i < arr2.length) {
            System.out.println("" + arr1[i] + arr2[i]);
        } else {
            // Check if word1 is a prefix of word2 or both are equal
            if (word1.length() <= word2.length()) {
                System.out.println("Nenhum");
            }
        }
    }
}
