import java.util.Scanner;

public class AlphabetSoup {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String word1 = scanner.next();
        String word2 = scanner.next();
        scanner.close();

        int i = 0;
        while (i < word1.length() && i < word2.length() && word1.charAt(i) == word2.charAt(i)) {
            i++;
        }

        // If we found a distinguishing pair
        if (i < word1.length() && i < word2.length()) {
            System.out.println("" + word1.charAt(i) + word2.charAt(i));
        } else {
            // Check if word1 is a prefix of word2 or both are equal
            if (word1.length() <= word2.length()) {
                System.out.println("Nenhum");
            }
        }
    }
}
