import java.util.Scanner;

public class AlphabetSoup {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String word1 = scanner.next();
        String word2 = scanner.next();
        scanner.close();

        int len1 = word1.length();
        int len2 = word2.length();

        for (int i = 0; i < Math.min(len1, len2); i++) {
            if (word1.charAt(i) != word2.charAt(i)) {
                System.out.println("" + word1.charAt(i) + word2.charAt(i));
                return;
            }
        }

        // Check if one word is a prefix of the other or they are equal
        if (len1 <= len2) {
            System.out.println("Nenhum");
        }
    }
}
