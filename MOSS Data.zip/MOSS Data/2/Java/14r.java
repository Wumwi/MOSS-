import java.util.Scanner;
class SopaDeLetras{
  
  // campo do objeto
  private String sequencia1;
  private String sequencia2;
  
  SopaDeLetras(){}
  SopaDeLetras(String a, String b){
    sequencia1 = a;
	sequencia2 = b;
  }
  
  // Metodos do objeto
  public void comparar(String seq1, String seq2){                                   //Comparar duas sequencia de letras
    int i = 0;                                                                      // Inicializar a contagem, enquanto nao chegarmos ao fim da primeira
	while( i < seq1.length() && seq1.charAt(i) == seq2.charAt(i) )                  // entao as duas  aqui sao iguais
	   i++;                                                                         // continuar a contagem ate acabar ou ser interrompida pela condicao 2
	 
	if( i == seq1.length() ){                                                       // se o i terminou ( significa q i = comprimento da sequencia1)
	  System.out.println("Nenhum");                                                 // eno escrevemos nenhum
	}
	else                                                                            // senao
	  System.out.println(seq1.charAt(i) + "" + seq2.charAt(i));                     // foi a 2 condicao q parou o loop e escrevemos esses valores
	  
 }
 
  
  public static void main(String[] args){
    
	Scanner a = new Scanner(System.in);                                             // ler(primeira sequencia)
	System.out.println( "Escreve a primeira sequencia" );
	String seq1 = a.nextLine();                                                     // guardar na variavel seq1
	
	Scanner b  = new Scanner(System.in);                                            //  ler (2 sequencia )
	System.out.println( "Escreve a segunda sequencia" );
	String seq2 = b.nextLine();                                                     // guardar em seq2
	
	SopaDeLetras sequencias = new SopaDeLetras(seq1, seq2 );                        // Criar o objeto para as duas palavras
	
	sequencias.comparar(seq1, seq2);                                                // comparar as duas palavras
  }
}
	