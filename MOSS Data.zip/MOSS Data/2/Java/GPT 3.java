import java.util.Scanner;

public class AlphabetSoup {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String word1 = scanner.next();
        String word2 = scanner.next();
        scanner.close();

        // Iterate over both strings to find the first differing character
        int minLength = Math.min(word1.length(), word2.length());
        for (int i = 0; i < minLength; i++) {
            if (word1.charAt(i) != word2.charAt(i)) {
                System.out.println("" + word1.charAt(i) + word2.charAt(i));
                return;
            }
        }

        // Check if word1 is a prefix of word2 or they are equal
        if (word1.length() <= word2.length() && word2.startsWith(word1)) {
            System.out.println("Nenhum");
        }
    }
}
