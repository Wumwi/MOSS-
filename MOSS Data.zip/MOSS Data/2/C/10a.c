
#include <stdio.h>

int compara(char seq1[],char seq2[]);

int main(){
	char seq1[21], seq2[21];
	int idif;
	scanf("%s",seq1);
	scanf("%s",seq2);
	idif=compara(seq1,seq2);
	if (idif==-1){
		printf("Nenhum\n");
	}
	else{
		printf("%c%c\n",seq1[idif],seq2[idif]);
	}
	return 0;
}

int compara(char seq1[],char seq2[]){
	int i;
	i=0;
	while (seq1[i]!='\0' && seq1[i]==seq2[i]){
		i++;
	}
	if (seq1[i]=='\0'){
		return -1;
	}
	else{
		return i;
	}
}
