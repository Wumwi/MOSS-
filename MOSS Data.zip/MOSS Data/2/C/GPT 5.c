#include <stdio.h>
#include <string.h>

int main() {
    char word1[21], word2[21];
    scanf("%s %s", word1, word2);

    char *p1 = word1;
    char *p2 = word2;

    // Traverse both words to find the first differing characters
    while (*p1 && *p2 && *p1 == *p2) {
        p1++;
        p2++;
    }

    // If we found a differing pair
    if (*p1 && *p2) {
        printf("%c%c\n", *p1, *p2);
    } else {
        // Check if word1 is a prefix of word2 or they are equal
        if (strlen(word1) <= strlen(word2)) {
            printf("Nenhum\n");
        }
    }

    return 0;
}
