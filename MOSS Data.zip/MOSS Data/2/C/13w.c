#include <stdio.h>
#include <string.h>

int main(){
	
	int i=0, j=0, flag=0;
	char l1[20], l2[20];
	
	
	
	while( (l1[i]=getchar() ) != '\n')
		i++;
		
	while( (l2[j]=getchar() ) != '\n')
		j++;	
	
	int k;
	for(k=0; k<i && k<j ;k++){
		
		if(l1[k] != l2[k]){
			printf("%c%c\n", l1[k], l2[k]);
			flag=1;
			break;
		}
	}
	
	if(flag==0)
		printf("Nenhum\n");
	
	
	return 0;
}
