#include <stdio.h>
#include <stdlib.h>

#define MAXC 21

int compara(char seq1[],char seq2[]){
    int i=0;
    while(seq1[i]==seq2[i] && seq1[i]!='\0' )
        i=i+1;
    if(seq1[i]=='\0')
        return -1;
    else
        return i;

}

int main()
{
    char palavra1[MAXC],palavra2[MAXC];
    scanf("%s",palavra1);
    scanf("%s",palavra2);

    int idif=compara(palavra1,palavra2);

    if(idif==-1)
        printf("Nenhum\n");
    else
        printf("%c%c\n",palavra1[idif],palavra2[idif]);

    return 0;
}
