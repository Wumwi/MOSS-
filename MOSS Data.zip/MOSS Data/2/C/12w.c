#include <stdio.h>
#include <string.h>
#define MAXCHAR 20

 int main() {
	 int i=0;
	 char s1[MAXCHAR],s2[MAXCHAR];
	scanf("%s",s1);
	scanf("%s",s2);
	for( i = 0; i < strlen(s1); i++) { 
	if( s1[i] != s2[i]) {
		printf("%c%c\n",s1[i],s2[i]);
		return 0;
		}
}
printf("Nenhum\n");
return 0;
}
