#include <stdio.h>
#define MAX 21
int main()
{
  char A[MAX], B[MAX];
  int a=-1, i;
  scanf("%s", A);
  scanf(" %s", B);
  for(i=0; A[i] != '\0' && B[i] != '\0'; i ++)
    {
      if(A[i] != B[i]){
	printf("%c%c\n", A[i], B[i]);
	a=1;
	break;
      }
    }
  if(a == -1)
    printf("Nenhum\n");
  return 0;
}

