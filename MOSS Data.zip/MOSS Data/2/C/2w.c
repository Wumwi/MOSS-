#include <stdio.h>
#include <string.h>

int main(){
	int i, count=0, j, k;
	char c, d, st1[20], st2[20];
	
	for(j=0;c!='\n';j++){
		c=getchar();
		st1[j]=c;
	}
	st1[j-1]='\0';
	
	for(k=0;d!='\n';k++){
		d=getchar();
		st2[k]=d;
	}
	st2[k-1]='\0';
	
	for(i=0;(st1[i]!='\0' && st2[i]!='\0');i++){
		if(st1[i]!=st2[i]){
			printf("%c%c\n",st1[i],st2[i]);
			break;
		}
		else
			count++;
	}
	
	if(count==k-1 || count==j-1)
	printf("Nenhum\n");
	
	return 0;
}
