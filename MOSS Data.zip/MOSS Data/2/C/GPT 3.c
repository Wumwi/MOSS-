#include <stdio.h>
#include <string.h>

int main() {
    char word1[21], word2[21];
    scanf("%s %s", word1, word2);

    // Iterate over both strings to find the first differing character
    int i;
    for (i = 0; word1[i] != '\0' && word2[i] != '\0'; i++) {
        if (word1[i] != word2[i]) {
            printf("%c%c\n", word1[i], word2[i]);
            return 0;
        }
    }

    // If we finish the loop, check if word1 is a prefix of word2
    if (strlen(word1) <= strlen(word2)) {
        printf("Nenhum\n");
    }

    return 0;
}
