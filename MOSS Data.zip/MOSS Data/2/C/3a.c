#include <stdio.h>

int main()
{
	char p1[21];
	char p2[21];

	int i = 0;

	scanf("%s %s", p1, p2);

	while(p1[i] != 0)
	{
		if(p1[i] != p2[i])
		{
			printf("%c%c\n", p1[i], p2[i]);
			return 0;
		}

		i++;
	}

	printf("Nenhum\n");

	return 0;
}