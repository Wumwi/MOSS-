#include <stdio.h>
#include <string.h>

int main() {
    char word1[21], word2[21];
    scanf("%s %s", word1, word2);

    int len1 = strlen(word1);
    int len2 = strlen(word2);

    for (int i = 0; i < len1 && i < len2; i++) {
        if (word1[i] != word2[i]) {
            printf("%c%c\n", word1[i], word2[i]);
            return 0;
        }
    }

    // Check if one word is a prefix of the other
    if (len1 <= len2) {
        printf("Nenhum\n");
    }

    return 0;
}
