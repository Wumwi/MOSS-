// Sopa de Letras, resolve a primeira parte do exercicio Rare Order

#include <stdio.h>
// #include <string.h>  para usar strcmp(a,b)

#define MAXC 21 // rare order

int compara(char seq1[],char seq2[]);


int main(){
  int idif;
  char seq1[MAXC],seq2[MAXC];
  scanf("%s",seq1);
  scanf("%s",seq2);

  idif = compara(seq1,seq2); 

  if (idif == -1)
    printf("Nenhum\n");
  
  else printf("%c%c\n",seq1[idif],seq2[idif]);



  return 0;
}

int compara(char seq1[],char seq2[]){
  int i = 0;
  while (seq1[i] != '\0' && seq1[i] == seq2[i])
    i = i + 1;
  
  if (seq1[i]=='\0')
    return -1;
  return i;

}


