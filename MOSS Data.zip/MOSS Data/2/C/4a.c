#include <stdio.h>
#define MAXC 21

int compara(char s1[], char s2[]){
  int i=0;
  while (s1[i] != 0 && s1[i] == s2[i]) {
    i++;
  }
  if (s1[i] == 0)
    return -1;
  else
    return i;
}

int main() {
  char s1[MAXC], s2[MAXC];
  int idif;
  scanf("%s",s1);
  scanf("%s",s2);
  idif = compara(s1,s2);
  if (idif == -1)
    printf("Nenhum\n");
  else
    printf("%c%c\n",s1[idif],s2[idif]);
  return 0;
}
