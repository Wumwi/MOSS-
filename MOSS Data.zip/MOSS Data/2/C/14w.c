#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main() {
    
    int i;
    char word1[21],word2[21];
    
    for(i=0; (word1[i]=getchar())!='\n' ; i++ );
    for(i=0; (word2[i]=getchar())!='\n' ; i++ );    
    
    for(i=0; i<20; i++){
        
        
        if(word1[i]=='\n' || word2[i]=='\n'){
            
            printf("Nenhum\n");
            return 0;
        }
            
        if(word1[i]!=word2[i]){
            
            printf("%c%c\n", word1[i], word2[i]);
            return 0;
        }
    }
    
    return 0;
}

