#include <stdio.h>

char st1[30], st2[30];

int main()
{
  scanf(" %s %s", st1, st2);
  int i;
  for (i = 0; st1[i] != '\0' && st2[i] != '\0'; i++)
    if (st1[i] != st2[i])
      break;

  if (st1[i] != '\0' && st2[i] != '\0')
    printf("%c%c\n", st1[i], st2[i]);
  else
    printf("Nenhum\n");

  return 0;
}
