#include <stdio.h>
#include <string.h>

int main() {
    char word1[21], word2[21];
    scanf("%s %s", word1, word2);

    int i = 0;
    while (word1[i] != '\0' && word2[i] != '\0' && word1[i] == word2[i]) {
        i++;
    }

    // If we found a distinguishing pair
    if (word1[i] != '\0' && word2[i] != '\0') {
        printf("%c%c\n", word1[i], word2[i]);
    } else {
        // Check if word1 is a prefix of word2 or both are equal
        if (strlen(word1) <= strlen(word2)) {
            printf("Nenhum\n");
        } else {
            // No need for further output; it will never reach here in lexicographical order.
        }
    }

    return 0;
}
