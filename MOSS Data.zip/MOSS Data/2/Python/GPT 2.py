word1 = input().strip()
word2 = input().strip()

i = 0
while i < len(word1) and i < len(word2) and word1[i] == word2[i]:
    i += 1

# If we found a distinguishing pair
if i < len(word1) and i < len(word2):
    print(f"{word1[i]}{word2[i]}")
else:
    # Check if word1 is a prefix of word2 or both are equal
    if len(word1) <= len(word2):
        print("Nenhum")
