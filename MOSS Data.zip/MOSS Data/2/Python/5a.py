def a():
    pal1=input()
    pal2=input()
    if len(pal1) > len(pal2):
        tamanho=len(pal2)
    else:
        tamanho=len(pal1)
    for i in range(tamanho):
        if pal1[i] != pal2[i]:
            stri=str(pal1[i])+str(pal2[i])
            print(stri)
            break
        if i==tamanho-1:
            print("Nenhum")

a()
