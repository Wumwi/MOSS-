word1 = input().strip()
word2 = input().strip()

# Find the first differing character using enumerate
for i, (c1, c2) in enumerate(zip(word1, word2)):
    if c1 != c2:
        print(f"{c1}{c2}")
        break
else:
    # If no differing character is found, handle prefix or equality cases
    if len(word1) <= len(word2):
        print("Nenhum")
