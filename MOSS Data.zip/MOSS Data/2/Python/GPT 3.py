word1 = input().strip()
word2 = input().strip()

# Iterate over both strings to find the first differing character
min_length = min(len(word1), len(word2))
for i in range(min_length):
    if word1[i] != word2[i]:
        print(f"{word1[i]}{word2[i]}")
        break
else:
    # If word1 is a prefix of word2 or they are equal
    if len(word1) <= len(word2) and word2.startswith(word1):
        print("Nenhum")
