def sopa():
    palavra_um=input()
    palavra_dois=input()
    flag=True
    for i in range(len(palavra_um)):
        if flag==True:
            if palavra_um[i]!=palavra_dois[i]:
                print(palavra_um[2]+palavra_dois[2])
                #print palavra_dois[2]
                flag=False

    if flag==True:
        print('Nenhum')
    
    
sopa()
