def main():
    x=input()
    y=input()
    for i in range(0,len(x)):
        if x[i]!=y[i]:
            print(x[i],y[i])
            break
    if x[i]==y[i]:
        print('Nenhum')
        

main()
