def funcao():
    pum=input()
    pdois=input()
    for i in range(0,min(len(pum),len(pdois))):
        if pum[i]!=pdois[i]:
            string=pum[i]+pdois[i]
            return string
    return "Nenhum"

print(funcao())
