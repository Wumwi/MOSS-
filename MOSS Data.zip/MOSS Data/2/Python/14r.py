def A():
	P = ""
	F = input()
	S = input()
	for i in range(20):
		if F[i] != S[i]:
			P += F[i] + S[i]
			break
		elif i == (len(F) -1) and len(F) < len(S):
			P += F[i] + S[i+1]
			break
		elif i == (len(S) -1) and len(S) < len(F):
			P += F[i] + F[i+1]
			break
	print(P)
A()
