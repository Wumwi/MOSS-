def printletras(a,b):
	print(a+b)

def printnenhum():
	print("Nenhum")

def A():
	palavra1 = input()
	palavra2 = input()
	for i in range(len(palavra1)):
		if palavra1[i] != palavra2[i]:
			return printletras(palavra1[i],palavra2[i])
	return printnenhum()

A()
