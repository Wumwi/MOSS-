def prob_a():

	str1=input()
	str2=input()

	min_len = min (len(str1),len(str2))
	final_string = ""
	
	for i in range(min_len):
		if str1[i]!=str2[i]:
			final_string=final_string+str1[i]+str2[i]
			break		

	print(final_string)

prob_a()
