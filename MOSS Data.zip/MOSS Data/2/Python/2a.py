def a():
	pal_a = input()
	pal_b = input()
	n=min(len(pal_a),len(pal_b))
	res = "Nenhum"
	for i in xrange(n):
		if pal_a[i] != pal_b[i]:
			res = pal_a[i]+pal_b[i]
			break
	print(res)
	



a()
