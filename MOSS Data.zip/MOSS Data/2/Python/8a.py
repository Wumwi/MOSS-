def lexi():
    a=input()
    b=input()
    flag=0
    if len(a)>len(b):
        tam=len(b)
    else:
        tam=len(a)
        
    for num in range(tam):
        if a[num]<>b[num]:
            print(a[num]+""+b[num])
            flag=1
            break;
        
    if flag==0:
        print("Nenhum")
            
        








lexi()
