word1 = input().strip()
word2 = input().strip()

min_length = min(len(word1), len(word2))

for i in range(min_length):
    if word1[i] != word2[i]:
        print(f"{word1[i]}{word2[i]}")
        break
else:
    # Check if one word is a prefix of the other or they are equal
    if len(word1) <= len(word2):
        print("Nenhum")
