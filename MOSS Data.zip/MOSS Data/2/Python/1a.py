import string

def dados():
    lista = []
    a = input()
    a = string.split(a)
    for x in a:
        lista = lista + [x]
    return lista

def inicio():
    a = []
    b = []

    a = input()
    b = input()
    #print a,b
    for i in range(min(len(a),len(b))):
        if a[i] != b[i]:
            print(a[i]+ "" +b[i])
            return
    print("Nenhum")
    return
inicio()
