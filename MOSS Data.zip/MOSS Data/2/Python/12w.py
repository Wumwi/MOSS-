def a():
    s = ""
    p1 = input()
    p2 = input()
    for i in range(len(p1)):
        if p1[i] != p2[i]:
            s= p1[i] + p2[i]
            print(s)
            break
    if s == "":
        print("Nenhum")
    




