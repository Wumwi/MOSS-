
def a():
    list = []
    x= input()
    y= input()

    for i in range(len(x)):
        if x[i] != y[i]:
            print(x[i]+''+y[i])
            return
    if len(x)<len(y):
        print("Nenhum")
        return 
a()
