def main():

    x=input()
    y=input()

    size=min(len(x),len(y))

    string=""

    for i in range(0,size):

        if x[i]!=y[i]:
            string=x[i]+y[i]
            break

    if string=="":
        print("Nenhum")

    else:
        print(string)

main()
