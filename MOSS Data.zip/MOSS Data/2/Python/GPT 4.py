word1 = input().strip()
word2 = input().strip()

# Use zip to pair characters and find the first differing pair
diff_pair = next(((c1, c2) for c1, c2 in zip(word1, word2) if c1 != c2), None)

if diff_pair:
    print(f"{diff_pair[0]}{diff_pair[1]}")
else:
    # If no differing pair is found, check if word1 is a prefix of word2 or they are equal
    if len(word1) <= len(word2):
        print("Nenhum")
