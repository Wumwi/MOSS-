def A():
    d=0
    pal1 = input()
    pal2 = input()
    l1=len(pal1)
    l2=len(pal2)
    m=min(l1,l2)
    for k in range(m):
        if pal1[k]!=pal2[k]:
            print(pal1[k] + pal2[k])
            d=1
            break
    if d==0:
        print("Nenhum")
    

A()
