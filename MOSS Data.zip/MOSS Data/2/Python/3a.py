
def a():
   ant=input()
   s=input()

   f=False
   for i in range(min(len(ant),len(s))):
       if ant[i]!=s[i]:
           print(ant[i]+s[i])
           f=True
           break
   if f==False:
       print("Nenhum")
   
           

a()
